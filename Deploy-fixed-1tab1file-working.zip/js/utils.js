/**
 * FLASHCARD PRO - UTILS MODULE
 * Module này chứa các hàm tiện ích dùng chung toàn hệ thống như:
 * Toast thông báo, Confirm Dialog, và Hệ thống Âm thanh (Audio/TTS/Noise).
 */

Object.assign(app, {

    // ==========================================
    // 1. GIAO DIỆN TIỆN ÍCH (UI UTILS)
    // ==========================================
    toast: function (msg, type = 'success') {
        const container = document.getElementById('toast-container');
        if (!container) return alert(msg);

        const el = document.createElement('div');
        const colors = type === 'error' ? 'bg-red-500' : (type === 'info' ? 'bg-blue-500' : 'bg-green-500');
        const icon = type === 'error' ? '⚠️' : (type === 'info' ? 'ℹ️' : '✅');

        el.className = `${colors} text-white px-6 py-3 rounded-xl shadow-lg transform transition-all duration-500 translate-x-full flex items-center font-bold pointer-events-auto min-w-[300px] backdrop-blur-md`;
        el.innerHTML = `<span class="mr-3 text-xl">${icon}</span> ${msg}`;

        container.appendChild(el);
        requestAnimationFrame(() => el.classList.remove('translate-x-full'));
        setTimeout(() => { el.classList.add('opacity-0', 'translate-y-[-20px]'); setTimeout(() => el.remove(), 500); }, 3000);
    },

    confirmAction: function (msg, callback) {
        const modal = document.getElementById('modal-confirm');
        if (!modal) return confirm(msg) ? callback() : null;

        document.getElementById('confirm-msg').textContent = msg;
        const btnYes = document.getElementById('confirm-btn-yes');
        const newBtn = btnYes.cloneNode(true);
        btnYes.parentNode.replaceChild(newBtn, btnYes);

        newBtn.onclick = () => { modal.classList.add('hidden'); if (callback) callback(); };
        modal.classList.remove('hidden'); modal.classList.add('flex');
    },

    // ==========================================
    // 2. HỆ THỐNG ÂM THANH (AUDIO ENGINE)
    // ==========================================
    audioCtx: null,
    noiseOscillator: null,
    noiseBuffer: null,
    currentAudio: null,

    playNoise: function () {
        if (!this.state.listenNoise) return;
        this.stopNoise();
        try {
            if (!this.audioCtx) this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            if (!this.noiseBuffer) {
                const bufferSize = this.audioCtx.sampleRate * 2;
                this.noiseBuffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
                const data = this.noiseBuffer.getChannelData(0);
                let lastOut = 0;
                for (let i = 0; i < bufferSize; i++) {
                    const white = Math.random() * 2 - 1;
                    data[i] = (lastOut + (0.02 * white)) / 1.02;
                    lastOut = data[i];
                    data[i] *= 3.5;
                }
            }
            this.noiseOscillator = this.audioCtx.createBufferSource();
            this.noiseOscillator.buffer = this.noiseBuffer;
            this.noiseOscillator.loop = true;
            const gainNode = this.audioCtx.createGain();
            gainNode.gain.value = 0.4;
            this.noiseOscillator.connect(gainNode);
            gainNode.connect(this.audioCtx.destination);
            this.noiseOscillator.start();
            if (this.audioCtx.state === 'suspended') {
                this.audioCtx.resume();
            }
        } catch (e) { console.error("Noise Error:", e); }
    },

    stopNoise: function () {
        if (this.noiseOscillator) {
            try { this.noiseOscillator.stop(); } catch (e) { }
            this.noiseOscillator = null;
        }
    },

    stopAudio: function () {
        if (this.currentAudio) {
            this.currentAudio.pause();
            this.currentAudio.currentTime = 0;
            this.currentAudio = null;
        }
        if (window.speechSynthesis) window.speechSynthesis.cancel();
    },

    playAudio: async function (e, targetWord = null, isSlow = false, onComplete = null) {
        if (e) e.stopPropagation();
        this.stopAudio();

        const word = targetWord || document.getElementById('card-word')?.textContent.trim() || '';
        if (!word) return;

        let lang = this.user.voiceLang || 'en-US'; 
        let targetSpeed = isSlow ? 0.5 : parseFloat(this.user.voiceSpeed || '1.0');

        // KIỂM TRA: Nếu KHÔNG phải tiếng Anh (vd zh-CN, ja-JP), dùng luôn hệ thống TTS của trình duyệt
        if (!lang.startsWith('en')) {
            this.playTTS(word, lang, targetSpeed);
            if (onComplete) setTimeout(onComplete, 1500);
            return;
        }

        // Logic cũ cho riêng Tiếng Anh
        if (this.state.quizMode === 'listen') {
            if (this.state.listenSpeed) targetSpeed = this.state.listenSpeed;
            if (this.state.listenAccent) {
                const accents = ['en-US', 'en-GB', 'en-AU'];
                lang = accents[Math.floor(Math.random() * accents.length)];
            }
            this.playNoise();
        }

        const accentMap = { 'en-US': '-us.mp3', 'en-GB': '-uk.mp3', 'en-AU': '-au.mp3' };
        const requiredSuffix = accentMap[lang];

        try {
            const encodedWord = encodeURIComponent(word.toLowerCase());
            const dictUrl = `https://api.dictionaryapi.dev/api/v2/entries/en/${encodedWord}`;
            const response = await fetch(dictUrl);
            const data = await response.json();
            
            let audioUrl = null;
            if (Array.isArray(data) && data[0].phonetics) {
                const accentPhonetic = data[0].phonetics.find(p => p.audio && p.audio.endsWith(requiredSuffix));
                if (accentPhonetic) audioUrl = accentPhonetic.audio;
                if (!audioUrl) {
                    const anyPhonetic = data[0].phonetics.find(p => p.audio);
                    if (anyPhonetic) audioUrl = anyPhonetic.audio;
                }
            }

            if (audioUrl) {
                this.currentAudio = new Audio(audioUrl);
                this.currentAudio.playbackRate = targetSpeed;
                this.currentAudio.play();
                if(onComplete) this.currentAudio.onended = onComplete;
            } else {
                this.playTTS(word, lang, targetSpeed);
                if (onComplete) setTimeout(onComplete, 1500);
            }
        } catch (error) {
            console.error("Audio error:", error);
            this.playTTS(word, lang, targetSpeed);
            if (onComplete) setTimeout(onComplete, 1500);
        }
    },

    // Hàm đọc Web Speech API đa ngôn ngữ (Tiếng Trung, Nhật, Hàn...)
    playTTS: function(text, lang, speed) {
        if (!window.speechSynthesis) {
            if(this.toast) this.toast("Trình duyệt không hỗ trợ đọc giọng nói", "error");
            return;
        }
        window.speechSynthesis.cancel();
        
        const msg = new SpeechSynthesisUtterance(text);
        msg.lang = lang; // Gán đúng mã ngôn ngữ (zh-CN, ja-JP...)
        msg.rate = speed;
        
        let voices = window.speechSynthesis.getVoices();
        const speak = () => {
            // Ưu tiên chọn các giọng đọc nghe tự nhiên nhất (Google, Premium, Natural)
            let bestVoice = voices.find(v => v.lang.includes(lang.split('-')[0]) && (v.name.includes('Google') || v.name.includes('Premium') || v.name.includes('Natural')));
            if (!bestVoice) bestVoice = voices.find(v => v.lang.includes(lang.split('-')[0]));
            
            if (bestVoice) msg.voice = bestVoice;
            window.speechSynthesis.speak(msg);
        };

        // Fix lỗi Chrome thỉnh thoảng load voice bị chậm
        if (voices.length === 0) {
            window.speechSynthesis.onvoiceschanged = () => {
                voices = window.speechSynthesis.getVoices();
                speak();
            };
        } else {
            speak();
        }
    },

    playExampleAudio: function (e) {
        if (e) e.stopPropagation();
        let text = document.getElementById('card-example').textContent;
        text = text.replace(/^"|"$/g, '').trim();
        this.playAudio(e, text);
    },

    playSound: function (type) {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const t = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain); gain.connect(ctx.destination);

            if (type === 'correct') {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(523.25, t);
                osc.frequency.exponentialRampToValueAtTime(1046.50, t + 0.1);
                gain.gain.setValueAtTime(0, t);
                gain.gain.linearRampToValueAtTime(0.2, t + 0.01);
                gain.gain.exponentialRampToValueAtTime(0.01, t + 0.3);
                osc.start(t); osc.stop(t + 0.3);
            } else if (type === 'crit') {
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(880, t);
                osc.frequency.exponentialRampToValueAtTime(1760, t + 0.05);
                gain.gain.setValueAtTime(0, t);
                gain.gain.linearRampToValueAtTime(0.4, t + 0.01);
                gain.gain.exponentialRampToValueAtTime(0.01, t + 0.5);
                osc.start(t); osc.stop(t + 0.5);
            } else {
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(180, t);
                osc.frequency.linearRampToValueAtTime(60, t + 0.2);
                gain.gain.setValueAtTime(0, t);
                gain.gain.linearRampToValueAtTime(0.2, t + 0.01);
                gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
                osc.start(t); osc.stop(t + 0.2);
            }
        } catch (e) { }
    },

    copyToClipboard: async function (text, successMsg = "Đã sao chép!") {
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
            } else {
                const temp = document.createElement('textarea');
                temp.value = text;
                document.body.appendChild(temp);
                temp.select();
                document.execCommand('copy');
                document.body.removeChild(temp);
            }
            this.toast(successMsg, "success");
            return true;
        } catch (err) {
            this.toast("Không thể copy!", "error");
            return false;
        }
    },

    addCopyButtons: function () {
        setTimeout(() => {
            document.querySelectorAll('pre, code, textarea[readonly]').forEach(block => {
                const container = block.tagName === 'CODE' ? block.parentElement : block;
                if (!container || !container.parentElement) return;
                if (container.parentElement.classList.contains('relative') && container.parentElement.querySelector('.code-copy-btn')) return;
                
                container.parentElement.classList.add('relative');
                const btn = document.createElement('button');
                btn.className = 'code-copy-btn';
                btn.innerHTML = 'Copy';
                
                btn.onclick = async () => {
                    const text = block.value || block.innerText || block.textContent;
                    const ok = await this.copyToClipboard(text);
                    if (ok) {
                        btn.innerHTML = 'Copied!';
                        btn.classList.add('copied');
                        setTimeout(() => {
                            btn.innerHTML = 'Copy';
                            btn.classList.remove('copied');
                        }, 2000);
                    }
                };
                container.parentElement.appendChild(btn);
            });
        }, 100);
    },

    playTTS: function(text, lang, speed) {
        if (!window.speechSynthesis) return this.toast("Trình duyệt không hỗ trợ đọc giọng nói", "error");
        window.speechSynthesis.cancel();
        
        const msg = new SpeechSynthesisUtterance(text);
        msg.lang = lang;
        msg.rate = speed;
        
        let voices = window.speechSynthesis.getVoices();
        const speak = () => {
            let bestVoice = voices.find(v => v.lang.includes(lang.split('-')[0]) && (v.name.includes('Google') || v.name.includes('Premium')));
            if (!bestVoice) bestVoice = voices.find(v => v.lang.includes(lang.split('-')[0]));
            if (bestVoice) msg.voice = bestVoice;
            window.speechSynthesis.speak(msg);
        };

        if (voices.length === 0) {
            setTimeout(() => { voices = window.speechSynthesis.getVoices(); speak(); }, 100);
        } else {
            speak();
        }
    }
});