/**
 * FLASHCARD PRO - STORAGE MODULE
 * Quản lý Local Storage, Xuất File Backup và Nạp Dữ Liệu (Import/Export).
 */

Object.assign(app, {
    
    // ==========================================
    // 1. DATA LOAD & SAVE (Lưu và Tải dữ liệu gốc)
    // ==========================================

    loadData: function () {
        const stored = localStorage.getItem('flashcard_data');
        if (stored) {
            this.data = JSON.parse(stored).map(i => ({
                ...i, level: i.level || 0, nextReview: i.nextReview || 0
            }));
        } else {
            this.data = [{ id: 1, word: "Welcome", type: "Noun", pronun: "/ˈwel.kəm/", definition: "Chào mừng (Mẫu)", example: "Welcome to Flashcard Pro!", topic: "General", level: 0, nextReview: 0 }];
        }

        const userStored = localStorage.getItem('user_profile');
        if (userStored) this.user = JSON.parse(userStored);

        const mockStored = localStorage.getItem('flashcard_mock_history');
        if (mockStored) this.mockHistory = JSON.parse(mockStored);
        else this.mockHistory = [];

        this.renderStats();
        if (this.renderMockHistory) this.renderMockHistory();
        if (this.renderProfileHeader) this.renderProfileHeader();
        if (this.loadCard) this.loadCard(0);
    },

    saveData: function () {
        localStorage.setItem('flashcard_data', JSON.stringify(this.data));
        this.renderStats();
    },

    saveUserData: function () {
        if (!this.user.stats) this.user.stats = { str: 0, int: 0, agi: 0, dex: 0, vit: 0, luk: 0 };
        localStorage.setItem('user_profile', JSON.stringify(this.user));
    },

    saveMockHistory: function () {
        localStorage.setItem('flashcard_mock_history', JSON.stringify(this.mockHistory));
        if (this.renderMockHistory) this.renderMockHistory();
    },


    // ==========================================
    // 2. BACKUP & IMPORT (Xuất/Nhập file JSON)
    // ==========================================

    exportData: function () {
        const dataStr = JSON.stringify(this.data, null, 2);
        const blob = new Blob([dataStr], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `FlashCardPro_Backup_${new Date().toLocaleDateString('vi-VN').replace(/\//g, '-')}.json`;
        a.click();
        URL.revokeObjectURL(url);
        this.toast("Đã tải file Backup về máy!", "info");
    },

    importData: function (input) {
        const file = input.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                let rawText = e.target.result.trim();
                rawText = rawText.replace(/^```json/gi, '').replace(/```$/g, '').trim();
                let json = JSON.parse(rawText);
                
                if (!Array.isArray(json)) {
                    if (json.words && Array.isArray(json.words)) json = json.words;
                    else if (json.data && Array.isArray(json.data)) json = json.data;
                }

                if (Array.isArray(json)) {
                    if(typeof this.confirmAction === 'function') {
                        this.confirmAction(`Tìm thấy ${json.length} từ. Bạn muốn NẠP THÊM vào danh sách hiện tại?`, () => {
                            let count = 0;
                            const newItems = json.map((i, idx) => {
                                count++;
                                return {
                                    ...i,
                                    id: Date.now() + idx + Math.random(), 
                                    topic: i.topic ? i.topic.charAt(0).toUpperCase() + i.topic.slice(1) : 'Imported',
                                    isImported: true,
                                    level: 0,
                                    nextReview: 0
                                };
                            });
                            this.data = [...newItems, ...this.data]; 
                            this.saveData();
                            if (this.refreshViews) this.refreshViews();
                            if (this.toggleImportModal) this.toggleImportModal();
                            this.toast(`Đã nạp thành công ${count} từ mới!`, "success");
                        });
                    }
                } else this.toast("Format file không đúng chuẩn JSON!", "error");
            } catch (err) { this.toast("Lỗi đọc file! Hãy kiểm tra lại file JSON.", "error"); }
        };
        reader.readAsText(file);
        input.value = ''; 
    },

    clearData: function () {
        if(typeof this.confirmAction === 'function') {
            this.confirmAction("CẢNH BÁO: Toàn bộ dữ liệu sẽ bị xóa vĩnh viễn?", () => {
                this.data = [];
                this.mockHistory = [];

                this.user = {
                    name: this.user.name || 'Người Mới',
                    avatar: this.user.avatar || '👨‍🎓',
                    avatarBg: this.user.avatarBg || 'from-indigo-500 to-purple-600',
                    voiceMode: 'real',
                    voiceLang: 'en-US',
                    apiKey: '',
                    joinDate: Date.now(),
                    lastLoginDate: new Date().toLocaleDateString('en-CA'),
                    streak: 0,
                    totalDays: 1
                };

                this.saveUserData();
                this.saveMockHistory();
                this.refreshViews();
                this.toast("Đã Reset toàn bộ dữ liệu & Chuỗi ngày học!");
            });
        }
    }

});