/**
 * FLASHCARD PRO - USER MODULE
 * Module này quản lý Hồ sơ người dùng (Profile), Cài đặt (Settings),
 * Hệ thống RPG (Chỉ số, Kinh nghiệm, Cấp độ, Thành tựu, Nhiệm vụ)
 * và Trợ thủ Mascot.
 */

Object.assign(app, {

    // ==========================================
    // 1. LIFECYCLE & STREAK
    // ==========================================
    checkStreak: function () {
        const today = new Date().toLocaleDateString('en-CA');
        if (!this.user.joinDate) {
            this.user.joinDate = Date.now();
            this.user.totalDays = 1;
            this.user.streak = 1;
            this.user.lastLoginDate = today;
            return this.saveUserData();
        }
        if (this.user.lastLoginDate !== today) {
            this.user.totalDays++;
            const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
            if (this.user.lastLoginDate === yesterday.toLocaleDateString('en-CA')) {
                this.user.streak++;
                this.toast(`🔥 Chuỗi ${this.user.streak} ngày!`, "success");
            } else {
                this.user.streak = 1;
                this.toast("Bắt đầu lại chuỗi mới nhé!", "info");
            }
            this.user.lastLoginDate = today;
            this.saveUserData();
        }
        this.initDailyQuests(today);
    },

    // ==========================================
    // 2. CHỈ SỐ RPG & THÀNH TỰU (STATS & ACHIEVEMENTS)
    // ==========================================
    gainStat: function (stat, amount) {
        if (!this.user.stats) this.user.stats = { str: 0, int: 0, agi: 0, dex: 0, vit: 0, luk: 0 };
        this.user.stats[stat] += amount;
        this.saveUserData();
    },

    gainExp: function (amount) {
        if (!this.user.exp) this.user.exp = 0;

        const oldLvl = Math.floor(Math.sqrt(this.user.exp / 50)) + 1;
        this.user.exp += amount;
        const newLvl = Math.floor(Math.sqrt(this.user.exp / 50)) + 1;

        this.saveUserData();

        const lvlEl = document.getElementById('profile-lvl');
        if (lvlEl) lvlEl.textContent = newLvl;
        const xpTextEl = document.getElementById('profile-xp-text');
        if (xpTextEl) {
            const currentLevelExp = Math.pow(newLvl - 1, 2) * 50;
            const nextLevelExp = Math.pow(newLvl, 2) * 50;
            const progress = this.user.exp - currentLevelExp;
            const required = nextLevelExp - currentLevelExp;
            xpTextEl.textContent = `${progress} / ${required} EXP`;
            document.getElementById('profile-xp-bar').style.width = `${(progress / required) * 100}%`;
        }

        if (newLvl > oldLvl) {
            this.playSound('crit');
            this.toast(`🆙 LEVEL UP! BẠN ĐÃ ĐỘT PHÁ LÊN CẤP ${newLvl}!`, "success");

            const body = document.body;
            const div = document.createElement('div');
            div.className = 'fixed inset-0 bg-yellow-400/20 z-[9999] pointer-events-none animate-hit-flash mix-blend-overlay';
            body.appendChild(div);
            setTimeout(() => div.remove(), 400);
        }
    },

    achievementsSystem: [
        // Nhóm 1: Số lượng từ vựng (Words)
        { id: 'w1', type: 'words', req: 10, icon: '🌱', color: 'from-green-100 to-emerald-100 text-green-700 border-green-300 dark:from-green-900/40 dark:to-emerald-900/40', vi: 'Nông Dân', viD: 'Thêm 10 từ' },
        { id: 'w2', type: 'words', req: 100, icon: '⚔️', color: 'from-blue-100 to-indigo-100 text-blue-700 border-blue-300 dark:from-blue-900/40 dark:to-indigo-900/40', vi: 'Kẻ Đi Săn', viD: 'Thêm 100 từ' },
        { id: 'w3', type: 'words', req: 500, icon: '🐉', color: 'from-purple-100 to-fuchsia-100 text-purple-700 border-purple-300 dark:from-purple-900/40 dark:to-fuchsia-900/40', vi: 'Đồ Long Dũng Sĩ', viD: 'Thêm 500 từ' },
        { id: 'w4', type: 'words', req: 2000, icon: '👑', color: 'from-yellow-200 to-amber-300 text-amber-800 border-amber-400 dark:from-yellow-700/50 dark:to-amber-900/50 shadow-[0_0_15px_rgba(251,191,36,0.5)]', vi: 'Ma Vương', viD: 'Thêm 2000 từ' },
        { id: 'w5', type: 'words', req: 5000, icon: '🌌', color: 'from-gray-800 to-black text-gray-300 border-gray-600 dark:from-black dark:to-gray-900 shadow-[0_0_20px_rgba(255,255,255,0.2)]', vi: 'Thần Sáng Tạo', viD: 'Thêm 5000 từ' },
        
        // Nhóm 2: Chuỗi ngày học (Streak)
        { id: 's1', type: 'streak', req: 3, icon: '🧘', color: 'from-sky-100 to-cyan-100 text-sky-700 border-sky-300 dark:from-sky-900/40', vi: 'Luyện Khí', viD: 'Chuỗi 3 ngày' },
        { id: 's2', type: 'streak', req: 7, icon: '⚡', color: 'from-amber-100 to-orange-100 text-orange-700 border-orange-300 dark:from-amber-900/40', vi: 'Trúc Cơ', viD: 'Chuỗi 7 ngày' },
        { id: 's3', type: 'streak', req: 30, icon: '🌪️', color: 'from-rose-100 to-red-100 text-red-700 border-red-300 dark:from-rose-900/40', vi: 'Độ Kiếp', viD: 'Chuỗi 30 ngày' },
        { id: 's4', type: 'streak', req: 100, icon: '🔥', color: 'from-red-500 to-rose-600 text-white border-red-400 shadow-[0_0_15px_rgba(220,38,38,0.5)]', vi: 'Hỏa Thần', viD: 'Chuỗi 100 ngày' },
        
        // Nhóm 3: Từ vựng thuộc lòng (Mastered - lv 5)
        { id: 'm1', type: 'mastered', req: 10, icon: '🐟', color: 'from-teal-100 to-emerald-100 text-teal-700 border-teal-300 dark:from-teal-900/40', vi: 'Não Cá Vàng', viD: 'Thuộc 10 từ' },
        { id: 'm2', type: 'mastered', req: 100, icon: '🦉', color: 'from-indigo-100 to-violet-100 text-indigo-700 border-indigo-300 dark:from-indigo-900/40', vi: 'Cú Đêm', viD: 'Thuộc 100 từ' },
        { id: 'm3', type: 'mastered', req: 500, icon: '👁️', color: 'from-fuchsia-200 to-pink-200 text-pink-800 border-pink-400 dark:from-fuchsia-900/40 shadow-[0_0_15px_rgba(236,72,153,0.4)]', vi: 'Thần Giao Cách Cảm', viD: 'Thuộc 500 từ' },
        { id: 'm4', type: 'mastered', req: 1000, icon: '🧠', color: 'from-blue-500 to-indigo-600 text-white border-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.5)]', vi: 'Siêu Trí Tuệ', viD: 'Thuộc 1000 từ' },
        
        // Nhóm 4: Làm đề Mock Test
        { id: 't1', type: 'mock', req: 1, icon: '🛡️', color: 'from-slate-200 to-gray-200 text-gray-700 border-gray-400 dark:from-slate-700 dark:to-gray-800', vi: 'Dấn Thân', viD: 'Làm 1 Đề IELTS' },
        { id: 't2', type: 'mock', req: 10, icon: '🏹', color: 'from-cyan-100 to-blue-200 text-blue-800 border-blue-300 dark:from-cyan-900/40 dark:to-blue-900/40', vi: 'Chiến Binh', viD: 'Làm 10 Đề IELTS' },
        { id: 't3', type: 'mock', req: 50, icon: '🏆', color: 'from-yellow-100 to-yellow-300 text-yellow-800 border-yellow-400 dark:from-yellow-800/60 dark:to-yellow-600/60', vi: 'Chiến Thần', viD: 'Làm 50 Đề IELTS' },
        
        // Nhóm 5: Đấu trường Hầm ngục (Dungeon)
        { id: 'd1', type: 'dungeon', req: 10, icon: '🧟', color: 'from-lime-100 to-green-200 text-green-800 border-green-400 dark:from-green-900/50 dark:to-lime-900/30', vi: 'Thợ Săn Tân Binh', viD: 'Đạt Tầng 10 Dungeon' },
        { id: 'd2', type: 'dungeon', req: 50, icon: '🧛', color: 'from-rose-200 to-red-300 text-red-900 border-red-500 dark:from-red-900/60 dark:to-rose-900/40', vi: 'Kẻ Săn Ác Quỷ', viD: 'Đạt Tầng 50 Dungeon' },
        { id: 'd3', type: 'dungeon', req: 100, icon: '☠️', color: 'from-purple-300 to-fuchsia-400 text-purple-900 border-purple-600 shadow-[0_0_20px_rgba(192,38,211,0.5)] dark:from-purple-900 dark:to-fuchsia-900', vi: 'Chúa Tể Hầm Ngục', viD: 'Phá Đảo Tầng 100' },
        
        // Nhóm 6: Thời gian đặc biệt (Cú đêm / Dậy sớm)
        { id: 'h1', type: 'time_early', req: 0, icon: '🌅', color: 'from-sky-50 to-blue-100 text-blue-600 border-blue-200 dark:from-sky-900/30', vi: 'Tinh Sương', viD: 'Học lúc 4h-6h sáng' },
        { id: 'h2', type: 'time_night', req: 0, icon: '🦇', color: 'from-gray-800 to-black text-gray-300 border-gray-600 dark:from-black dark:to-gray-900', vi: 'Chúa Tể Bóng Đêm', viD: 'Học sau 23h đêm' }
    ],

    renderStats: function () {
        if (this.dom.stats?.total) {
            this.dom.stats.total.textContent = this.data ? this.data.length : 0;
        }
        if (!this.data) return;

        const masteredCount = this.data.filter(i => (i.level || 0) >= 5).length;
        if (document.getElementById('dash-stat-mastered')) document.getElementById('dash-stat-mastered').textContent = masteredCount;
        if (document.getElementById('dash-stat-streak')) document.getElementById('dash-stat-streak').textContent = `🔥 ${this.user.streak || 1}`;

        const dueCount = this.data.filter(i => i.nextReview > 0 && i.nextReview <= Date.now()).length;
        if (document.getElementById('dash-due-count')) document.getElementById('dash-due-count').textContent = dueCount;
        if (document.getElementById('dash-dungeon-floor')) document.getElementById('dash-dungeon-floor').textContent = this.user.dungeonFloor || 1;
        
        const dashBg = document.getElementById('dash-avatar-bg');
        if (dashBg) {
            dashBg.textContent = this.user.avatar || '👨‍🎓';
            dashBg.className = dashBg.className.replace(/from-\S+ to-\S+/g, '');
            dashBg.classList.add(...(this.user.avatarBg || 'from-indigo-500 to-purple-600').split(' '));
        }

        const total = this.data.length;
        const currentExp = this.user.exp || 0;
        const level = Math.floor(Math.sqrt(currentExp / 50)) + 1;
        const nextLevelExp = Math.pow(level, 2) * 50;
        const prevLevelExp = Math.pow(level - 1, 2) * 50;
        const expNeeded = nextLevelExp - prevLevelExp;
        const expGained = currentExp - prevLevelExp;
        const xpPercent = Math.min(100, Math.floor((expGained / expNeeded) * 100));

        let rank = { name: 'E-Class Vô Danh', color: 'text-gray-500 bg-gray-100 border-gray-200 dark:text-gray-400 dark:bg-gray-800 dark:border-gray-700' };
        if (level >= 5) rank = { name: 'D-Class Tân Binh', color: 'text-green-600 bg-green-100 border-green-200 dark:text-green-400 dark:bg-green-900/30' };
        if (level >= 15) rank = { name: 'C-Class Thợ Săn', color: 'text-blue-600 bg-blue-100 border-blue-200 dark:text-blue-400 dark:bg-blue-900/30' };
        if (level >= 30) rank = { name: 'B-Class Tinh Anh', color: 'text-purple-600 bg-purple-100 border-purple-200 dark:text-purple-400 dark:bg-purple-900/30' };
        if (level >= 50) rank = { name: 'A-Class Quái Kiệt', color: 'text-orange-600 bg-orange-100 border-orange-200 dark:text-orange-400 dark:bg-orange-900/30' };
        if (level >= 80) rank = { name: 'S-Class Thức Tỉnh', color: 'text-red-600 bg-red-100 border-red-200 shadow-[0_0_15px_rgba(220,38,38,0.4)] dark:text-red-400 dark:bg-red-900/30' };
        if (level >= 100) rank = { name: '👑 Lãnh Chúa Ngôn Ngữ', color: 'text-yellow-400 bg-gray-900 border-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.5)] dark:bg-black dark:border-yellow-600' };

        const rankEl = document.getElementById('profile-rank');
        if (rankEl) {
            rankEl.textContent = rank.name;
            rankEl.className = `text-[10px] md:text-xs font-black px-3 py-1.5 md:px-4 md:py-2 rounded-xl border-2 flex items-center gap-1 uppercase tracking-widest ${rank.color} transition-all`;
        }

        if (document.getElementById('profile-lvl')) {
            document.getElementById('profile-lvl').textContent = level;
            document.getElementById('profile-xp-text').textContent = `${currentExp} / ${nextLevelExp} EXP`;
            document.getElementById('profile-xp-bar').style.width = `${xpPercent}%`;

            if (document.getElementById('profile-streak')) document.getElementById('profile-streak').textContent = `🔥 ${this.user.streak || 1} Streak`;

            let cefr = 'A1 (Beginner)';
            if (level >= 20) cefr = 'A2 (Elementary)';
            if (level >= 40) cefr = 'B1 (Intermediate)';
            if (level >= 60) cefr = 'B2 (Upper Int.)';
            if (level >= 80) cefr = 'C1 (Advanced)';
            if (level >= 100) cefr = 'C2 (Mastery)';
            if (document.getElementById('profile-cefr-badge')) document.getElementById('profile-cefr-badge').textContent = `RANK: ${cefr}`;

            const st = this.user.stats || { str: 0, int: 0, agi: 0, dex: 0, vit: 0, luk: 0 };
            const calcLv = (pts) => Math.floor(Math.sqrt((pts || 0) / 10));

            ['str', 'int', 'agi', 'dex', 'vit', 'luk'].forEach(s => {
                if (document.getElementById(`stat-${s}`)) {
                    const slv = calcLv(st[s]);
                    document.getElementById(`stat-${s}`).textContent = slv;
                    const pct = Math.min(100, (((st[s] || 0) - (Math.pow(slv, 2) * 10)) / (((Math.pow(slv + 1, 2) * 10) - (Math.pow(slv, 2) * 10)))) * 100);
                    document.getElementById(`bar-${s}`).style.width = `${pct}%`;
                }
            });
        }

        if (document.getElementById('profile-level-stats')) {
            const totalW = this.data.length || 1; // Ngăn chia cho 0
            const lv5 = this.data.filter(i => (i.level || 0) >= 5).length;
            const lv4 = this.data.filter(i => (i.level || 0) === 4).length;
            const lv3 = this.data.filter(i => (i.level || 0) === 3).length;
            const lv2 = this.data.filter(i => (i.level || 0) === 2).length;
            const lv1 = this.data.filter(i => (i.level || 0) <= 1).length;

            document.getElementById('lvl-count-5').textContent = lv5;
            document.getElementById('lvl-bar-5').style.width = `${(lv5/totalW)*100}%`;
            
            document.getElementById('lvl-count-4').textContent = lv4;
            document.getElementById('lvl-bar-4').style.width = `${(lv4/totalW)*100}%`;

            document.getElementById('lvl-count-3').textContent = lv3;
            document.getElementById('lvl-bar-3').style.width = `${(lv3/totalW)*100}%`;

            document.getElementById('lvl-count-2').textContent = lv2;
            document.getElementById('lvl-bar-2').style.width = `${(lv2/totalW)*100}%`;

            document.getElementById('lvl-count-1').textContent = lv1;
            document.getElementById('lvl-bar-1').style.width = `${(lv1/totalW)*100}%`;
        }

        if (document.getElementById('profile-recent-achievements')) {
            const currentHour = new Date().getHours();
            const mockCount = this.mockHistory ? this.mockHistory.length : 0;
            const streakCount = this.user.streak || 0;
            const dungeonFloor = this.user.dungeonFloor || 1;

            let unlockedList = [];
            
            this.achievementsSystem.forEach(ach => {
                let isUnlocked = false;
                if (ach.type === 'streak') isUnlocked = streakCount >= ach.req;
                else if (ach.type === 'words') isUnlocked = total >= ach.req;
                else if (ach.type === 'mastered') isUnlocked = masteredCount >= ach.req;
                else if (ach.type === 'mock') isUnlocked = mockCount >= ach.req;
                else if (ach.type === 'dungeon') isUnlocked = dungeonFloor >= ach.req;
                else if (ach.type === 'time_early') isUnlocked = currentHour >= 4 && currentHour <= 6;
                else if (ach.type === 'time_night') isUnlocked = currentHour >= 23 || currentHour <= 2;

                if (isUnlocked) unlockedList.push(ach);
            });

            if (document.getElementById('profile-ach-unlocked')) document.getElementById('profile-ach-unlocked').textContent = unlockedList.length;
            if (document.getElementById('profile-ach-total')) document.getElementById('profile-ach-total').textContent = this.achievementsSystem.length;

            // Lấy 3 thành tựu mới nhất (đảo ngược mảng để lấy cái gần nhất)
            const recent3 = unlockedList.reverse().slice(0, 3);
            
            let recentHtml = recent3.map(ach => `
                <div class="flex flex-col items-center p-2 rounded-xl bg-gradient-to-br ${ach.color} border border-white/20 shadow-sm relative overflow-hidden group hover:scale-105 transition cursor-help" title="${ach.viD}">
                    <div class="text-2xl mb-1 relative z-10 group-hover:animate-bounce">${ach.icon}</div>
                    <div class="text-[9px] font-black text-gray-800 dark:text-white text-center leading-tight relative z-10 truncate w-full px-1">${ach.vi}</div>
                </div>
            `).join('');

            // Điền chỗ trống nếu chưa đủ 3 thành tựu
            for(let i = recent3.length; i < 3; i++) {
                recentHtml += `
                    <div class="flex flex-col items-center p-2 rounded-xl bg-gray-50 dark:bg-gray-900/50 border border-gray-100 dark:border-gray-800 opacity-50 grayscale">
                        <div class="text-2xl mb-1">🔒</div>
                        <div class="text-[9px] font-bold text-gray-400 text-center">Chưa mở</div>
                    </div>
                `;
            }

            document.getElementById('profile-recent-achievements').innerHTML = recentHtml;
        }
    },

    // ==========================================
    // 3. HỆ THỐNG NHIỆM VỤ (QUEST ENGINE)
    // ==========================================
    questPool: [
        { id: 'q1', type: 'study', target: 15, title: 'Khởi Động Não Bộ', desc: 'Ôn tập 15 thẻ từ vựng bất kỳ', exp: 100, icon: '🧠', color: 'text-blue-500 bg-blue-50 dark:bg-blue-900/30 dark:text-blue-400' },
        { id: 'q2', type: 'arena', target: 3, title: 'Chiến Binh Hầm Ngục', desc: 'Thắng 3 lượt đấu với quái vật', exp: 150, icon: '⚔️', color: 'text-red-500 bg-red-50 dark:bg-red-900/30 dark:text-red-400' },
        { id: 'q3', type: 'ai', target: 1, title: 'Nhà Sáng Tạo', desc: 'Dùng AI tạo 1 bộ từ vựng mới', exp: 200, icon: '✨', color: 'text-purple-500 bg-purple-50 dark:bg-purple-900/30 dark:text-purple-400' },
        { id: 'q4', type: 'speak', target: 5, title: 'Luyện Giọng Bản Xứ', desc: 'Nói đúng 5 câu (Shadowing/Tavern)', exp: 120, icon: '🎙️', color: 'text-orange-500 bg-orange-50 dark:bg-orange-900/30 dark:text-orange-400' },
        { id: 'q5', type: 'quiz', target: 1, title: 'Kiểm Tra Nhanh', desc: 'Hoàn thành 1 bài Quiz trắc nghiệm', exp: 80, icon: '📝', color: 'text-pink-500 bg-pink-50 dark:bg-pink-900/30 dark:text-pink-400' },
        { id: 'q6', type: 'mock', target: 1, title: 'Thử Thách IELTS', desc: 'Hoàn thành 1 bài thi Mock Test', exp: 250, icon: '🏆', color: 'text-amber-500 bg-amber-50 dark:bg-amber-900/30 dark:text-amber-400' },
        { id: 'q7', type: 'study', target: 30, title: 'Kẻ Cuồng Học', desc: 'Lật và học 30 thẻ từ vựng', exp: 180, icon: '🔥', color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 dark:text-indigo-400' }
    ],

    initDailyQuests: function (today) {
        if (this.user.questDate !== today) {
            const shuffled = [...this.questPool].sort(() => 0.5 - Math.random()).slice(0, 3);
            this.user.quests = shuffled.map(q => ({ ...q, progress: 0, claimed: false }));
            this.user.questDate = today;
            this.saveUserData();
        }
    },

    renderDailyQuests: function () {
        const board = document.getElementById('quest-board');
        if (!board || !this.user.quests) return;

        board.innerHTML = this.user.quests.map((q, idx) => {
            const isDone = q.progress >= q.target;
            const progressPercent = Math.min(100, (q.progress / q.target) * 100);

            let navAction = "app.navigate('study')";
            if (q.type === 'arena') navAction = "app.startArena()";
            else if (q.type === 'ai') navAction = "app.toggleAiModal()";
            else if (q.type === 'speak') navAction = "app.navigate('listening')";
            else if (q.type === 'quiz') navAction = "app.navigate('quiz')";
            else if (q.type === 'mock') navAction = "app.navigate('mocktest')";

            let actionBtn = `<button onclick="${navAction}" class="px-4 py-2.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-xl text-xs font-bold w-full md:w-auto dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-600 dark:hover:text-white transition-all shadow-sm">Làm ngay ➔</button>`;

            if (isDone && !q.claimed) {
                actionBtn = `<button onclick="app.claimQuest(${idx})" class="px-4 py-2.5 bg-gradient-to-r from-emerald-400 to-green-500 text-white rounded-xl text-xs font-black shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:scale-95 transition-all w-full md:w-auto animate-pulse flex items-center justify-center gap-1"><span class="text-sm">✨</span> Nhận ${q.exp} EXP</button>`;
            } else if (q.claimed) {
                actionBtn = `<button disabled class="px-4 py-2.5 bg-emerald-50 text-emerald-500 border border-emerald-100 rounded-xl text-xs font-bold w-full md:w-auto dark:bg-emerald-900/20 dark:border-emerald-800/50 dark:text-emerald-400">Đã nhận ✅</button>`;
            }

            return `
            <div class="bg-white p-4 rounded-2xl shadow-sm border ${isDone && !q.claimed ? 'border-emerald-300 shadow-emerald-100 dark:border-emerald-600/50' : 'border-gray-100 dark:border-gray-700'} flex flex-col md:flex-row items-start md:items-center gap-4 dark:bg-gray-800 transition-all hover:shadow-md">
                <div class="w-12 h-12 shrink-0 rounded-xl flex items-center justify-center text-2xl ${q.color}">${q.icon}</div>
                <div class="flex-1 w-full">
                    <h4 class="font-bold text-gray-800 text-sm dark:text-white">${q.title}</h4>
                    <p class="text-[11px] text-gray-500 mt-0.5 dark:text-gray-400">${q.desc}</p>
                    <div class="mt-2.5 flex items-center gap-3">
                        <div class="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden dark:bg-gray-700 shadow-inner">
                            <div class="h-full ${isDone ? 'bg-emerald-500' : 'bg-gradient-to-r from-blue-500 to-primary'} transition-all duration-1000 ease-out relative" style="width: ${progressPercent}%">
                                <div class="absolute inset-0 bg-white/20 w-full animate-[shimmer_2s_infinite]"></div>
                            </div>
                        </div>
                        <span class="text-[10px] font-black ${isDone ? 'text-emerald-500' : 'text-gray-500 dark:text-gray-400'} w-8 text-right">${q.progress}/${q.target}</span>
                    </div>
                </div>
                <div class="w-full md:w-auto mt-3 md:mt-0 shrink-0">
                    ${actionBtn}
                </div>
            </div>`;
        }).join('');
    },

    fireConfetti: function () {
        const colors = ['#4F46E5', '#10B981', '#F59E0B', '#EC4899', '#3B82F6'];
        for (let i = 0; i < 40; i++) {
            const confetti = document.createElement('div');
            confetti.style.position = 'fixed';
            confetti.style.width = Math.random() * 8 + 4 + 'px';
            confetti.style.height = Math.random() * 8 + 4 + 'px';
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.top = '50%';
            confetti.style.left = '50%';
            confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
            confetti.style.zIndex = '9999';
            confetti.style.pointerEvents = 'none';
            document.body.appendChild(confetti);

            const angle = Math.random() * Math.PI * 2;
            const velocity = 5 + Math.random() * 15;
            const tx = Math.cos(angle) * velocity * 20;
            const ty = Math.sin(angle) * velocity * 20 + 100;

            confetti.animate([
                { transform: 'translate(-50%, -50%) rotate(0deg)', opacity: 1 },
                { transform: `translate(calc(-50% + ${tx}px), calc(-50% + ${ty}px)) rotate(${Math.random() * 720}deg)`, opacity: 0 }
            ], { duration: 1000 + Math.random() * 1000, easing: 'cubic-bezier(.37,0,.23,1)' });

            setTimeout(() => confetti.remove(), 2000);
        }
    },

    checkDailyQuests: function () {
        if (!this.user) this.user = {};
        const today = new Date().toDateString();
        const isDataCorrupted = this.user.quests && this.user.quests.some(q => q.target === undefined || q.current === undefined);

        if (this.user.lastQuestDate !== today || !this.user.quests || isDataCorrupted) {
            this.user.lastQuestDate = today;
            this.user.quests = [
                { id: 'q1', type: 'study', title: 'Học giả chăm chỉ', desc: 'Lật và học 20 thẻ từ vựng', target: 20, current: 0, exp: 50, claimed: false, icon: '🃏' },
                { id: 'q2', type: 'quiz', title: 'Thợ săn Hầm ngục', desc: 'Đánh trúng Boss / Trả lời đúng 10 câu', target: 10, current: 0, exp: 80, claimed: false, icon: '⚔️' },
                { id: 'q3', type: 'grammar', title: 'Bậc thầy Ngữ pháp', desc: 'Hoàn thành 1 bài test Ngữ pháp', target: 1, current: 0, exp: 100, claimed: false, icon: '🧙‍♂️' },
                { id: 'q4', type: 'listen', title: 'Đôi tai nhạy bén', desc: 'Bấm nghe phát âm từ vựng 15 lần', target: 15, current: 0, exp: 60, claimed: false, icon: '🎧' }
            ];
            this.saveUserData();
        }
    },

    renderQuests: function () {
        this.checkDailyQuests();
        const board = document.getElementById('quest-board-inner');

        let hasUnclaimed = false;
        if (this.user && this.user.quests) {
            hasUnclaimed = this.user.quests.some(q => q.current >= q.target && !q.claimed);
        }

        const dot1 = document.getElementById('quest-noti-dot');
        const dot2 = document.getElementById('quest-noti-dot-core');
        if (dot1 && dot2) {
            if (hasUnclaimed) {
                dot1.classList.remove('hidden'); dot2.classList.remove('hidden');
            } else {
                dot1.classList.add('hidden'); dot2.classList.add('hidden');
            }
        }

        if (!board) return;

        board.innerHTML = this.user.quests.map((q) => {
            const isDone = q.current >= q.target;
            const percent = Math.min(100, (q.current / q.target) * 100);

            let actionHtml = '';
            
            let navAction = "app.navigate('study'); app.toggleQuestModal();";
            if (q.type === 'arena') navAction = "app.startArena(); app.toggleQuestModal();";
            else if (q.type === 'grammar') navAction = "app.navigate('grammar'); app.toggleQuestModal();";
            else if (q.type === 'listen') navAction = "app.navigate('listening'); app.toggleQuestModal();";
            else if (q.type === 'quiz') navAction = "app.navigate('quiz'); app.toggleQuestModal();";
            else if (q.type === 'mock') navAction = "app.navigate('mocktest'); app.toggleQuestModal();";
            else if (q.type === 'ai') navAction = "app.toggleAiModal(); app.toggleQuestModal();";

            if (q.claimed) {
                actionHtml = `<div class="text-[10px] font-black text-gray-400 bg-gray-100 dark:bg-gray-700/50 px-3 py-1.5 rounded-lg text-center uppercase tracking-widest border border-gray-200 dark:border-gray-600 shadow-inner">ĐÃ HOÀN THÀNH</div>`;
            } else if (isDone) {
                actionHtml = `<button onclick="app.claimQuest('${q.id}'); app.toggleQuestModal();" class="w-full py-2 bg-gradient-to-r from-emerald-400 to-green-500 text-white rounded-xl text-xs font-black shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:scale-95 transition-all animate-pulse flex items-center justify-center gap-1 uppercase tracking-widest"><span class="text-sm">✨</span> Nhận Thưởng</button>`;
            } else {
                actionHtml = `
                    <div class="flex justify-between items-center text-[9px] font-bold text-gray-500 dark:text-gray-400 mb-1.5">
                        <span>Tiến độ</span>
                        <span>${q.current} / ${q.target}</span>
                    </div>
                    <div class="w-full bg-gray-100 dark:bg-gray-700 rounded-full h-1.5 overflow-hidden shadow-inner mb-2.5">
                        <div class="bg-gradient-to-r from-indigo-400 to-primary h-full rounded-full transition-all duration-500 shadow-[0_0_5px_rgba(79,70,229,0.5)]" style="width: ${percent}%"></div>
                    </div>
                    <button onclick="${navAction}" class="w-full py-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-600 dark:hover:text-white font-bold text-xs rounded-xl border border-indigo-100 dark:border-indigo-800/50 uppercase tracking-widest transition-all shadow-sm">Làm ngay ➔</button>
                `;
            }

            return `
            <div class="bg-white dark:bg-gray-800 p-3 md:p-4 rounded-2xl border ${isDone && !q.claimed ? 'border-yellow-400 shadow-md shadow-yellow-400/10' : 'border-gray-100 dark:border-gray-700'} flex flex-col justify-between gap-3 relative overflow-hidden group transition-all hover:-translate-y-0.5 hover:shadow-lg">
                ${q.claimed ? '<div class="absolute inset-0 bg-gray-50/60 dark:bg-gray-900/60 z-10 backdrop-blur-[1px]"></div>' : ''}
                <div class="flex items-start gap-3 relative z-20">
                    <div class="w-10 h-10 rounded-xl bg-gray-50 dark:bg-gray-700/50 flex items-center justify-center text-xl shrink-0 border border-gray-100 dark:border-gray-600 shadow-sm group-hover:scale-110 group-hover:rotate-6 transition-transform">${q.icon}</div>
                    <div class="flex-1 min-w-0">
                        <div class="flex justify-between items-start gap-1">
                            <h4 class="font-black text-gray-800 dark:text-white text-sm leading-tight truncate">${q.title}</h4>
                            <span class="text-[9px] font-black text-yellow-600 dark:text-yellow-400 bg-yellow-100 dark:bg-yellow-900/30 px-1.5 py-0.5 rounded shadow-sm shrink-0">+${q.exp} EXP</span>
                        </div>
                        <p class="text-[10px] text-gray-500 dark:text-gray-400 font-medium leading-snug mt-1 line-clamp-2">${q.desc}</p>
                    </div>
                </div>
                <div class="mt-auto relative z-20 pt-1">
                    ${actionHtml}
                </div>
            </div>`;
        }).join('');
    },

    toggleQuestModal: function () {
        const modal = document.getElementById('modal-quests');
        if (!modal) return;

        if (modal.classList.contains('hidden')) {
            modal.classList.replace('hidden', 'flex');
            setTimeout(() => {
                modal.classList.remove('opacity-0');
                modal.children[0].classList.remove('scale-95');
            }, 10);
            this.renderQuests();
        } else {
            modal.classList.add('opacity-0');
            modal.children[0].classList.add('scale-95');
            setTimeout(() => modal.classList.replace('flex', 'hidden'), 300);
        }
    },

    updateQuest: function (type, amount) {
        if (!this.user || !this.user.quests) return;
        let updated = false;

        this.user.quests.forEach(q => {
            if (q.type === type && !q.claimed && q.current < q.target) {
                q.current = Math.min(q.target, q.current + amount);
                updated = true;
                if (q.current === q.target) {
                    this.toast(`🎉 Nhiệm vụ "${q.title}" đã hoàn thành! Ra Trang chủ nhận thưởng.`, "success");
                    this.playSound('crit');
                }
            }
        });

        if (updated) {
            this.saveUserData();
            this.renderQuests();
        }
    },

    claimQuest: function (questId) {
        const quest = this.user.quests.find(q => q.id === questId);
        if (!quest || quest.claimed || quest.current < quest.target) return;

        quest.claimed = true;
        this.saveUserData();
        this.renderQuests();
        this.gainExp(quest.exp);

        this.toast(`🎁 Đã nhận ${quest.exp} EXP từ Bảng Ủy Thác!`, "success");
        this.playSound('correct');
    },


    // ==========================================
    // 4. HỒ SƠ & CÀI ĐẶT (PROFILE & SETTINGS)
    // ==========================================
    toggleVoiceModal: function () {
        const m = document.getElementById('modal-voice');
        if (m) {
            m.classList.toggle('hidden');
            m.classList.toggle('flex');

            if (!m.classList.contains('hidden')) {
                const modeEl = document.getElementById('setting-voice-mode');
                const langEl = document.getElementById('setting-voice-lang');
                const speedEl = document.getElementById('setting-voice-speed');
                if (modeEl) modeEl.value = this.user.voiceMode || 'real';
                if (langEl) langEl.value = this.user.voiceLang || 'en-US';
                if (speedEl) speedEl.value = this.user.voiceSpeed || '1.0';

                const elKey = document.getElementById('setting-eleven-key');
                const elVoice = document.getElementById('setting-eleven-voice');
                const elCustom = document.getElementById('setting-eleven-custom');
                if (elKey) elKey.value = this.user.elevenKey || '';

                const savedVoice = this.user.elevenVoice || 'pFZP5JQG7iQjIQuC4Bku';
                const predefinedOpts = ['pFZP5JQG7iQjIQuC4Bku', '21m00Tcm4TlvDq8ikWAM', 'EXAVITQu4vr4xnSDxMaL', 'ThT5KcBeYPX3keUQqHPh'];

                if (elVoice && elCustom) {
                    if (predefinedOpts.includes(savedVoice)) {
                        elVoice.value = savedVoice;
                        elCustom.style.display = 'none';
                        elCustom.value = '';
                    } else {
                        elVoice.value = 'custom';
                        elCustom.style.display = 'block';
                        elCustom.value = savedVoice;
                    }
                }
            }
        }
    },

    renderProfileHeader: function () {
        if (document.getElementById('setting-voice-mode')) {
            document.getElementById('setting-voice-mode').value = this.user.voiceMode || 'real';
            document.getElementById('setting-voice-lang').value = this.user.voiceLang || 'en-US';
            document.getElementById('setting-voice-speed').value = this.user.voiceSpeed || '1.0';
        }

        const langMapVi = { 'en-US': '🇺🇸 Mỹ (US)', 'en-GB': '🇬🇧 Anh (UK)', 'en-AU': '🇦🇺 Úc (AU)', 'en-IN': '🇮🇳 Ấn Độ', 'en-IE': '🍀 Ireland', 'en-ZA': '🇿🇦 Nam Phi', 'zh-CN': '🇨🇳 Tiếng Trung', 'zh-TW': '🇹🇼 Đài Loan', 'ja-JP': '🇯🇵 Tiếng Nhật', 'ko-KR': '🇰🇷 Tiếng Hàn' };
        const langMapEn = { 'en-US': '🇺🇸 US Accent', 'en-GB': '🇬🇧 UK Accent', 'en-AU': '🇦🇺 AU Accent', 'en-IN': '🇮🇳 IN Accent', 'en-IE': '🍀 IE Accent', 'en-ZA': '🇿🇦 ZA Accent', 'zh-CN': '🇨🇳 Chinese', 'zh-TW': '🇹🇼 Taiwanese', 'ja-JP': '🇯🇵 Japanese', 'ko-KR': '🇰🇷 Korean' };

        const voiceDisplay = document.getElementById('current-voice-display');
        if (voiceDisplay) {
            const mapToUse = this.lang === 'vi' ? langMapVi : langMapEn;
            voiceDisplay.textContent = mapToUse[this.user.voiceLang || 'en-US'] || (this.lang === 'vi' ? '🇺🇸 Mỹ (US)' : '🇺🇸 US Accent');
        }

        ['dash-name', 'profile-name', 'sidebar-name'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.textContent = this.user.name;
        });

        const bgClass = this.user.avatarBg || 'from-indigo-500 to-purple-600';
        const char = this.user.avatar || '👨‍🎓';

        ['profile-avatar', 'sidebar-avatar', 'dash-avatar-bg'].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.textContent = char;
                el.className = el.className.replace(/from-\S+ to-\S+/g, '');
                el.classList.add(...bgClass.split(' '));
            }
        });
    },

    toggleProfileModal: function () {
        const modal = document.getElementById('modal-profile');
        modal.classList.toggle('hidden'); modal.classList.toggle('flex');
    },

    openProfileModal: function () {
        this.state.tempProfile = {
            char: this.user.avatar || '👨‍🎓',
            bg: this.user.avatarBg || 'from-indigo-500 to-purple-600'
        };
        document.getElementById('edit-name').value = this.user.name;
        this.renderAvatarStudio();
        this.toggleProfileModal();
    },

    renderAvatarStudio: function () {
        const chars = ['👨‍🎓', '👩‍🎓', '🧑‍💻', '🚀', '🤖', '🐱', '🐯', '🦄', '🐲', '👽', '🔥', '🍀', '⚡', '💎', '🎧'];
        const bgs = [
            'from-indigo-500 to-purple-600', 'from-blue-400 to-blue-600', 'from-emerald-400 to-green-600',
            'from-orange-400 to-red-500', 'from-pink-500 to-rose-500', 'from-slate-700 to-slate-900',
            'from-yellow-400 to-orange-500', 'from-teal-400 to-cyan-500', 'from-fuchsia-500 to-pink-500', 'from-gray-200 to-gray-400'
        ];

        document.getElementById('avatar-grid-char').innerHTML = chars.map(c => `
            <div onclick="app.updateTempProfile('char', '${c}')" class="h-10 w-10 flex items-center justify-center text-2xl bg-gray-50 rounded-lg cursor-pointer hover:scale-110 transition ${c === this.state.tempProfile.char ? 'ring-2 ring-primary bg-indigo-50' : ''}">${c}</div>
        `).join('');

        document.getElementById('avatar-grid-bg').innerHTML = bgs.map(bg => `
            <div onclick="app.updateTempProfile('bg', '${bg}')" class="h-10 w-10 rounded-full cursor-pointer hover:scale-110 transition ring-offset-1 ${bg === this.state.tempProfile.bg ? 'ring-2 ring-gray-800 scale-110' : ''} bg-gradient-to-br ${bg}"></div>
        `).join('');

        document.getElementById('preview-avatar-char').textContent = this.state.tempProfile.char;
        const pBg = document.getElementById('preview-avatar-bg');
        pBg.className = pBg.className.replace(/from-\S+ to-\S+/g, '');
        pBg.classList.add(...this.state.tempProfile.bg.split(' '));
    },

    updateTempProfile: function (type, val) {
        this.state.tempProfile[type] = val;
        this.renderAvatarStudio();
    },

    saveProfile: function () {
        const newName = document.getElementById('edit-name').value.trim();
        if (!newName) return this.toast("Tên không được để trống!", "error");

        this.user.name = newName;
        this.user.avatar = this.state.tempProfile.char;
        this.user.avatarBg = this.state.tempProfile.bg;

        this.saveUserData();
        this.renderProfileHeader();
        this.toggleProfileModal();
        this.toast("Hồ sơ mới đã được lưu! ✨");
    },

    testVoice: function (event) {
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        const lang = document.getElementById('setting-voice-lang').value;
        const speed = parseFloat(document.getElementById('setting-voice-speed').value);
        const btn = event ? event.currentTarget : document.getElementById('setting-voice-lang');
        const msg = new SpeechSynthesisUtterance("Flashcard Pro is ready!");

        btn.classList.add('animate-pulse');
        msg.lang = lang;

        let finalRate = 0.85;
        if (speed === 0.8) finalRate = 0.7;
        if (speed <= 0.6) finalRate = 0.5;
        msg.rate = finalRate;

        let voices = window.speechSynthesis.getVoices();
        let bestVoice = voices.find(v => v.lang.replace('_', '-') === lang && (v.name.includes('Google') || v.name.includes('Premium') || v.name.includes('Siri')));
        if (!bestVoice) bestVoice = voices.find(v => v.lang.replace('_', '-') === lang);
        if (bestVoice) msg.voice = bestVoice;

        msg.onend = () => btn.classList.remove('animate-pulse');

        setTimeout(() => window.speechSynthesis.speak(msg), 10);

        if (!bestVoice) this.toast("Máy không có sẵn gói giọng, dùng tạm giọng gốc!", "info");
    },

    saveVoiceSettings: function () {
        this.user.voiceMode = document.getElementById('setting-voice-mode').value;
        this.user.voiceLang = document.getElementById('setting-voice-lang').value;
        this.user.voiceSpeed = document.getElementById('setting-voice-speed').value;

        const elKey = document.getElementById('setting-eleven-key');
        const elVoice = document.getElementById('setting-eleven-voice');
        const elCustom = document.getElementById('setting-eleven-custom');

        if (elKey) this.user.elevenKey = elKey.value.trim();
        if (elVoice) {
            this.user.elevenVoice = elVoice.value === 'custom' ? elCustom.value.trim() : elVoice.value;
        }

        this.saveUserData();
        this.renderProfileHeader();
        this.toggleVoiceModal();
        this.toast("Đã lưu thiết lập Giọng Đọc & ElevenLabs!");
    },

    // ==========================================
    // 5. TRỢ THỦ ANIME (MASCOT COMPANION)
    // ==========================================
    mascotQuotes: [
        { text: "Ganbatte kudasai! (Cố lên Chủ nhân!) 🌟", speech: "がんばってください、ご主人様", lang: "ja-JP", vId: "Azl39N9V6vS7u9Nkh5yO" },
        { text: "Tuturu~ (Bé tới đây!) 🎵", speech: "トゥットゥルー", lang: "ja-JP", vId: "Azl39N9V6vS7u9Nkh5yO" },
        { text: "Onii-chan! (Học tiếp đi anh!) 💕", speech: "お兄ちゃん、がんばって", lang: "ja-JP", vId: "Azl39N9V6vS7u9Nkh5yO" },
        { text: "Sugoi! (Chủ nhân đỉnh quá!) ✨", speech: "すごい", lang: "ja-JP", vId: "Azl39N9V6vS7u9Nkh5yO" },
        { text: "Chủ nhân mệt chưa? Ráng học thêm chút xíu nha! 💖", speech: "Chủ nhân mệt chưa? Ráng học thêm chút xíu nha!", lang: "vi-VN", vId: "pFZP5JQG7iQjIQuC4Bku" },
        { text: "Hôm nay chủ nhân học giỏi quá đi à! 💕", speech: "Hôm nay chủ nhân học giỏi quá đi à!", lang: "vi-VN", vId: "pFZP5JQG7iQjIQuC4Bku" },
        { text: "Đừng có lười biếng nha, bé buồn đó! 🐾", speech: "Đừng có lười biếng nha, bé buồn đó!", lang: "vi-VN", vId: "pFZP5JQG7iQjIQuC4Bku" }
    ],

    mascotImages: [
        'https://raw.githubusercontent.com/AzurAPI/azurapi-js-setup/master/images/skins/019/chibi.png',
        'https://raw.githubusercontent.com/AzurAPI/azurapi-js-setup/master/images/skins/025/chibi.png',
        'https://raw.githubusercontent.com/AzurAPI/azurapi-js-setup/master/images/skins/035/chibi.png',
        'https://raw.githubusercontent.com/AzurAPI/azurapi-js-setup/master/images/skins/045/chibi.png',
        'https://raw.githubusercontent.com/AzurAPI/azurapi-js-setup/master/images/skins/055/chibi.png'
    ],

    pokeMascot: async function (isGreeting = false) {
        const speechBox = document.getElementById('mascot-speech');
        if (!speechBox) return;

        let quoteObj;
        if (!isGreeting) {
            quoteObj = this.mascotQuotes[Math.floor(Math.random() * this.mascotQuotes.length)];
        } else {
            quoteObj = { text: "Okaeri! Mừng Chủ nhân về nhà! (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧", speech: "おかえりなさい、ご主人様", lang: "ja-JP", vId: "Azl39N9V6vS7u9Nkh5yO" };
        }

        speechBox.textContent = quoteObj.text;
        speechBox.classList.remove('opacity-0');
        speechBox.classList.add('opacity-100', 'animate-pop-in');

        if (this.mascotTimer) clearTimeout(this.mascotTimer);
        this.mascotTimer = setTimeout(() => {
            speechBox.classList.remove('opacity-100', 'animate-pop-in');
            speechBox.classList.add('opacity-0');
        }, 3500);

        const apiKey = this.user.elevenKey;
        if (apiKey && apiKey.length > 20) {
            try {
                const vId = quoteObj.vId || 'pFZP5JQG7iQjIQuC4Bku';
                const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${vId}?output_format=mp3_44100_128`, {
                    method: 'POST',
                    headers: { 'xi-api-key': apiKey, 'Content-Type': 'application/json', 'accept': 'audio/mpeg' },
                    body: JSON.stringify({
                        text: quoteObj.text,
                        model_id: "eleven_turbo_v2_5",
                        voice_settings: { stability: 0.4, similarity_boost: 0.8, style: 0.0, use_speaker_boost: true }
                    })
                });

                if (response.ok) {
                    const blob = await response.blob();
                    const audio = new Audio(URL.createObjectURL(blob));
                    audio.play().catch(e => { });
                    return;
                }
            } catch (err) { }
        }

        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            const msg = new SpeechSynthesisUtterance(quoteObj.speech);
            msg.lang = quoteObj.lang;
            const voices = window.speechSynthesis.getVoices();
            let targetVoice = voices.find(v => v.lang.includes(quoteObj.lang.split('-')[0]) && (v.name.includes('Female') || v.name.includes('Google') || v.name.includes('Linh')));
            if (targetVoice) msg.voice = targetVoice;
            msg.pitch = quoteObj.lang === 'ja-JP' ? 1.8 : 1.4;
            msg.rate = 1.2;
            window.speechSynthesis.speak(msg);
        }
    },

    updateMascotImage: function () {
        const imgEl = document.getElementById('mascot-image');
        if (imgEl && this.mascotImages.length > 0) {
            const randomImg = this.mascotImages[Math.floor(Math.random() * this.mascotImages.length)];
            imgEl.src = randomImg;
        }
    },

    // ==========================================
    // MODULE: HỆ THỐNG THÀNH TỰU (ACHIEVEMENTS)
    // ==========================================
    toggleAchievementModal: function () {
        const modal = document.getElementById('modal-achievements');
        if (!modal) return;

        if (modal.classList.contains('hidden')) {
            modal.classList.replace('hidden', 'flex');
            // Đợi 10ms để trình duyệt render display:flex trước khi kích hoạt transition opacity
            setTimeout(() => {
                modal.classList.remove('opacity-0');
                modal.children[0].classList.remove('scale-95');
            }, 10);
            
            // Gọi hàm render dữ liệu thành tựu mỗi khi mở modal
            this.renderAchievementBoard();
        } else {
            modal.classList.add('opacity-0');
            modal.children[0].classList.add('scale-95');
            // Đợi animation đóng xong mới ẩn hoàn toàn element
            setTimeout(() => modal.classList.replace('flex', 'hidden'), 300);
        }
    },

    renderAchievementBoard: function () {
        const board = document.getElementById('achievement-board-content');
        if (!board) return;

        // Lấy các chỉ số hiện tại của User
        const currentHour = new Date().getHours();
        const mockCount = this.mockHistory ? this.mockHistory.length : 0;
        const streakCount = this.user.streak || 0;
        const masteredCount = this.data ? this.data.filter(i => (i.level || 0) >= 5).length : 0;
        const totalWords = this.data ? this.data.length : 0;
        const dungeonFloor = this.user.dungeonFloor || 1;

        let unlockedCount = 0;

        // Quét qua mảng achievementsSystem để đối chiếu với tiến độ
        board.innerHTML = this.achievementsSystem.map((ach, index) => {
            let isUnlocked = false;
            if (ach.type === 'streak') isUnlocked = streakCount >= ach.req;
            else if (ach.type === 'words') isUnlocked = totalWords >= ach.req;
            else if (ach.type === 'mastered') isUnlocked = masteredCount >= ach.req;
            else if (ach.type === 'mock') isUnlocked = mockCount >= ach.req;
            else if (ach.type === 'dungeon') isUnlocked = dungeonFloor >= ach.req;
            else if (ach.type === 'time_early') isUnlocked = currentHour >= 4 && currentHour <= 6;
            else if (ach.type === 'time_night') isUnlocked = currentHour >= 23 || currentHour <= 2;

            if (isUnlocked) unlockedCount++;

            const delay = Math.min(index * 20, 300);

            // Giao diện nếu ĐÃ MỞ KHÓA
            if (isUnlocked) {
                return `
                <div style="animation-delay: ${delay}ms" class="animate-fade-in-up flex items-center p-4 bg-white dark:bg-gray-800 rounded-2xl border-2 border-gray-100 dark:border-gray-700 shadow-sm relative overflow-hidden group">
                    <div class="absolute inset-0 bg-gradient-to-r ${ach.color.replace(/text-[a-z0-9-]+/g, '')} opacity-10 pointer-events-none"></div>
                    <div class="w-14 h-14 shrink-0 rounded-2xl bg-gradient-to-br ${ach.color} flex items-center justify-center text-3xl border-2 mr-4 relative z-10 shadow-sm group-hover:scale-110 group-hover:rotate-6 transition-transform">
                        ${ach.icon}
                    </div>
                    <div class="flex-1 min-w-0 relative z-10">
                        <h4 class="font-black text-gray-800 dark:text-white text-base leading-tight mb-0.5 truncate">${ach.vi}</h4>
                        <p class="text-[11px] text-gray-500 dark:text-gray-400 font-bold tracking-wide">${ach.viD}</p>
                    </div>
                    <div class="shrink-0 ml-2 relative z-10">
                        <span class="text-green-500 bg-green-50 dark:bg-green-900/30 dark:text-green-400 p-2 rounded-full flex items-center justify-center shadow-sm">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path></svg>
                        </span>
                    </div>
                </div>`;
            } 
            // Giao diện nếu CHƯA MỞ KHÓA
            else {
                return `
                <div style="animation-delay: ${delay}ms" class="animate-fade-in-up flex items-center p-4 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border-2 border-dashed border-gray-200 dark:border-gray-800 opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0 group">
                    <div class="w-14 h-14 shrink-0 rounded-2xl bg-gray-200 dark:bg-gray-800 flex items-center justify-center text-3xl border-2 border-gray-300 dark:border-gray-700 mr-4 text-gray-400">
                        🔒
                    </div>
                    <div class="flex-1 min-w-0">
                        <h4 class="font-bold text-gray-500 dark:text-gray-400 text-sm leading-tight mb-0.5 truncate">Chưa Mở Khóa</h4>
                        <p class="text-[11px] text-gray-400 dark:text-gray-500 font-medium">Yêu cầu: ${ach.viD}</p>
                    </div>
                </div>`;
            }
        }).join('');

        // Cập nhật số đếm lên Giao diện
        const elUnlocked = document.getElementById('achievements-unlocked-count');
        const elTotal = document.getElementById('achievements-total-count');
        if (elUnlocked) elUnlocked.textContent = unlockedCount;
        if (elTotal) elTotal.textContent = this.achievementsSystem.length;
    }
});