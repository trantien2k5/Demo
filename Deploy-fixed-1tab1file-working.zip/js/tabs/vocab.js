/**
 * FLASHCARD PRO - STUDY MODULE
 * Module này quản lý chế độ Học Từ Vựng (Study Mode), 
 * bao gồm render danh sách chủ đề học, lật thẻ nhớ (Flashcard),
 * và các thuật toán đánh giá/nhồi từ (Smart Auto-SRS).
 */

Object.assign(app, {

    // ==========================================
    // 1. RENDER CHỦ ĐỀ HỌC (TOPICS)
    // ==========================================
    renderTopics: function () {
        const query = (document.getElementById('topic-search')?.value || '').toLowerCase();
        const sortMode = document.getElementById('topic-sort')?.value || 'recent';

        const groups = this.data.reduce((acc, item) => {
            const t = item.topic || 'General';
            if (!acc[t]) acc[t] = { total: 0, totalLevel: 0, desc: item.topicDesc || 'Luyện tập bộ thẻ này để nâng cao phản xạ tiếng Anh.' };
            acc[t].total++;
            acc[t].totalLevel += Math.min(item.level || 0, 5);
            if (item.isImported) acc[t].isImported = true;
            return acc;
        }, {});

        let topicArr = Object.entries(groups).map(([topic, data]) => ({ topic, ...data }));

        if (query) {
            topicArr = topicArr.filter(t => t.topic.toLowerCase().includes(query));
        }

        const lastStudied = this.user?.lastStudiedTopic || '';
        topicArr.sort((a, b) => {
            if (sortMode === 'recent') {
                if (a.topic === lastStudied) return -1;
                if (b.topic === lastStudied) return 1;
                return b.total - a.total;
            }
            if (sortMode === 'progress') return (a.totalLevel / (a.total * 5)) - (b.totalLevel / (b.total * 5));
            if (sortMode === 'count') return b.total - a.total;
            if (sortMode === 'az') return a.topic.localeCompare(b.topic);
            return 0;
        });

        const myTopics = topicArr.filter(t => !t.isImported);
        const importedTopics = topicArr.filter(t => t.isImported);

        const buildSectionedHTML = (actionStr) => {
            if (topicArr.length === 0) return `<div class="col-span-full text-center py-10 text-gray-400 font-bold">Không tìm thấy bộ thẻ nào! 🥲</div>`;
            
            let html = '';
            
            // Render các chủ đề bạn tự tạo trước
            if (myTopics.length > 0) {
                html += this.genTopicHTML(myTopics, actionStr);
            }
            
            // Render dải phân cách và các chủ đề được nạp từ file bên dưới
            if (importedTopics.length > 0) {
                html += `
                <div class="col-span-full mt-6 mb-2 flex items-center gap-3 w-full animate-fade-in-up">
                    <div class="h-px bg-gray-200 dark:bg-gray-700 flex-1"></div>
                    <span class="text-[11px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-1.5"><span class="text-base">📂</span> THƯ MỤC NẠP NGOÀI</span>
                    <div class="h-px bg-gray-200 dark:bg-gray-700 flex-1"></div>
                </div>`;
                html += this.genTopicHTML(importedTopics, actionStr);
            }
            return html;
        };

        const grid = document.getElementById('topic-grid');
        if (grid) grid.innerHTML = buildSectionedHTML('app.startLearn');

        const quizGrid = document.getElementById('quiz-topic-grid');
        if (quizGrid) {
            const allCard = `<div onclick="app.startQuiz('ALL')" class="animate-fade-in-up bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl shadow-lg border border-indigo-500 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group flex flex-col p-6 md:col-span-2 lg:col-span-3 mb-2 relative overflow-hidden">
                <div class="absolute -right-10 -top-10 w-40 h-40 bg-white opacity-10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
                <div class="flex items-center gap-5 relative z-10">
                    <div class="w-16 h-16 shrink-0 rounded-2xl flex items-center justify-center text-3xl bg-white/20 text-white shadow-inner group-hover:scale-110 transition-transform duration-300">🔀</div>
                    <div class="flex-1">
                        <h3 class="font-black text-white text-xl md:text-2xl mb-1 drop-shadow-sm">Trộn Tất Cả Thư Viện</h3>
                        <p class="text-indigo-100 text-sm font-medium">Tạo đề trắc nghiệm ngẫu nhiên từ toàn bộ từ vựng của bạn.</p>
                    </div>
                </div>
            </div>`;
            quizGrid.innerHTML = allCard + buildSectionedHTML('app.startQuiz');
        }
    },

    genTopicHTML: function (topicArr, action) {
        if (topicArr.length === 0) return `<div class="col-span-full text-center py-10 text-gray-400 font-bold">Không tìm thấy bộ thẻ nào! 🥲</div>`;

        return topicArr.map((item, index) => {
            const topic = item.topic;
            const count = item.total;
            const percent = Math.round((item.totalLevel / (item.total * 5)) * 100);
            const emojiMatch = topic.match(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/u);
            const displayIcon = emojiMatch ? emojiMatch[0] : '📚';
            const cleanTopic = topic.replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, '').trim() || topic;

            const themeColors = [
                { bg: 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400', border: 'group-hover:border-blue-300 dark:group-hover:border-blue-700', hoverText: 'group-hover:text-blue-600', fill: 'bg-blue-500' },
                { bg: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400', border: 'group-hover:border-emerald-300 dark:group-hover:border-emerald-700', hoverText: 'group-hover:text-emerald-600', fill: 'bg-emerald-500' },
                { bg: 'bg-orange-50 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400', border: 'group-hover:border-orange-300 dark:group-hover:border-orange-700', hoverText: 'group-hover:text-orange-600', fill: 'bg-orange-500' },
                { bg: 'bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400', border: 'group-hover:border-purple-300 dark:group-hover:border-purple-700', hoverText: 'group-hover:text-purple-600', fill: 'bg-purple-500' }
            ];
            const theme = themeColors[topic.length % themeColors.length];
            const delay = Math.min(index * 40, 300);

            const isRecent = (topic === (this.user?.lastStudiedTopic || ''));
            const recentBadge = isRecent && action.includes('startLearn') ? `<div class="absolute -top-3 -right-3 bg-red-500 text-white text-[9px] font-black px-3 py-1 rounded-full shadow-md z-20 animate-bounce uppercase tracking-widest border-2 border-white dark:border-gray-800">Vừa học</div>` : '';

            const isImportedBadge = item.isImported ? `<div class="absolute -top-3 left-4 bg-teal-500 text-white text-[9px] font-black px-3 py-1 rounded-full shadow-md z-20 uppercase tracking-widest border-2 border-white dark:border-gray-800 flex items-center gap-1"><span class="text-xs">📥</span> TỪ FILE NẠP</div>` : '';

            const expandBtn = action.includes('startLearn') ? `<button onclick="app.expandTopicAI(event, '${topic.replace(/'/g, "\\'")}')" class="text-[10px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 dark:bg-indigo-900/40 dark:text-indigo-300 px-3 py-1.5 rounded-xl hover:bg-indigo-600 hover:text-white transition-colors flex items-center gap-1 z-20 relative"><span class="text-sm">✨</span> Thêm Từ Mới</button>` : '<div></div>';

            return `
            <div onclick="${action}('${topic.replace(/'/g, "\\'")}')" style="animation-delay: ${delay}ms" class="animate-fade-in-up opacity-0 relative group cursor-pointer mt-2">
                ${recentBadge}
                ${isImportedBadge}
                <div class="absolute inset-0 bg-gray-200 dark:bg-gray-700 rounded-3xl transform rotate-2 translate-y-2 translate-x-2 group-hover:rotate-6 group-hover:translate-y-3 group-hover:translate-x-3 transition-all duration-300 z-0 shadow-sm"></div>
                <div class="absolute inset-0 bg-gray-100 dark:bg-gray-600 rounded-3xl transform -rotate-1 translate-y-1 translate-x-1 group-hover:-rotate-3 group-hover:translate-y-1 group-hover:-translate-x-1 transition-all duration-300 z-0 shadow-sm"></div>
                
                <div class="relative bg-white rounded-3xl shadow-sm border ${isRecent && action.includes('startLearn') ? 'border-primary shadow-indigo-100 dark:shadow-none' : 'border-gray-100'} ${theme.border} transition-all duration-300 dark:bg-gray-800 dark:border-gray-700 flex flex-col p-5 z-10 h-full overflow-hidden group-hover:-translate-y-1 group-hover:shadow-xl">
                    <div class="flex items-start justify-between gap-4 mb-4">
                        <div class="w-16 h-16 shrink-0 rounded-2xl flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 group-hover:-rotate-6 transition-transform duration-300 ${theme.bg}">
                            ${displayIcon}
                        </div>
                        <span class="bg-gray-100 text-gray-500 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest dark:bg-gray-700 dark:text-gray-400 shadow-sm">
                            ${count} Thẻ
                        </span>
                    </div>
                    
                    <h3 class="font-black text-gray-800 text-xl md:text-2xl leading-tight dark:text-white ${theme.hoverText} transition-colors line-clamp-2 mb-1">${cleanTopic}</h3>
                    <p class="text-xs text-gray-500 font-medium dark:text-gray-400 line-clamp-2 mb-5 leading-relaxed opacity-90">${item.desc}</p>
                    
                    <div class="mt-auto relative z-10">
                        <div class="flex justify-between text-[10px] font-bold text-gray-400 mb-2 uppercase tracking-widest">
                            <span>Mức độ thuộc</span>
                            <span class="${percent === 100 ? 'text-emerald-500' : 'text-gray-600 dark:text-gray-300'}">${percent}%</span>
                        </div>
                        <div class="w-full bg-gray-100 rounded-full h-2 dark:bg-gray-700 overflow-hidden mb-4">
                            <div class="${theme.fill} h-full rounded-full transition-all duration-1000" style="width: ${percent}%"></div>
                        </div>
                        
                        <div class="flex items-center justify-between pt-4 border-t border-dashed border-gray-100 dark:border-gray-700">
                            ${expandBtn}
                            <div class="flex items-center gap-2 relative z-10">
                                <span class="text-xs font-bold text-gray-500 dark:text-gray-400 group-hover:text-gray-800 dark:group-hover:text-gray-200 transition-colors">Vào học</span>
                                <div class="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 group-hover:bg-primary group-hover:text-white transition-all dark:bg-gray-700 shadow-sm group-hover:scale-110">
                                    <svg class="w-4 h-4 ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7"></path></svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
        }).join('');
    },

    expandTopicAI: function (event, topic) {
        event.stopPropagation();
        document.getElementById('ai-topic-input').value = topic;
        document.getElementById('ai-qty').value = 15;
        this.toggleAiModal();
        this.toast(`Chuẩn bị sinh thêm từ cho "${topic}". AI sẽ né các từ đã có!`, "info");
    },

    // ==========================================
    // 2. LOGIC HỌC TẬP (STUDY ENGINE)
    // ==========================================
    changeStudySort: function () {
        if (!this.state.studySortMode) this.state.studySortMode = 'priority';

        const modes = ['priority', 'default', 'random'];
        let idx = modes.indexOf(this.state.studySortMode) + 1;
        if (idx >= modes.length) idx = 0;

        this.state.studySortMode = modes[idx];

        if (this.state.currentTopicName) {
            this.startLearn(this.state.currentTopicName);
        }
    },

    startLearn: function (topic) {
        this.state.currentTopicName = topic;

        if (!this.user) this.user = {};
        this.user.lastStudiedTopic = topic;
        if (typeof this.saveUserData === 'function') this.saveUserData();

        let pool = this.data.filter(i => (i.topic || 'General') === topic);
        if (pool.length === 0) return this.toast("Chủ đề này chưa có từ vựng!", "info");

        if (!this.state.studySortMode) this.state.studySortMode = 'priority';
        const sortMode = this.state.studySortMode;

        const sortBtn = document.getElementById('btn-study-sort');
        if (sortBtn) {
            if (sortMode === 'priority') sortBtn.innerHTML = '🔥 Ưu tiên';
            else if (sortMode === 'default') sortBtn.innerHTML = '📋 Cố định';
            else sortBtn.innerHTML = '🔀 Trộn từ';
        }

        if (sortMode === 'priority') {
            pool.sort((a, b) => {
                const levelDiff = (a.level || 0) - (b.level || 0);
                if (levelDiff !== 0) return levelDiff;
                return (a.nextReview || 0) - (b.nextReview || 0);
            });
        } else if (sortMode === 'random') {
            pool.sort(() => 0.5 - Math.random());
        }

        this.sessionData = pool;

        document.getElementById('study-topics').classList.add('hidden');
        document.getElementById('study-mode').classList.replace('hidden', 'flex');

        const listPreview = document.getElementById('study-list-preview');
        if (listPreview) {
            listPreview.innerHTML = this.sessionData.map((item, idx) => `
                <div onclick="app.loadCard(${idx})" class="p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition border-l-2 border-transparent hover:border-primary group dark:hover:bg-gray-700">
                    <div class="font-bold text-gray-700 text-sm group-hover:text-primary dark:text-gray-300">${item.word}</div>
                    <div class="text-xs text-gray-400 truncate">${item.definition}</div>
                </div>
            `).join('');
        }
        this.state.currentIndex = 0;
        this.loadCard(0);
    },

    backToTopics: function () {
        document.getElementById('study-mode').classList.replace('flex', 'hidden');
        document.getElementById('study-topics').classList.remove('hidden');
    },

    // ==========================================
    // 3. LOGIC FLASHCARD (LẬT THẺ)
    // ==========================================
    loadCard: function (index) {
        if (this.audioTimer) clearTimeout(this.audioTimer);
        if (typeof this.stopAudio === 'function') this.stopAudio();

        if (!this.sessionData[index]) return;
        const item = this.sessionData[index];

        this.state.isFlipped = false;
        this.state.cardEnterTime = Date.now();
        this.state.flipTime = null;
        this.state.isManualMarked = false;
        this.state.isProcessing = false; // BẢO VỆ CHỐNG SPAM CLICK HIỆU QUẢ NHẤT

        this.dom.card.inner.classList.remove('rotate-y-180');

        if (this.dom.card.emoji) this.dom.card.emoji.textContent = item.emoji || '💡';

        const wLen = item.word.length;
        const wClass = wLen < 8 ? 'text-5xl md:text-6xl' : (wLen < 14 ? 'text-4xl md:text-5xl' : 'text-3xl');
        this.dom.card.word.className = `font-extrabold text-gray-800 break-words leading-tight transition-all duration-300 ${wClass} dark:text-gray-800`;
        this.dom.card.word.textContent = item.word;

        const mainMeaning = item.coreDef || item.definition;
        const descMeaning = (item.coreDef && item.coreDef !== item.definition) ? item.definition : '';

        const dLen = mainMeaning.length;
        const dClass = dLen < 50 ? 'text-3xl md:text-4xl' : (dLen < 100 ? 'text-2xl' : 'text-lg');
        this.dom.card.def.className = `font-extrabold leading-snug text-center text-primary dark:text-indigo-400 px-2 ${dClass}`;
        this.dom.card.def.textContent = mainMeaning;

        this.dom.card.type.textContent = item.type;
        this.dom.card.pronun.textContent = item.pronun;
        this.dom.card.ex.textContent = item.example;

        const coreBox = document.getElementById('card-core-box');
        if (descMeaning) {
            if (coreBox) coreBox.classList.remove('hidden');
            const boxTitle = coreBox.querySelector('p');
            if (boxTitle) boxTitle.textContent = 'GIẢI NGHĨA CHI TIẾT'; 

            const cwEl = document.getElementById('card-core-word');
            const cdEl = document.getElementById('card-core-def');
            if (cwEl) cwEl.textContent = 'Mô tả';
            if (cdEl) cdEl.textContent = descMeaning;
        } else {
            if (coreBox) coreBox.classList.add('hidden');
        }

        const exTransEl = document.getElementById('card-ex-trans');
        if (exTransEl) {
            exTransEl.textContent = item.exTranslation || 'Chưa có bản dịch cho câu này.';
            exTransEl.classList.add('hidden');
        }

        if (this.dom.controls?.currentIdx) this.dom.controls.currentIdx.textContent = index + 1;
        if (this.dom.controls?.totalCards) this.dom.controls.totalCards.textContent = this.sessionData.length;

        // Reset UI SRS Buttons
        const btnShow = document.getElementById('btn-show-answer');
        const btnNext = document.getElementById('btn-smart-next');
        if (btnShow) btnShow.classList.remove('hidden');
        if (btnNext) btnNext.classList.add('hidden');

        this.audioTimer = setTimeout(() => {
            if (typeof this.playAudio === 'function') this.playAudio(null, item.word);
        }, 150);
    },

    flipCard: function () {
        this.state.isFlipped = !this.state.isFlipped;
        this.dom.card.inner.classList.toggle('rotate-y-180', this.state.isFlipped);

        const btnShow = document.getElementById('btn-show-answer');
        const btnNext = document.getElementById('btn-smart-next');
        const quizBox = document.getElementById('card-quick-quiz');
        const backContent = document.getElementById('card-back-content');
        const title = document.getElementById('card-back-title');

        if (this.state.isFlipped) {
            if (!this.state.flipTime) this.state.flipTime = Date.now();
            if (btnShow) btnShow.classList.add('hidden');
            
            const item = this.sessionData[this.state.currentIndex];
            // Kích hoạt Active Recall Micro-Quiz: Đa dạng loại câu hỏi
            if ((Math.random() > 0.6 || item.isReview) && this.sessionData.length > 2) {
                if (btnNext) btnNext.classList.add('hidden');
                if (backContent) backContent.classList.add('hidden');
                
                const quizType = Math.floor(Math.random() * 3); // 3 Dạng: Chọn nghĩa, Chọn từ, Điền chữ
                let html = '';
                
                if (quizType === 0) {
                    if (title) title.textContent = "CHỌN NGHĨA CHÍNH XÁC";
                    let options = [item.definition];
                    let pool = this.data.filter(i => i.definition !== item.definition);
                    pool.sort(() => 0.5 - Math.random());
                    if (pool[0]) options.push(pool[0].definition);
                    if (pool[1]) options.push(pool[1].definition);
                    options.sort(() => 0.5 - Math.random());

                    html = options.map(opt => `
                        <button onclick="app.submitMicroQuiz(this, '${opt.replace(/'/g, "\\'")}', '${item.definition.replace(/'/g, "\\'")}'); event.stopPropagation()" 
                            class="w-full text-left p-3 rounded-xl border border-gray-200 hover:border-indigo-500 hover:bg-indigo-50 dark:border-gray-600 dark:hover:bg-indigo-900/30 text-sm font-bold text-gray-700 dark:text-gray-200 transition shadow-sm" data-ans="${opt.replace(/"/g, '&quot;')}">
                            ${opt}
                        </button>
                    `).join('');
                } else if (quizType === 1) {
                    if (title) title.textContent = "TỪ NÀY TIẾNG ANH LÀ GÌ?";
                    let options = [item.word];
                    let pool = this.data.filter(i => i.word !== item.word);
                    pool.sort(() => 0.5 - Math.random());
                    if (pool[0]) options.push(pool[0].word);
                    if (pool[1]) options.push(pool[1].word);
                    options.sort(() => 0.5 - Math.random());

                    html = options.map(opt => `
                        <button onclick="app.submitMicroQuiz(this, '${opt.replace(/'/g, "\\'")}', '${item.word.replace(/'/g, "\\'")}'); event.stopPropagation()" 
                            class="w-full text-center p-3 rounded-xl border border-gray-200 hover:border-indigo-500 hover:bg-indigo-50 dark:border-gray-600 dark:hover:bg-indigo-900/30 text-lg font-black text-gray-800 dark:text-gray-100 transition shadow-sm" data-ans="${opt.replace(/"/g, '&quot;')}">
                            ${opt}
                        </button>
                    `).join('');
                } else {
                    if (title) title.textContent = "ĐIỀN CHỮ CÁI CÒN THIẾU";
                    const w = item.word;
                    const hideIdx = Math.floor(Math.random() * w.length);
                    const hiddenWord = w.substring(0, hideIdx) + '_' + w.substring(hideIdx + 1);
                    const correctChar = w[hideIdx].toLowerCase();
                    
                    const charPool = "abcdefghijklmnopqrstuvwxyz";
                    let options = [correctChar];
                    while (options.length < 4) {
                        let c = charPool[Math.floor(Math.random() * charPool.length)];
                        if (!options.includes(c)) options.push(c);
                    }
                    options.sort(() => 0.5 - Math.random());

                    html = `<div class="text-3xl font-black text-center text-indigo-600 dark:text-indigo-400 tracking-widest mb-4 drop-shadow-sm">${hiddenWord}</div>
                            <div class="grid grid-cols-4 gap-2">` + 
                    options.map(opt => `
                        <button onclick="app.submitMicroQuiz(this, '${opt}', '${correctChar}'); event.stopPropagation()" 
                            class="p-3 rounded-xl border border-gray-200 hover:border-indigo-500 hover:bg-indigo-50 dark:border-gray-600 dark:hover:bg-indigo-900/30 text-xl font-bold text-gray-800 dark:text-gray-100 transition uppercase shadow-sm" data-ans="${opt.replace(/"/g, '&quot;')}">
                            ${opt}
                        </button>
                    `).join('') + `</div>`;
                }

                if (quizBox) {
                    quizBox.innerHTML = html;
                    quizBox.classList.remove('hidden');
                    quizBox.classList.add('flex');
                }
            } else {
                if (btnNext) btnNext.classList.remove('hidden');
                if (title) title.textContent = "Định nghĩa";
                if (backContent) backContent.classList.remove('hidden');
                if (quizBox) {
                    quizBox.classList.add('hidden');
                    quizBox.classList.remove('flex');
                }
            }
            if (typeof this.playAudio === 'function') this.playAudio();
        } else {
            if (btnShow) btnShow.classList.remove('hidden');
            if (btnNext) btnNext.classList.add('hidden');
            if (quizBox) {
                quizBox.classList.add('hidden');
                quizBox.classList.remove('flex');
            }
        }
    },

    submitMicroQuiz: function(btn, selected, correct) {
        if (this.state.isProcessing) return;
        this.state.isProcessing = true; // Khóa UI không cho bấm tiếp

        const quizBox = document.getElementById('card-quick-quiz');
        if (quizBox) {
            const btns = quizBox.querySelectorAll('button');
            btns.forEach(b => {
                b.disabled = true; // Disable tất cả nút
                b.classList.remove('hover:border-indigo-500', 'hover:bg-indigo-50', 'dark:hover:bg-indigo-900/30');
                // Tô xanh đáp án đúng
                if (b.getAttribute('data-ans') === correct) {
                    b.classList.add('bg-emerald-100', 'border-emerald-500', 'text-emerald-700', 'dark:bg-emerald-900/50', 'dark:text-emerald-400');
                }
            });
        }

        if (selected === correct) {
            if (typeof this.playSound === 'function') this.playSound('correct');
            setTimeout(() => {
                this.state.isProcessing = false;
                this.smartNextCard(true);
            }, 600); // Đợi 0.6s để người dùng thấy nút màu xanh
        } else {
            if (typeof this.playSound === 'function') this.playSound('wrong');
            // Tô đỏ nút đã chọn sai và rung
            btn.classList.add('bg-rose-100', 'border-rose-500', 'text-rose-700', 'dark:bg-rose-900/50', 'dark:text-rose-400', 'animate-shake');
            if (typeof this.toast === 'function') this.toast(`Sai rồi! Đáp án là: ${correct}`, "error");
            
            setTimeout(() => {
                this.state.isProcessing = false;
                this.smartNextCard(false);
            }, 1200); // Đợi 1.2s để người dùng kịp nhận diện đáp án sai
        }
    },

    nextCard: function () {
        if (this.state.isProcessing) return; // Chặn double skip khi spam phím Next

        if (!this.state.isManualMarked) {
            const now = Date.now();
            let isKnown = true;
            let reason = "";

            if (!this.state.flipTime) {
                isKnown = false;
                reason = "Bạn chưa lật thẻ xem nghĩa!";
            } else {
                const recallTime = this.state.flipTime - this.state.cardEnterTime;
                const readTime = now - this.state.flipTime;

                if (recallTime < 400) {
                    isKnown = false;
                    reason = "Lật thẻ quá nhanh, chưa kịp nhìn từ!";
                } else if (recallTime > 3000) {
                    isKnown = false;
                    reason = "Phản xạ chậm (>3s)! Cần học lại.";
                } else if (readTime < 400) {
                    isKnown = false;
                    reason = "Lướt quá nhanh, hãy đọc kỹ nghĩa nhé!";
                }
            }

            if (!isKnown) {
                document.getElementById('flashcard-inner').classList.add('animate-shake');
                setTimeout(() => document.getElementById('flashcard-inner').classList.remove('animate-shake'), 300);
                if (typeof this.toast === 'function') this.toast(`⚠️ ${reason}`, "error");
            }

            this.state.isProcessing = true; // Khóa thẻ trong lúc xử lý
            this.processStudyDecision(isKnown);
        } else {
            this.executeNextCard();
        }
    },

    executeNextCard: function () {
        if (this.state.currentIndex < this.sessionData.length - 1) {
            this.state.currentIndex++;
            this.loadCard(this.state.currentIndex);
        } else {
            if (typeof this.confirmAction === 'function') {
                this.confirmAction("🎉 Chúc mừng! Bạn đã cày nát bộ thẻ này. Khắc sâu vào não rồi đó!", () => {
                    this.backToTopics();
                });
            } else {
                alert("🎉 Chúc mừng! Bạn đã cày nát bộ thẻ này.");
                this.backToTopics();
            }
        }
    },

    prevCard: function () {
        if (this.state.isProcessing) return;
        if (this.state.currentIndex > 0) {
            this.state.currentIndex--;
            this.loadCard(this.state.currentIndex);
        }
    },

    // ==========================================
    // 4. CHẤM ĐIỂM & ĐÁNH GIÁ (SRS & PACING)
    // ==========================================
    smartNextCard: function(forceKnown = null) {
        if (this.state.isProcessing) return;
        
        const now = Date.now();
        let grade = 'good'; // Tốt
        let warningMsg = "";
        
        if (forceKnown !== null) {
            grade = forceKnown ? 'good' : 'again';
        } else if (!this.state.flipTime) {
            grade = 'again';
            warningMsg = "Bạn chưa lật thẻ xem nghĩa!";
        } else {
            const recallTime = this.state.flipTime - this.state.cardEnterTime; 
            const readTime = now - this.state.flipTime; 
            
            if (recallTime < 300 || readTime < 400) {
                grade = 'again';
                warningMsg = "Spam quá nhanh! Não bộ không kịp ghi nhớ.";
            } else if (recallTime > 4000) {
                grade = 'hard'; 
            } else if (recallTime < 1000 && readTime > 2500) {
                grade = 'hard'; 
            } else if (recallTime >= 600 && recallTime <= 2500 && readTime <= 1500) {
                grade = 'easy'; 
            }
        }

        if (warningMsg) {
            const cardInner = document.getElementById('flashcard-inner');
            if (cardInner) {
                cardInner.classList.add('animate-shake');
                setTimeout(() => cardInner.classList.remove('animate-shake'), 300);
            }
            if (typeof this.toast === 'function') this.toast(`⚠️ ${warningMsg}`, "warning");
        }

        this.state.isProcessing = true;
        this.processStudyDecision(grade);
    },

    processStudyDecision: function (grade) {
        if (!this.sessionData[this.state.currentIndex]) return;
        const currentItem = this.sessionData[this.state.currentIndex];

        // Tích hợp FSRS Optimization
        this.processFSRS(currentItem, grade);
        if (typeof this.updateQuest === 'function') this.updateQuest('study', 1);

        if (grade === 'again' || grade === 'hard') {
            this.sessionData.push({ ...currentItem, isReview: true, tempGrade: grade });
            if (this.dom.controls?.totalCards) this.dom.controls.totalCards.textContent = this.sessionData.length; 
            if (typeof this.playSound === 'function') this.playSound('wrong');
        } else {
            if (typeof this.playSound === 'function') this.playSound('correct');
        }

        this.executeNextCard();
    },

    processFSRS: function (item, grade) {
        const now = Date.now();
        // Khởi tạo FSRS Object nếu thẻ chưa từng được học
        if (!item.fsrs) {
            item.fsrs = { reps: 0, lapses: 0, state: 0, difficulty: 5, stability: 2, lastReview: now };
        }
        
        let fsrs = item.fsrs;
        fsrs.reps++;
        
        // Map cấp độ Cognitive Matrix sang FSRS Rating (1-4)
        const rating = grade === 'again' ? 1 : grade === 'hard' ? 2 : grade === 'good' ? 3 : 4;
        
        if (rating === 1) {
            fsrs.lapses++;
            fsrs.stability = Math.max(0.5, fsrs.stability * 0.4); // Giảm mạnh độ ổn định
            fsrs.difficulty = Math.min(10, fsrs.difficulty + 1.5); // Tăng độ khó
            fsrs.state = 1; // State: Relearning
        } else {
            const factor = 1 + (10 - fsrs.difficulty) / 10;
            fsrs.stability = fsrs.stability * factor * (rating === 4 ? 1.5 : 1);
            fsrs.difficulty = Math.max(1, fsrs.difficulty - (rating === 4 ? 1.5 : 0.5));
            fsrs.state = 2; // State: Reviewing
        }
        
        fsrs.lastReview = now;
        // Chuyển đổi Stability thành thời gian Next Review
        item.nextReview = now + (fsrs.stability * 24 * 60 * 60 * 1000);
        // Đồng bộ với UI System cũ để tương thích thanh Progress
        item.level = rating >= 3 ? Math.min((item.level || 0) + 1, 5) : Math.max((item.level || 0) - 1, 0);

        if (typeof this.saveData === 'function') this.saveData();
    }
});