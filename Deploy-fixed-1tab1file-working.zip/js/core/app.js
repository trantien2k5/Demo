/**
 * ============================================================================
 * FLASHCARD PRO - CORE ENGINE SCRIPT
 * ============================================================================
 * File này đóng vai trò là "Trái tim" của ứng dụng. Nó khởi tạo trạng thái
 * toàn cục, quản lý DOM cơ bản và chứa các module hệ thống cốt lõi bao gồm:
 * 1. Thư viện Từ vựng (CRUD)
 * 2. AI Generator (Tạo từ tự động)
 * 3. Hệ thống Luyện Nghe & Podcast
 * 4. Hệ thống Thi Thử (Mock Test)
 * 5. Hội Quán (Tavern - Giao tiếp AI)
 * 6. Ma Pháp Trận (Luyện tập Ngữ pháp)
 * ============================================================================
 */

const app = {
    // ==========================================
    // 1. CẤU HÌNH & TRẠNG THÁI TOÀN CỤC (GLOBAL STATE)
    // ==========================================
    apiKey: '',
    data: [],           // Kho lưu trữ từ vựng chính
    sessionData: [],    // Dữ liệu tạm thời cho phiên học hiện tại
    mockHistory: [],    // Lịch sử làm bài test

    // Dữ liệu người dùng và tiến trình học tập
    user: {
        name: 'Người Mới', 
        avatar: '👨‍🎓', 
        avatarBg: 'from-indigo-500 to-purple-600',
        learningLang: 'English',
        voiceMode: 'real', 
        voiceLang: 'en-US', 
        voiceSpeed: '1.0', 
        apiKey: '',
        joinDate: null, 
        lastLoginDate: null, 
        streak: 0, 
        totalDays: 0, 
        exp: 0, 
        dungeonFloor: 1,
        questDate: null, 
        quests: []
    },

    // Trạng thái vận hành của UI và các mini-games
    state: {
        currentIndex: 0, 
        isFlipped: false, 
        editingId: null,
        currentTopicName: null, 
        quizMode: 'meaning', 
        currentQuizTopic: null,
        listenSpeed: 1.0, 
        listenAccent: false, 
        listenNoise: false,
        deepStep: 0, 
        survivalStreak: 0,
        arenaState: { level: 1, pMaxHp: 100, pHp: 100, bMaxHp: 50, bHp: 50, currentWord: null, pool: [] }
    },

    dom: {}, // Nơi cache lại các DOM elements để tăng hiệu suất

    // ==========================================
    // 2. KHỞI TẠO ỨNG DỤNG (LIFECYCLE)
    // ==========================================
    init: function () {
        this.cacheDOM();
        this.bindEvents();
        this.lang = localStorage.getItem('app_lang') || 'vi';
        this.loadData();
        this.applyLanguage();
        this.updateThemeUI();
        this.startClock();
        this.checkStreak();
        
        // Đồng bộ toàn bộ UI ngôn ngữ học (Sidebar, AI Modal, Dashboard, Title...)
        if(this.updateLearningLangUI) this.updateLearningLangUI();
        
        if (app.addCopyButtons) app.addCopyButtons();
        const observer = new MutationObserver(() => { if (app.addCopyButtons) app.addCopyButtons(); });
        observer.observe(document.body, { childList: true, subtree: true });
    },

    /**
     * Map các HTML elements quan trọng vào object app.dom 
     * để tái sử dụng, tránh việc gọi document.getElementById nhiều lần.
     */
    cacheDOM: function () {
        this.dom = {
            views: {
                dashboard: document.getElementById('view-dashboard'),
                study: document.getElementById('view-study'),
                listening: document.getElementById('view-listening'),
                quiz: document.getElementById('view-quiz'),
                library: document.getElementById('view-library'),
                grammar: document.getElementById('view-grammar'),
                profile: document.getElementById('view-profile'),
                arena: document.getElementById('view-arena'),
                mocktest: document.getElementById('view-mocktest')
            },
            card: {
                inner: document.getElementById('flashcard-inner'),
                emoji: document.getElementById('card-emoji'),
                word: document.getElementById('card-word'),
                type: document.getElementById('card-type'),
                pronun: document.getElementById('card-pronun'),
                def: document.getElementById('card-definition'),
                ex: document.getElementById('card-example')
            },
            stats: {
                total: document.getElementById('stat-total')
            },
            controls: {
                currentIdx: document.getElementById('current-index'),
                totalCards: document.getElementById('total-cards')
            },
            navItems: document.querySelectorAll('.nav-item')
        };
    },

    // ==========================================
    // 3. QUẢN LÝ THƯ VIỆN & CRUD (LIBRARY ENGINE)
    // ==========================================
    
    toggleDataModal: function () {
        const m = document.getElementById('modal-data');
        if (m) {
            m.classList.toggle('hidden');
            m.classList.toggle('flex');
            if (!m.classList.contains('hidden')) m.children[0].classList.add('animate-pop-in');
        }
    },

    toggleImportModal: function () {
        const dm = document.getElementById('modal-data');
        if (dm && !dm.classList.contains('hidden')) {
            dm.classList.add('hidden');
            dm.classList.remove('flex');
        }
        const m = document.getElementById('modal-import');
        m.classList.toggle('hidden'); m.classList.toggle('flex');
        if (!m.classList.contains('hidden')) m.children[0].classList.add('animate-pop-in');
    },

    /**
     * Sao chép câu lệnh (prompt) mẫu để người dùng dán vào ChatGPT/Claude 
     * nhằm tạo ra file JSON nhập liệu đúng chuẩn.
     */
    copyImportPrompt: async function () {
        const p = document.getElementById('import-prompt-text');
        if (!p) return;
        if (app.copyToClipboard) {
            app.copyToClipboard(p.value, "Đã copy lệnh! Hãy dán vào AI để tạo file nhé.");
        }
    },

    toggleModal: function () {
        const modal = document.getElementById('modal-add');
        modal.classList.toggle('hidden'); modal.classList.toggle('flex');
        if (!modal.classList.contains('hidden')) modal.children[0].classList.add('animate-pop-in');
    },

    /**
     * Mở form thêm mới hoặc chỉnh sửa từ vựng.
     * Nếu có ID truyền vào, form sẽ load dữ liệu của từ đó lên để edit.
     */
    openModal: function (id = null) {
        this.state.editingId = id;
        this.toggleModal();

        if (id) {
            const item = this.data.find(i => i.id === id);
            if (item) {
                document.getElementById('input-topic').value = item.topic || 'General';
                document.getElementById('input-word').value = item.word;
                document.getElementById('input-emoji').value = item.emoji || '💡';
                document.getElementById('input-type').value = item.type;
                document.getElementById('input-pronun').value = item.pronun;
                document.getElementById('input-def').value = item.definition;
                document.getElementById('input-core-word').value = item.coreWord || '';
                document.getElementById('input-core-def').value = item.coreDef || '';
                document.getElementById('input-ex').value = item.example;
                document.getElementById('input-ex-trans').value = item.exTranslation || '';
            }
        } else {
            document.querySelectorAll('#modal-add input, #modal-add textarea').forEach(i => i.value = '');
        }
    },

    /**
     * Lưu dữ liệu từ form vào bộ nhớ (Xử lý cả 2 tác vụ: Thêm mới và Cập nhật).
     */
    saveWord: function () {
        const w = document.getElementById('input-word').value;
        const d = document.getElementById('input-def').value;
        const e = document.getElementById('input-emoji').value || '💡';
        
        if (!w || !d) return this.toast("Vui lòng nhập Từ và Định nghĩa!", "error");

        const newItem = {
            id: this.state.editingId || (window.crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now()),
            word: w,
            emoji: e,
            topic: document.getElementById('input-topic').value || 'General',
            type: document.getElementById('input-type').value || 'Noun',
            pronun: document.getElementById('input-pronun').value,
            definition: d,
            coreWord: document.getElementById('input-core-word').value,
            coreDef: document.getElementById('input-core-def').value,
            example: document.getElementById('input-ex').value,
            exTranslation: document.getElementById('input-ex-trans').value,
            level: 0, 
            nextReview: 0
        };

        // Nếu có editingId tức là đang ở chế độ cập nhật, nếu không thì thêm vào đầu mảng
        if (this.state.editingId) {
            const index = this.data.findIndex(i => i.id === this.state.editingId);
            if (index !== -1) {
                newItem.level = this.data[index].level;
                newItem.nextReview = this.data[index].nextReview;
                this.data[index] = newItem;
            }
        } else {
            this.data.unshift(newItem);
        }

        this.toggleModal();
        this.refreshViews();
        this.toast("Đã lưu từ vựng thành công!");
    },

    deleteWord: function (id) {
        this.confirmAction("Bạn có chắc chắn muốn xóa từ này?", () => {
            this.data = this.data.filter(i => i.id !== id);
            this.refreshViews();
            this.toast("Đã xóa từ vựng!");
        });
    },

    deleteTopic: function (topic) {
        this.confirmAction(`CẢNH BÁO: Bạn muốn xóa chủ đề "${topic}" và TẤT CẢ các từ trong đó?`, () => {
            const initialLength = this.data.length;
            this.data = this.data.filter(i => (i.topic || 'General') !== topic);
            const deletedCount = initialLength - this.data.length;

            this.refreshViews();
            this.toast(`Đã xóa chủ đề "${topic}" (${deletedCount} từ)!`, "success");
        });
    },

    deleteCurrentLibTopic: function () {
        const topic = document.getElementById('lib-filter-topic').value;
        if (topic) this.deleteTopic(topic);
    },

    /**
     * Hiển thị danh sách từ vựng trong Thư viện.
     * Bao gồm tính năng tìm kiếm, lọc theo chủ đề và sắp xếp theo thuộc tính.
     */
    renderLibrary: function (isLoadMore = false) {
        if (!isLoadMore) {
            this.state.libLimit = 50; 
        } else {
            this.state.libLimit = (this.state.libLimit || 50) + 50;
        }

        const query = (document.getElementById('lib-search')?.value || '').toLowerCase();
        const topicFilter = document.getElementById('lib-filter-topic');
        const sortMode = document.getElementById('lib-sort')?.value || 'newest';
        const list = document.getElementById('lib-list');
        const topicActions = document.getElementById('lib-topic-actions');

        const currentTopic = topicFilter?.value || '';
        const uniqueTopics = [...new Set(this.data.map(i => i.topic || 'General'))].sort();

        // Đổ dữ liệu vào Dropdown bộ lọc chủ đề
        if (topicFilter) {
            const options = ['<option value="">📂 Tất cả chủ đề</option>', ...uniqueTopics.map(t => `<option value="${t}">${t}</option>`)];
            if (topicFilter.innerHTML.length !== options.join('').length) {
                topicFilter.innerHTML = options.join('');
                topicFilter.value = uniqueTopics.includes(currentTopic) ? currentTopic : "";
            }
        }

        // Hiện/ẩn khu vực thao tác nhanh của chủ đề (Xóa cả cụm)
        if (topicActions) {
            if (topicFilter && topicFilter.value) {
                topicActions.classList.remove('hidden');
                document.getElementById('lib-selected-topic-name').textContent = topicFilter.value;
            } else {
                topicActions.classList.add('hidden');
            }
        }

        // Áp dụng bộ lọc và công cụ tìm kiếm
        let filtered = this.data.filter(i => {
            const matchText = (i.word || '').toLowerCase().includes(query) || (i.definition || '').toLowerCase().includes(query);
            const matchTopic = (topicFilter && topicFilter.value) ? (i.topic || 'General') === topicFilter.value : true;
            return matchText && matchTopic;
        });

        // Sắp xếp
        filtered.sort((a, b) => {
            if (sortMode === 'newest') return b.id - a.id;
            if (sortMode === 'oldest') return a.id - b.id;
            if (sortMode === 'az') return (a.word || '').localeCompare(b.word || '');
            return 0;
        });

        if (document.getElementById('lib-total')) document.getElementById('lib-total').textContent = filtered.length;

        // Cắt mảng để phân trang lười (Lazy Load)
        const displayData = filtered.slice(0, this.state.libLimit);

        // Render HTML UI cho từng Thẻ (Card)
        let html = displayData.map((item, index) => {
            const delay = Math.min(index * 30, 400);

            let typeColor = 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300 border-gray-200';
            const t = (item.type || '').toLowerCase();
            if (t.includes('noun')) typeColor = 'bg-blue-50 text-blue-600 border-blue-200 dark:bg-blue-900/30 dark:border-blue-800 dark:text-blue-400';
            else if (t.includes('verb')) typeColor = 'bg-rose-50 text-rose-600 border-rose-200 dark:bg-rose-900/30 dark:border-rose-800 dark:text-rose-400';
            else if (t.includes('adj')) typeColor = 'bg-emerald-50 text-emerald-600 border-emerald-200 dark:bg-emerald-900/30 dark:border-emerald-800 dark:text-emerald-400';
            else if (t.includes('adv')) typeColor = 'bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-900/30 dark:border-amber-800 dark:text-amber-400';

            const level = Math.min(item.level || 0, 5);
            const levelBars = Array.from({ length: 5 }).map((_, i) =>
                `<div class="h-1.5 w-full rounded-full ${i < level ? 'bg-emerald-500' : 'bg-gray-200 dark:bg-gray-700'}"></div>`
            ).join('');

            return `
            <div style="animation-delay: ${delay}ms" class="animate-fade-in-up opacity-0 bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group flex flex-col h-full relative dark:bg-gray-800 dark:border-gray-700">
                <div class="flex justify-between items-start mb-3 gap-2">
                    <div class="flex-1 min-w-0">
                        <h3 class="font-black text-gray-900 text-xl md:text-2xl leading-tight dark:text-white truncate" title="${item.word}">${item.word}</h3>
                        <p class="text-sm text-gray-500 font-mono mt-0.5 dark:text-gray-400">${item.pronun || '/.../'}</p>
                    </div>
                    <span class="text-[10px] font-black px-2.5 py-1 rounded-lg border uppercase tracking-wider shrink-0 ${typeColor}">${item.type || 'Word'}</span>
                </div>
                
                <p class="text-gray-700 text-sm md:text-base font-medium mb-4 line-clamp-2 flex-grow dark:text-gray-300 leading-relaxed" title="${item.coreDef || item.definition}">${item.coreDef || item.definition}</p>
                
                <div class="pt-4 border-t border-gray-50 dark:border-gray-700/50 mt-auto">
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center text-[11px] text-gray-500 font-bold dark:text-gray-400 bg-gray-50 dark:bg-gray-900 px-2 py-1 rounded-md">
                            <span class="mr-1">📂</span> <span class="truncate max-w-[120px]">${item.topic || 'General'}</span>
                        </div>
                        <div class="flex w-12 gap-0.5 ml-2" title="Mức độ thông thạo: ${level}/5">
                            ${levelBars}
                        </div>
                    </div>
                    
                    <div class="flex space-x-2">
                        <button onclick="app.playAudio(event, '${item.word.replace(/'/g, "\\'")}')" class="flex-1 py-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-xl transition text-xs font-bold flex justify-center items-center gap-1 dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-600 dark:hover:text-white">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                            Nghe
                        </button>
                        <button onclick="app.openModal(${item.id})" class="px-3 py-2 bg-gray-50 text-gray-600 hover:bg-blue-500 hover:text-white rounded-xl transition dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-blue-600" title="Sửa">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                        </button>
                        <button onclick="app.deleteWord(${item.id})" class="px-3 py-2 bg-gray-50 text-gray-600 hover:bg-red-500 hover:text-white rounded-xl transition dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-red-600" title="Xóa">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </button>
                    </div>
                </div>
            </div>`;
        }).join('');

        // Xử lý khi rỗng hoặc khi cần phân trang
        if (filtered.length === 0) {
            html = `
            <div class="col-span-full flex flex-col items-center justify-center py-20 text-center text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                <div class="text-5xl mb-4 opacity-50 grayscale">📭</div>
                <h3 class="text-lg font-bold text-gray-600 dark:text-gray-300 mb-1">Thư viện trống</h3>
                <p class="text-sm mb-5">Chưa có từ vựng nào phù hợp với tìm kiếm.</p>
                <button onclick="app.openModal()" class="px-6 py-3 bg-gradient-to-r from-primary to-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg hover:-translate-y-0.5 transition">
                    + Thêm từ vựng đầu tiên
                </button>
            </div>`;
        } else if (filtered.length > this.state.libLimit) {
            html += `
            <div class="col-span-full flex justify-center py-6 animate-fade-in-up">
                <button onclick="app.renderLibrary(true)" class="px-8 py-3 bg-indigo-50 text-indigo-600 font-bold rounded-2xl hover:bg-indigo-100 transition shadow-sm border border-indigo-100 dark:bg-indigo-900/30 dark:border-indigo-800/50 dark:text-indigo-400 dark:hover:bg-indigo-900/50 flex items-center gap-2">
                    <span class="text-lg leading-none">👇</span> Xem thêm (${filtered.length - this.state.libLimit} từ nữa)
                </button>
            </div>
            `;
        }

        list.innerHTML = html;
    },

    // ==========================================
    // 4. AI GENERATOR (TẠO TỪ TỰ ĐỘNG BẰNG AI)
    // ==========================================
    
    toggleAiModal: function () {
        const m = document.getElementById('modal-ai-generator');
        if (m) {
            m.classList.toggle('hidden');
            m.classList.toggle('flex');
            if (!m.classList.contains('hidden')) {
                m.children[0].classList.add('animate-pop-in');
                this.checkAPIStatus();
            }
        }
    },

    toggleApiKeyModal: function () {
        const m = document.getElementById('modal-api-key');
        if (m) {
            m.classList.toggle('hidden');
            m.classList.toggle('flex');
            if (!m.classList.contains('hidden')) {
                m.children[0].classList.add('animate-pop-in');
                document.getElementById('input-api-key').value = this.user.apiKey || '';
                setTimeout(() => document.getElementById('input-api-key').focus(), 100);
            }
        }
    },

    saveApiKey: function () {
        const keyInput = document.getElementById('input-api-key');
        if (!keyInput) return;

        const key = keyInput.value.trim();
        if (key !== "") {
            this.user.apiKey = key;
            this.saveUserData();
            this.checkAPIStatus();
            this.toggleApiKeyModal();
            this.toast("Đã kết nối API Key thành công! ⚡", "success");
        } else {
            this.toast("Vui lòng nhập API Key hợp lệ!", "error");
        }
    },

    /**
     * Xây dựng Prompt chuẩn kỹ thuật (Prompt Engineering) để gửi cho OpenAI.
     * Có tính năng loại trừ (Avoid) những từ vựng mà người dùng đã học trong chủ đề này.
     */
    getPromptContent: function () {
        const topicInput = document.getElementById('ai-topic-input').value.trim();
        if (!topicInput) { this.toast("Vui lòng nhập tình huống bạn muốn học!", "error"); return null; }
        const qty = document.getElementById('ai-qty').value;
        const lang = this.user.learningLang || 'English';

        const existingWords = this.data.filter(i => (i.topic || '').toLowerCase() === topicInput.toLowerCase()).map(i => i.word);
        const avoidString = existingWords.length > 0
            ? `\n\nCRITICAL RULE: The user already knows these words in this topic. DO NOT generate any of the following words: [${existingWords.join(', ')}]. Give me completely NEW words.`
            : '';

        // Tự động điều chỉnh quy tắc Phát âm & Ví dụ theo từng ngôn ngữ
        let pronunRule = '"pronun": Cách phát âm (Dùng chuẩn IPA).';
        let exampleRule = `"example": 1 câu ví dụ thực tế bằng ${lang}.`;
        
        if (lang === 'Chinese') {
            pronunRule = '"pronun": BẮT BUỘC TRẢ VỀ PINYIN (vd: nǐ hǎo). Tuyệt đối không dùng IPA.';
            exampleRule = '"example": 1 câu ví dụ thực tế bằng CHỮ HÁN (Hanzi).';
        } else if (lang === 'Japanese') {
            pronunRule = '"pronun": BẮT BUỘC TRẢ VỀ ROMAJI chuẩn.';
            exampleRule = '"example": 1 câu ví dụ thực tế bằng KANJI/KANA.';
        } else if (lang === 'Korean') {
             pronunRule = '"pronun": Romanization (Phiên âm Latinh của tiếng Hàn).';
             exampleRule = '"example": 1 câu ví dụ thực tế bằng HANGUL.';
        }

        return `Act as a street-smart, practical ${lang} teacher.
The user wants to learn exactly ${qty} highly useful items for this specific situation: "${topicInput}".${avoidString}

CRITICAL RULE: YOU MUST GENERATE VOCABULARY IN ${lang.toUpperCase()}! DO NOT GENERATE ENGLISH WORDS UNLESS THE TARGET LANGUAGE IS ENGLISH!

STRICT RULES:
1. "word": The target vocabulary word in ${lang.toUpperCase()} ONLY (MAXIMUM 2-3 WORDS). 
2. "emoji": Choose EXACTLY ONE highly specific emoji.
3. "coreWord": Extract the single most important root word in ${lang.toUpperCase()}.
4. "coreDef": Nghĩa tiếng Việt ngắn gọn nhất.
5. "definition": Giải thích chi tiết từ này bằng tiếng Việt.
6. ${exampleRule}
7. "exTranslation": Dịch câu ví dụ trên sang tiếng Việt.
8. "type": Noun, Verb, Adjective, Phrase, etc.
9. ${pronunRule}
10. Output MUST be a valid JSON Object. NO markdown formatting.

Format EXACTLY like this:
{
  "topic": "Tên chủ đề ngắn gọn bằng Tiếng Việt (kèm 1 Emoji)",
  "topicDesc": "1 câu mô tả ngắn gọn (bằng tiếng Việt) lợi ích khi học bộ từ này.",
  "words": [
    {"word": "...", "emoji": "...", "coreWord": "...", "coreDef": "...", "definition": "...", "example": "...", "exTranslation": "...", "type": "...", "pronun": "..."}
  ]
}`;
    },

    genPrompt: async function () {
        const p = this.getPromptContent();
        if (!p) return; 

        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(p);
            } else {
                const temp = document.createElement('textarea');
                temp.value = p;
                temp.style.position = 'fixed';
                temp.style.opacity = '0';
                document.body.appendChild(temp);
                temp.focus();
                temp.select();
                document.execCommand('copy');
                document.body.removeChild(temp);
            }
            this.toast("Đã copy Prompt! Dán vào AI nhé.", "info");
        } catch (err) {
            this.toast("Không thể copy. Hãy thử lại!", "error");
        }
    },

    /**
     * Gọi API trực tiếp đến OpenAI và áp dụng hiệu ứng thanh tải giả lập (Fake Progress).
     * Giúp UX mượt mà hơn trong lúc chờ phản hồi từ máy chủ.
     */
    runAutoAI: async function () {
        const activeKey = this.user.apiKey || this.apiKey;
        if (!activeKey || activeKey.includes('PASTE')) {
            document.getElementById('ai-status-bar').classList.remove('hidden');
            return this.toast("Vui lòng cấu hình API Key ở tab Hồ Sơ!", "error");
        }

        const prompt = this.getPromptContent();
        if (!prompt) return;

        const btn = document.getElementById('ai-btn-auto-trigger');
        const oldText = btn.innerHTML;
        const oldClass = btn.className; 

        let progress = 0;
        btn.disabled = true;
        btn.className = "w-full py-4 bg-gray-800 text-white rounded-2xl font-black text-lg shadow-inner relative overflow-hidden transition-all";

        // Vòng lặp tăng thanh tiến độ ảo
        const timerInterval = setInterval(() => {
            if (progress < 50) progress += Math.floor(Math.random() * 8) + 2;
            else if (progress < 85) progress += Math.floor(Math.random() * 4) + 1;
            else if (progress < 99) progress += 1;

            if (progress > 99) progress = 99; // Giữ ở 99% cho đến khi API trả về

            btn.innerHTML = `
                <div class="absolute top-0 left-0 h-full bg-gradient-to-r from-indigo-500 to-purple-600 transition-all duration-200" style="width: ${progress}%"></div>
                <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPgo8cmVjdCB3aWR0aD0iOCIgaGVpZ2h0PSI4IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMDUiLz4KPHBhdGggZD0iTTAgMEw4IDhaTTAgOEw4IDBaIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1vcGFjaXR5PSIwLjEiLz4KPC9zdmc+')] opacity-20 pointer-events-none"></div>
                <span class="relative z-10 flex items-center justify-center gap-2 drop-shadow-md text-white">
                    <span class="animate-spin">⚒️</span> ĐANG RÈN TỪ... ${progress}%
                </span>
            `;
        }, 150);

        try {
            const res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${activeKey}` },
                body: JSON.stringify({ model: "gpt-3.5-turbo", messages: [{ role: "user", content: prompt }], temperature: 0.7 })
            });

            if (!res.ok) throw new Error("Lỗi kết nối OpenAI API");

            clearInterval(timerInterval);
            btn.innerHTML = `
                <div class="absolute top-0 left-0 h-full bg-emerald-500 transition-all duration-100" style="width: 100%"></div>
                <span class="relative z-10 flex items-center justify-center gap-2 drop-shadow-md text-white">✨ HOÀN TẤT 100%</span>
            `;
            await new Promise(r => setTimeout(r, 400)); // Dừng hình 0.4s để user kịp nhìn thấy dòng chữ hoàn tất

            const data = await res.json();
            let content = data.choices[0].message.content.replace(/```json/g, '').replace(/```/g, '').trim();

            const jsonStart = content.indexOf('{');
            const jsonEnd = content.lastIndexOf('}');
            if (jsonStart === -1 || jsonEnd === -1) throw new Error("Dữ liệu AI trả về không hợp lệ!");

            document.getElementById('ai-json').value = content.substring(jsonStart, jsonEnd + 1);
            this.processAI();
            this.toggleAiModal();

        } catch (err) {
            clearInterval(timerInterval);
            this.toast(err.message, "error");
            document.getElementById('ai-manual-mini').classList.remove('hidden'); // Fallback sang nhập thủ công
        } finally {
            btn.className = oldClass;
            btn.innerHTML = oldText;
            btn.disabled = false;
        }
    },

    /**
     * Parse chuỗi JSON thành object và chèn vào Database (Library).
     * Bỏ qua các từ đã tồn tại để tránh trùng lặp.
     */
    processAI: function () {
        const raw = document.getElementById('ai-json').value;
        if (!raw.trim()) return this.toast("Không có dữ liệu JSON!", "error");

        try {
            const parsed = JSON.parse(raw);
            let arr = [];
            const userInputTopic = document.getElementById('ai-topic-input').value.trim();
            let rawTopic = userInputTopic;
            let topicDesc = 'Bộ từ vựng thực chiến được tinh chỉnh bởi AI.';

            if (Array.isArray(parsed)) {
                arr = parsed;
                if (!rawTopic) rawTopic = arr[0]?.topic || 'AI Generated';
            } else {
                arr = parsed.words || [];
                if (!rawTopic) rawTopic = parsed.topic || 'AI Generated';
                topicDesc = parsed.topicDesc || topicDesc;
            }

            let forcedTopic = rawTopic.charAt(0).toUpperCase() + rawTopic.slice(1);
            let count = 0;
            let skipped = 0;

            arr.forEach(item => {
                if (item.word) {
                    const exists = this.data.some(ex => ex.word.toLowerCase() === item.word.trim().toLowerCase());
                    if (!exists) {
                        this.data.unshift({
                            id: (window.crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now() + Math.random()),
                            word: item.word,
                            emoji: item.emoji || '💡', 
                            type: item.type || 'Word',
                            pronun: item.pronun || '',
                            definition: item.definition || '',
                            coreWord: item.coreWord || '',
                            coreDef: item.coreDef || '',
                            example: item.example || '',
                            exTranslation: item.exTranslation || '',
                            topic: forcedTopic,
                            topicDesc: topicDesc, 
                            level: 0, nextReview: 0
                        });
                        count++;
                    } else {
                        skipped++;
                    }
                }
            });

            this.navigate('library');
            this.refreshViews();

            let msg = `Thành công! Đã thêm ${count} từ vào chủ đề "${forcedTopic}"`;
            if (skipped > 0) msg += ` (Bỏ qua ${skipped} trùng)`;
            this.toast(msg, "success");
            document.getElementById('ai-json').value = '';

        } catch (e) {
            this.toast("Lỗi định dạng JSON! Hãy thử lại.", "error");
        }
    },

    toggleAI: function () {
        this.navigate('ai');
    },

    forceManualMode: function () {
        const autoBtn = document.getElementById('ai-btn-auto');
        const manualBtn = document.getElementById('ai-btn-manual');
        const manualPanel = document.getElementById('ai-manual-panel');

        if (autoBtn) autoBtn.classList.add('hidden');
        if (manualBtn) manualBtn.classList.remove('hidden');
        if (manualPanel) manualPanel.classList.remove('hidden');
    },

    checkAPIStatus: function () {
        const validKey = (this.apiKey && !this.apiKey.includes('PASTE')) || (this.user.apiKey && this.user.apiKey.length > 10);

        const statusBar = document.getElementById('ai-status-bar');
        const autoBtn = document.getElementById('ai-btn-auto-trigger');
        const manualMini = document.getElementById('ai-manual-mini');

        if (validKey) {
            if (statusBar) statusBar.classList.add('hidden');
            if (autoBtn) {
                autoBtn.style.display = '';
                if (autoBtn.nextElementSibling) autoBtn.nextElementSibling.style.display = '';
            }
            if (manualMini) manualMini.classList.add('hidden');
        } else {
            if (statusBar) statusBar.classList.remove('hidden');
            if (autoBtn) {
                autoBtn.style.display = 'none';
                if (autoBtn.nextElementSibling) autoBtn.nextElementSibling.style.display = 'none';
            }
            if (manualMini) manualMini.classList.remove('hidden');
        }
    },


    // ==========================================
    // 5. HỆ THỐNG LUYỆN NGHE & PODCAST
    // ==========================================
    
    renderListeningTopics: function () {
        // Gom nhóm data theo Topic và đếm số lượng câu Audio có sẵn
        const groups = this.data.reduce((acc, item) => {
            const t = item.topic || 'General';
            if (!acc[t]) acc[t] = { total: 0, hasAudio: 0, desc: item.topicDesc || 'Luyện nghe phản xạ với danh sách từ vựng chuyên ngành này.' };
            acc[t].total++;
            if (item.example) acc[t].hasAudio++;
            return acc;
        }, {});

        const grid = document.getElementById('listening-topic-grid');
        if (!grid) return;

        let html = ``;
        html += Object.entries(groups).map(([topic, data], index) => {
            const count = data.total;
            const audioCount = data.hasAudio;
            const emojiMatch = topic.match(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/u);
            const displayIcon = emojiMatch ? emojiMatch[0] : '💿';
            const cleanTopic = topic.replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, '').trim() || topic;
            const delay = Math.min(index * 30, 300);
            const isReady = audioCount > 0;
            const safeTopic = topic.replace(/'/g, "\\'");

            return `<div style="animation-delay: ${delay}ms" class="animate-fade-in-up opacity-0 bg-white rounded-3xl shadow-sm border border-gray-100 transition-all duration-300 group dark:bg-gray-800 dark:border-gray-700 flex flex-col p-4 md:p-5 relative hover:shadow-xl hover:-translate-y-1 hover:border-pink-300">
                <div class="flex items-center gap-4 mb-4 relative z-10">
                    <div class="w-16 h-16 shrink-0 rounded-2xl flex items-center justify-center text-3xl bg-gradient-to-br from-pink-50 to-rose-50 text-pink-600 shadow-inner group-hover:rotate-12 transition-transform duration-500 dark:from-pink-900/20 dark:to-rose-900/20 relative overflow-hidden">
                        <div class="absolute inset-0 bg-white/40 dark:bg-black/20 rounded-2xl"></div>
                        <div class="absolute w-2 h-2 bg-white rounded-full shadow-sm z-20 top-2 right-2"></div> 
                        <span class="relative z-10">${displayIcon}</span>
                    </div>
                    <div class="flex-1 min-w-0">
                        <h3 class="font-black text-base sm:text-lg lg:text-xl leading-tight transition-colors truncate text-gray-800 dark:text-white group-hover:text-pink-600">${cleanTopic}</h3>
                        <p class="text-[10px] md:text-[11px] xl:text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2 font-medium leading-snug">${data.desc}</p>
                    </div>
                </div>
                
                <div class="mt-auto pt-4 border-t border-gray-50 dark:border-gray-700/50 relative z-10">
                    <div class="flex items-center justify-between mb-3">
                        <span class="text-xs font-bold text-gray-400 uppercase tracking-widest">Trạng thái</span>
                        ${isReady
                    ? `<span class="bg-emerald-50 text-emerald-600 px-2.5 py-1 rounded-md text-[10px] font-black dark:bg-emerald-900/30 dark:text-emerald-400 flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> ${audioCount} CÂU SẴN SÀNG</span>`
                    : `<span class="bg-amber-50 text-amber-600 px-2.5 py-1 rounded-md text-[10px] font-black dark:bg-amber-900/30 dark:text-amber-400 flex items-center gap-1">⚠️ TỪ ĐƠN</span>`
                }
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        <button onclick="app.startListening('${safeTopic}')" class="flex items-center justify-center gap-1.5 w-full py-2.5 bg-pink-50 text-pink-600 rounded-xl font-bold text-xs hover:bg-pink-600 hover:text-white transition-all shadow-sm dark:bg-pink-900/30 dark:text-pink-400 dark:hover:bg-pink-600 dark:hover:text-white">
                            <span class="text-sm">🎯</span> Luyện Tập
                        </button>
                        <button onclick="app.startPodcast('${safeTopic}')" class="flex items-center justify-center gap-1.5 w-full py-2.5 bg-indigo-50 text-indigo-600 rounded-xl font-bold text-xs hover:bg-indigo-600 hover:text-white transition-all shadow-sm dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-600 dark:hover:text-white">
                            <span class="text-sm">📻</span> Podcast
                        </button>
                    </div>
                </div>
            </div>`;
        }).join('');
        grid.innerHTML = html;
    },

    toggleListenAccent: function () {
        this.state.listenAccent = !this.state.listenAccent;
        const btn = document.getElementById('listen-accent-btn');
        if (btn) btn.innerHTML = this.state.listenAccent ? '🌍 Trộn Giọng' : '🇺🇸 Cố định';
    },

    toggleListenNoise: function () {
        this.state.listenNoise = !this.state.listenNoise;
        const btn = document.getElementById('listen-noise-btn');
        if (btn) btn.innerHTML = this.state.listenNoise ? '🌧️ Ồn ào' : '☕ Yên tĩnh';
        if (!this.state.listenNoise) this.stopNoise();
    },

    toggleListenSpeed: function () {
        const speeds = [1.0, 1.2, 0.7];
        let idx = speeds.indexOf(this.state.listenSpeed) + 1;
        if (idx >= speeds.length) idx = 0;
        this.state.listenSpeed = speeds[idx];
        const btn = document.getElementById('listen-speed-btn');
        if (btn) {
            const labels = { 1.0: '▶️ 1.0x', 1.2: '🔥 1.2x (Native)', 0.7: '🐢 0.7x (Slow)' };
            btn.innerHTML = labels[this.state.listenSpeed];
        }
    },

    /**
     * Chấm điểm phát âm của người dùng bằng Web Speech API.
     * So khớp chuỗi giọng nói của User với câu mẫu (target sentence).
     */
    checkSentencePronunciation: function (event) {
        if (event) event.stopPropagation();
        if (this.isListening) return;

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) return this.toast("Trình duyệt không hỗ trợ chấm điểm Mic!", "error");

        const currentWord = this.quizData[this.quizState.index];
        const sentenceToSay = (currentWord.example || "").toLowerCase().replace(/[.,!?]/g, '');
        if (!sentenceToSay) return;

        const btn = event ? event.currentTarget : null;
        const oldHtml = btn ? btn.innerHTML : '';

        this.isListening = true;
        if (btn) btn.innerHTML = `<span class="animate-pulse">🔴 Đang nghe...</span>`;

        const recognition = new SpeechRecognition();
        recognition.lang = this.user.voiceLang || 'en-US';
        recognition.interimResults = false;

        try {
            recognition.start();
            this.toast("🎙️ Hãy đọc to CẢ CÂU ví dụ với tốc độ và nhịp điệu vừa nghe!", "info");
        } catch (err) {
            this.isListening = false;
            if (btn) btn.innerHTML = oldHtml;
            return;
        }

        recognition.onresult = (e) => {
            const transcript = e.results[0][0].transcript.toLowerCase().replace(/[.,!?]/g, '');
            const expectedWords = sentenceToSay.split(' ');
            const spokenWords = transcript.split(' ');
            let matchCount = 0;
            expectedWords.forEach(w => { if (spokenWords.includes(w)) matchCount++; });
            const matchRate = matchCount / expectedWords.length;

            if (matchRate >= 0.6 || transcript.includes(currentWord.word.toLowerCase())) {
                this.toast(`✅ Quá đỉnh! Phát âm chuẩn người bản xứ.`, "success");
                if (btn) {
                    btn.innerHTML = `🌟 Hoàn Hảo`;
                    btn.classList.replace('bg-emerald-600', 'bg-yellow-500');
                    btn.classList.replace('text-white', 'text-yellow-900');
                }
            } else {
                this.toast(`❌ Bạn đọc là: "${transcript}". Chú ý nối âm giống audio hơn nhé!`, "error");
            }
        };

        recognition.onerror = () => { this.isListening = false; if (btn) btn.innerHTML = oldHtml; };
        recognition.onend = () => { this.isListening = false; if (btn && btn.innerHTML.includes('Đang nghe')) btn.innerHTML = oldHtml; };
    },

    setListenMode: function (mode, btnEl) {
        this.state.listenMode = mode;
        const activeClasses = ['bg-white', 'text-pink-600', 'border-pink-200', 'font-black', 'shadow-sm', 'dark:bg-pink-900/40', 'dark:text-pink-400', 'dark:border-pink-800/50'];
        const inactiveClasses = ['text-gray-500', 'font-bold', 'border-transparent', 'hover:bg-white', 'hover:text-gray-800', 'hover:shadow-sm'];

        document.querySelectorAll('.listen-mode-btn').forEach(btn => {
            btn.classList.remove(...activeClasses);
            btn.classList.add(...inactiveClasses);
        });

        btnEl.classList.remove(...inactiveClasses);
        btnEl.classList.add(...activeClasses);
    },

    startListening: function (topic) {
        this.state.quizMode = 'listen';
        this.navigate('quiz');
        document.getElementById('quiz-intro').classList.add('hidden');
        this.startQuiz(topic);
    },

    // Dữ liệu vòng lặp của Podcast Thụ động
    podcastState: {
        isActive: false, 
        isPaused: false, 
        playlist: [], 
        currentIndex: 0,
        step: 0, // Quy trình: 0 (Đọc từ), 1 (Nghĩa Tiếng Việt), 2 (Ví dụ)
        timeoutId: null,
        sleepTimer: 0, 
        sleepInterval: null, 
        isZenMode: false 
    },

    startPodcast: function (topic) {
        let pool = topic === 'ALL' ? this.data : this.data.filter(i => (i.topic || 'General') === topic);
        if (pool.length === 0) return this.toast("Chủ đề này chưa có từ vựng!", "info");

        this.podcastState.playlist = pool.sort(() => 0.5 - Math.random());
        this.podcastState.currentIndex = 0;
        this.podcastState.step = 0;
        this.podcastState.isActive = true;
        this.podcastState.isPaused = false;

        const player = document.getElementById('podcast-player');
        player.classList.remove('hidden');
        setTimeout(() => player.classList.remove('translate-y-full', 'opacity-0'), 10);

        this.toast("🎧 Bắt đầu chế độ Nghe Thụ Động!", "success");
        this.playPodcastItem();
    },

    openModeInfo: function () {
        const modal = document.getElementById('mode-info-modal');
        const card = document.getElementById('mode-info-card');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        setTimeout(() => {
            modal.classList.remove('opacity-0');
            card.classList.remove('scale-95');
            card.classList.add('scale-100');
        }, 10);
    },

    closeModeInfo: function () {
        const modal = document.getElementById('mode-info-modal');
        const card = document.getElementById('mode-info-card');
        modal.classList.add('opacity-0');
        card.classList.remove('scale-100');
        card.classList.add('scale-95');
        setTimeout(() => {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }, 300); 
    },

    toggleZenMode: function () {
        this.podcastState.isZenMode = !this.podcastState.isZenMode;
        const zenEl = document.getElementById('podcast-zen-overlay');

        if (this.podcastState.isZenMode) {
            zenEl.classList.remove('hidden');
            setTimeout(() => zenEl.classList.remove('opacity-0'), 10);
            this.updatePodcastUI();
            if (!this.podcastState.isActive) this.startPodcast('ALL'); 
        } else {
            zenEl.classList.add('opacity-0');
            setTimeout(() => zenEl.classList.add('hidden'), 700);
        }
    },

    cyclePodcastTimer: function () {
        const cycles = [0, 15, 30, 60];
        let idx = cycles.indexOf(this.podcastState.sleepTimer) + 1;
        if (idx >= cycles.length) idx = 0;
        this.podcastState.sleepTimer = cycles[idx];

        const btn = document.getElementById('podcast-btn-timer');
        clearInterval(this.podcastState.sleepInterval);

        if (this.podcastState.sleepTimer === 0) {
            if (btn) btn.innerHTML = `<span class="text-sm">🌙</span>`;
            document.getElementById('zen-timer-display').classList.add('hidden');
            this.toast("Đã tắt Hẹn giờ ngủ.", "info");
        } else {
            let timeLeft = this.podcastState.sleepTimer * 60;
            if (btn) btn.innerHTML = `<span class="text-[10px] font-black tracking-widest">${this.podcastState.sleepTimer}m</span>`;
            this.toast(`💤 Tự động tắt âm thanh sau ${this.podcastState.sleepTimer} phút!`, "success");

            document.getElementById('zen-timer-display').classList.remove('hidden');

            this.podcastState.sleepInterval = setInterval(() => {
                timeLeft--;
                const m = Math.floor(timeLeft / 60);
                const s = timeLeft % 60;
                document.getElementById('zen-timer-text').textContent = `${m}:${s < 10 ? '0' + s : s}`;

                if (timeLeft <= 0) {
                    clearInterval(this.podcastState.sleepInterval);
                    this.stopPodcast();
                    if (this.podcastState.isZenMode) this.toggleZenMode();
                }
            }, 1000);
        }
    },

    stopPodcast: function () {
        this.podcastState.isActive = false;
        clearTimeout(this.podcastState.timeoutId);
        clearInterval(this.podcastState.sleepInterval);
        this.podcastState.sleepTimer = 0;

        const btnTimer = document.getElementById('podcast-btn-timer');
        if (btnTimer) btnTimer.innerHTML = `<span class="text-sm">🌙</span>`;

        this.stopAudio();

        const player = document.getElementById('podcast-player');
        player.classList.add('translate-y-full', 'opacity-0');
        setTimeout(() => player.classList.add('hidden'), 300);

        if (this.podcastState.isZenMode) this.toggleZenMode();
    },

    togglePodcast: function () {
        this.podcastState.isPaused = !this.podcastState.isPaused;
        const btn = document.getElementById('podcast-btn-pause');
        const disc = document.getElementById('podcast-disc');

        if (this.podcastState.isPaused) {
            btn.innerHTML = `<svg class="w-5 h-5 ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
            disc.classList.remove('animate-[spin_4s_linear_infinite]');
            this.stopAudio();
            clearTimeout(this.podcastState.timeoutId);
        } else {
            btn.innerHTML = `<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/></svg>`;
            disc.classList.add('animate-[spin_4s_linear_infinite]');
            this.playPodcastItem();
        }
    },

    updatePodcastUI: function () {
        const item = this.podcastState.playlist[this.podcastState.currentIndex];
        document.getElementById('podcast-word').textContent = item.word;
        document.getElementById('podcast-def').textContent = item.definition;
        document.getElementById('podcast-progress-text').textContent = `${this.podcastState.currentIndex + 1}/${this.podcastState.playlist.length}`;
        document.getElementById('podcast-progress-bar').style.width = `${((this.podcastState.currentIndex + 1) / this.podcastState.playlist.length) * 100}%`;

        if (this.podcastState.isZenMode) {
            const zenWord = document.getElementById('zen-word');
            zenWord.style.opacity = '0'; 
            setTimeout(() => {
                zenWord.textContent = item.word;
                document.getElementById('zen-pronun').textContent = item.pronun || '/.../';
                document.getElementById('zen-def').textContent = item.definition;
                document.getElementById('zen-ex').textContent = item.example ? `"${item.example}"` : '';
                zenWord.style.opacity = '1';
            }, 300);
        }
    },

    nextPodcast: function () {
        if (!this.podcastState.isActive) return;
        clearTimeout(this.podcastState.timeoutId);
        this.stopAudio();
        this.podcastState.currentIndex++;
        this.podcastState.step = 0;

        if (this.podcastState.currentIndex >= this.podcastState.playlist.length) {
            this.podcastState.currentIndex = 0; 
        }
        if (!this.podcastState.isPaused) this.playPodcastItem();
        else this.updatePodcastUI();
    },

    prevPodcast: function () {
        if (!this.podcastState.isActive) return;
        clearTimeout(this.podcastState.timeoutId);
        this.stopAudio();
        this.podcastState.currentIndex--;
        this.podcastState.step = 0;

        if (this.podcastState.currentIndex < 0) {
            this.podcastState.currentIndex = this.podcastState.playlist.length - 1;
        }
        if (!this.podcastState.isPaused) this.playPodcastItem();
        else this.updatePodcastUI();
    },

    /**
     * Logic đệ quy xử lý luồng âm thanh Podcast.
     * Thứ tự: Đọc Từ (EN) -> Nghĩa (VI) -> Câu ví dụ (EN)
     */
    playPodcastItem: function () {
        if (!this.podcastState.isActive || this.podcastState.isPaused) return;

        const item = this.podcastState.playlist[this.podcastState.currentIndex];
        this.updatePodcastUI();

        const scheduleNext = (delay) => {
            this.podcastState.timeoutId = setTimeout(() => {
                this.podcastState.step++;
                this.playPodcastItem();
            }, delay);
        };

        if (this.podcastState.step === 0) {
            this.playAudio(null, item.word, false, () => scheduleNext(800));

        } else if (this.podcastState.step === 1) {
            if (window.speechSynthesis) {
                const msg = new SpeechSynthesisUtterance(item.definition);
                msg.lang = 'vi-VN';
                msg.onend = () => scheduleNext(800);
                msg.onerror = () => scheduleNext(800);
                window.speechSynthesis.speak(msg);
            } else {
                scheduleNext(800);
            }

        } else if (this.podcastState.step === 2) {
            if (item.example) {
                const safeEx = item.example.replace(/^"|"$/g, '').trim();
                this.playAudio(null, safeEx, false, () => scheduleNext(1000));
            } else {
                this.podcastState.step = 3;
                this.playPodcastItem();
            }
        } else {
            this.nextPodcast();
        }
    },


    // ==========================================
    // 6. THI THỬ ĐỌC HIỂU (MOCK TEST ENGINE)
    // ==========================================

    renderMockHistory: function () {
        const list = document.getElementById('mock-history-list');
        const count = document.getElementById('mock-history-count');
        if (!list || !count) return;

        count.textContent = this.mockHistory.length;

        if (this.mockHistory.length === 0) {
            list.innerHTML = `<div class="col-span-full text-center py-16 bg-white rounded-3xl border border-dashed border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                <div class="text-6xl mb-4 opacity-50 grayscale">📭</div>
                <h3 class="text-lg font-bold text-gray-600 dark:text-gray-300 mb-1">Chưa có đề thi nào</h3>
                <p class="text-sm text-gray-400 mb-5">Hãy tạo đề thi đầu tiên để bắt đầu luyện tập.</p>
                <button onclick="app.toggleMockModal()" class="px-6 py-3 bg-indigo-50 text-indigo-600 rounded-xl text-sm font-bold hover:bg-indigo-100 transition dark:bg-indigo-900/30 dark:text-indigo-400">✨ Tạo đề ngay</button>
            </div>`;
            return;
        }

        list.innerHTML = this.mockHistory.map((m, index) => {
            const delay = Math.min(index * 30, 400);
            const qCount = m.questions ? m.questions.length : 0;
            const time = m.timeLimit ? Math.floor(m.timeLimit / 60) : 10;
            const dateStr = new Date(m.createdAt).toLocaleDateString('vi-VN');

            return `
            <div style="animation-delay: ${delay}ms" class="animate-fade-in-up opacity-0 bg-white p-5 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 hover:border-indigo-200 transition-all duration-300 cursor-pointer group flex flex-col relative dark:bg-gray-800 dark:border-gray-700 dark:hover:border-indigo-500/50" onclick="app.loadSavedMock('${m.id}')">
                <button onclick="app.deleteSavedMock('${m.id}'); event.stopPropagation();" class="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-red-50 hover:text-red-500 transition opacity-0 group-hover:opacity-100 z-10 dark:bg-gray-700 dark:hover:bg-red-900/30" title="Xóa đề">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                </button>
                <div class="w-12 h-12 bg-gradient-to-br from-indigo-50 to-blue-50 text-indigo-600 rounded-2xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 group-hover:rotate-6 transition-transform shadow-inner border border-indigo-100/50 dark:from-indigo-900/40 dark:to-blue-900/40 dark:border-indigo-800/50 dark:text-indigo-400">📄</div>
                <h4 class="font-black text-gray-800 text-lg leading-tight mb-3 line-clamp-2 dark:text-white group-hover:text-primary transition-colors flex-1">${m.title || 'Bài đọc IELTS/TOEIC'}</h4>
                <div class="mt-auto pt-4 border-t border-gray-50 dark:border-gray-700/50 flex flex-wrap items-center gap-2 text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                    <span class="bg-gray-100 px-2 py-1 rounded dark:bg-gray-700">⏱ ${time}p</span>
                    <span class="bg-gray-100 px-2 py-1 rounded dark:bg-gray-700">📝 ${qCount} câu</span>
                    <span class="ml-auto flex items-center text-gray-400"><svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>${dateStr}</span>
                </div>
            </div>
            `;
        }).join('');
    },

    toggleMockModal: function () {
        const m = document.getElementById('modal-mock-create');
        if (m) {
            m.classList.toggle('hidden');
            m.classList.toggle('flex');
            if (!m.classList.contains('hidden')) {
                m.children[0].classList.add('animate-pop-in');
            }
        }
    },

    enterMockWorkspace: function () {
        document.body.classList.add('mock-focus-mode');
        document.getElementById('mocktest-lobby').classList.add('hidden');
        const ws = document.getElementById('mocktest-workspace');
        ws.classList.remove('hidden');
        ws.classList.add('flex');
    },

    exitMockWorkspace: function () {
        document.body.classList.remove('mock-focus-mode');
        document.getElementById('mocktest-lobby').classList.remove('hidden');
        const ws = document.getElementById('mocktest-workspace');
        ws.classList.add('hidden');
        ws.classList.remove('flex');
    },

    loadSavedMock: function (id) {
        const mock = this.mockHistory.find(m => m.id === id);
        if (mock) {
            this.mockData = mock;
            this.enterMockWorkspace();
            this.startMockTest();
        }
    },

    deleteSavedMock: function (id) {
        this.confirmAction("Xóa đề thi này khỏi lịch sử?", () => {
            this.mockHistory = this.mockHistory.filter(m => m.id !== id);
            this.saveMockHistory();
            this.toast("Đã xóa đề!", "success");
        });
    },

    autoSaveMockData: function (parsedData) {
        if (!parsedData.id) parsedData.id = 'mock_' + Date.now().toString();
        if (!parsedData.createdAt) parsedData.createdAt = Date.now();

        if (!this.mockHistory) this.mockHistory = [];
        const exists = this.mockHistory.find(m => m.id === parsedData.id);
        if (!exists) {
            this.mockHistory.unshift(parsedData);
            if (this.mockHistory.length > 50) this.mockHistory.pop();
            this.saveMockHistory();
        }
    },

    mockState: { isActive: false, timeLeft: 0, timerInterval: null, answers: {}, isSubmitted: false },
    mockData: {}, 

    getMockPromptContent: function (isRandom = false) {
        let topic = document.getElementById('mock-topic-input').value.trim();
        const level = document.getElementById('mock-level-input').value;

        if (isRandom || !topic) {
            const randomTopics = ["Global Warming", "History of Art", "Space Exploration", "Psychology of Sleep", "Future of Work", "Oceanography", "Artificial Intelligence in Medicine", "Ancient Civilizations", "Healthy Eating Habits", "The Industrial Revolution"];
            topic = randomTopics[Math.floor(Math.random() * randomTopics.length)];
        }

        return `Act as an expert English examiner. Generate a Reading Comprehension test.
Topic: ${topic}
Level/Difficulty: ${level}
Requirements:
1. Write an engaging reading passage (about 250-300 words). Format it with simple HTML tags like <p>, <b>, <i> only.
2. Generate exactly 4 multiple-choice questions based on the passage.
3. Provide a short, easy-to-understand explanation in Vietnamese for why the correct answer is correct.

STRICT JSON RULES (CRITICAL):
- Output MUST be a valid JSON object ONLY. No markdown wrapping (no \`\`\`json).
- NEVER use double quotes (") inside your strings. If you write HTML attributes, use SINGLE QUOTES ONLY (e.g. <p class='text'>).
- Do NOT use actual line breaks (newlines) inside strings.

Format exactly like this:
{
  "title": "Short Title",
  "timeLimit": 600,
  "passage": "<h3 class='text-2xl font-black mb-4'>Title</h3><p class='mb-4'>Paragraph 1...</p>",
  "questions": [
    {
      "id": 1,
      "text": "Question 1 text?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct": 0,
      "explanation": "Lời giải thích bằng Tiếng Việt..."
    }
  ]
}`;
    },

    copyMockPrompt: async function () {
        const p = this.getMockPromptContent(document.getElementById('mock-topic-input').value.trim() === '');
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(p);
            } else {
                const temp = document.createElement('textarea');
                temp.value = p; document.body.appendChild(temp);
                temp.select(); document.execCommand('copy');
                document.body.removeChild(temp);
            }
            this.toast("Đã copy lệnh! Hãy dán vào AI nhé.", "info");
        } catch (e) { this.toast("Lỗi copy!", "error"); }
    },

    processManualMock: function () {
        const raw = document.getElementById('mock-manual-json').value;
        if (!raw.trim()) return this.toast("Vui lòng dán JSON vào ô!", "error");

        try {
            let content = raw.replace(/```json/g, '').replace(/```/g, '').trim();
            const startIdx = content.indexOf('{');
            const endIdx = content.lastIndexOf('}');
            if (startIdx !== -1 && endIdx !== -1) {
                content = content.substring(startIdx, endIdx + 1);
            }

            const parsedData = JSON.parse(content);
            if (!parsedData.passage || !parsedData.questions) throw new Error("Thiếu passage hoặc questions");

            this.mockData = parsedData;
            this.autoSaveMockData(parsedData);
            this.enterMockWorkspace();
            this.startMockTest();
            this.toast("Đã nạp đề thi thành công!", "success");
            document.getElementById('mock-manual-json').value = '';
            this.toggleMockModal();
        } catch (e) {
            this.toast("JSON từ AI bị lỗi cú pháp! Hãy kiểm tra lại.", "error");
        }
    },

    generateMockTest: async function (isRandom = false, btnElement = null) {
        const btn = btnElement || document.querySelector('#mocktest-lobby button');

        if (!isRandom && !document.getElementById('mock-topic-input').value.trim()) {
            return this.toast("Hãy nhập chủ đề bạn muốn! Hoặc bấm 'Bốc Đề' ở dưới.", "error");
        }

        if (!this.apiKey && (!this.user.apiKey || this.user.apiKey.length < 10)) {
            document.getElementById('mock-manual-panel').classList.remove('hidden');
            return this.toast("Chưa có API Key! Hãy dùng chế độ thủ công bên dưới nhé.", "info");
        }

        const oldBtnText = btn.innerHTML;
        btn.innerHTML = `<span class="animate-spin mr-2">🔄</span> Đang bốc...`;
        btn.disabled = true;

        const prompt = this.getMockPromptContent(isRandom);

        try {
            const res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.user.apiKey || this.apiKey}` },
                body: JSON.stringify({
                    model: "gpt-3.5-turbo",
                    messages: [{ role: "user", content: prompt }],
                    temperature: 0.7
                })
            });

            if (!res.ok) throw new Error("Lỗi kết nối OpenAI API");
            const data = await res.json();
            let content = data.choices[0].message.content.trim();
            content = content.replace(/```json/g, '').replace(/```/g, '').trim();

            const parsedData = JSON.parse(content);
            this.mockData = parsedData;
            this.autoSaveMockData(parsedData);
            this.enterMockWorkspace();
            this.startMockTest();
            this.toast("Đã tạo đề thi thành công! Thời gian: 10 phút.", "success");
            this.toggleMockModal();

        } catch (err) {
            this.toast("AI đang bận hoặc lỗi format. Vui lòng thử lại!", "error");
        } finally {
            btn.innerHTML = oldBtnText;
            btn.disabled = false;
        }
    },

    quitMockTest: function () {
        if (this.mockState.timerInterval) clearInterval(this.mockState.timerInterval);
        this.mockState.isActive = false;
        this.exitMockWorkspace();
    },

    switchMockTab: function (tab) {
        const p = document.getElementById('mock-panel-passage');
        const q = document.getElementById('mock-panel-questions');
        const tp = document.getElementById('mock-tab-passage');
        const tq = document.getElementById('mock-tab-questions');

        if (!p || !q) return;

        if (tab === 'passage') {
            p.classList.remove('-translate-x-full');
            q.classList.remove('-translate-x-full');
            tp.className = 'flex-1 py-2.5 rounded-lg bg-white text-primary font-black shadow-sm text-xs transition dark:bg-gray-800 dark:text-white';
            tq.className = 'flex-1 py-2.5 rounded-lg text-gray-500 font-bold text-xs transition dark:text-gray-400';
        } else {
            p.classList.add('-translate-x-full');
            q.classList.add('-translate-x-full');
            tq.className = 'flex-1 py-2.5 rounded-lg bg-white text-primary font-black shadow-sm text-xs transition dark:bg-gray-800 dark:text-white';
            tp.className = 'flex-1 py-2.5 rounded-lg text-gray-500 font-bold text-xs transition dark:text-gray-400';
        }
    },

    startMockTest: function () {
        this.mockState.isActive = true;
        this.mockState.isSubmitted = false;
        this.mockState.answers = {};
        this.mockState.timeLeft = this.mockData.timeLimit || 600;

        this.switchMockTab('passage');

        document.getElementById('mocktest-title').textContent = this.mockData.title;
        document.getElementById('mocktest-passage').innerHTML = this.mockData.passage;

        document.getElementById('mocktest-footer-actions').innerHTML = `
            <div class="text-sm font-bold text-gray-500 dark:text-gray-400">
                Đã làm: <span id="mock-progress-text" class="text-primary text-lg ml-1">0/${this.mockData.questions.length}</span>
            </div>
            <button onclick="app.submitMockTest()" class="px-6 md:px-8 py-2.5 md:py-3 bg-gradient-to-r from-primary to-indigo-600 text-white rounded-xl font-bold shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition flex items-center gap-2">
                <span class="text-lg">✅</span> Nộp Bài 
            </button>
        `;

        this.renderMockQuestions();
        this.startMockTimer();
    },

    renderMockQuestions: function () {
        const container = document.getElementById('mocktest-questions');
        container.innerHTML = this.mockData.questions.map((q, index) => {
            const selectedIdx = this.mockState.answers[q.id];
            const isWrongAfterSubmit = this.mockState.isSubmitted && selectedIdx !== q.correct && selectedIdx !== undefined;
            const boxClass = isWrongAfterSubmit ? 'border-red-300 ring-2 ring-red-50 dark:border-red-800 dark:ring-red-900/20' : 'border-gray-100 dark:border-gray-700';

            return `
            <div class="bg-white p-5 rounded-2xl shadow-sm border transition-all dark:bg-gray-800 ${boxClass}">
                <p class="font-bold text-gray-800 text-sm md:text-base mb-4 dark:text-white leading-relaxed">
                    <span class="bg-gray-100 text-gray-600 px-2.5 py-0.5 rounded-md mr-2 dark:bg-gray-700 dark:text-gray-300">${index + 1}</span> 
                    ${q.text}
                </p>
                <div class="space-y-3">
                    ${q.options.map((opt, oIdx) => {
                const isSelected = selectedIdx === oIdx;
                let optionClass = isSelected
                    ? 'border-primary bg-indigo-50 text-primary dark:bg-indigo-900/30 dark:border-primary'
                    : 'border-gray-100 hover:border-primary hover:bg-indigo-50 dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-primary text-gray-700 dark:text-gray-300';

                if (this.mockState.isSubmitted) {
                    if (oIdx === q.correct) {
                        optionClass = 'border-green-500 bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400 font-bold border-2';
                    } else if (isSelected && oIdx !== q.correct) {
                        optionClass = 'border-red-500 bg-red-50 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-2';
                    } else {
                        optionClass = 'border-gray-100 opacity-40 dark:border-gray-700 text-gray-500';
                    }
                }

                return `
                        <label class="flex items-center space-x-3 p-3.5 rounded-xl border-2 cursor-pointer transition-all group ${optionClass}">
                            <input type="radio" name="mock_q_${q.id}" class="text-primary focus:ring-primary w-4 h-4" 
                                ${isSelected ? 'checked' : ''} 
                                ${this.mockState.isSubmitted ? 'disabled' : ''}
                                onchange="app.selectMockAnswer(${q.id}, ${oIdx})">
                            <span class="text-sm font-semibold transition-colors ${isSelected && !this.mockState.isSubmitted ? 'text-primary' : ''}">${String.fromCharCode(65 + oIdx)}. ${opt}</span>
                        </label>`;
            }).join('')}
                </div>
                
                ${this.mockState.isSubmitted ? `
                <div class="mt-5 border-t border-dashed border-gray-100 dark:border-gray-700 pt-4">
                    <button onclick="app.explainMockWithAI(${q.id})" class="w-full py-3 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-100 text-purple-700 rounded-xl font-bold text-xs flex items-center justify-center hover:shadow-md hover:scale-[1.01] transition dark:from-purple-900/20 dark:to-indigo-900/20 dark:border-purple-800/50 dark:text-purple-300 group">
                        <span class="mr-2 text-base group-hover:scale-125 transition">✨</span> Nhờ AI Tutor giải thích chi tiết
                    </button>
                </div>
                ` : ''}
            </div>
            `;
        }).join('');
    },

    selectMockAnswer: function (qId, oIdx) {
        if (this.mockState.isSubmitted) return;
        this.mockState.answers[qId] = oIdx;
        this.renderMockQuestions();

        const progressText = document.getElementById('mock-progress-text');
        if (progressText) {
            const answeredCount = Object.keys(this.mockState.answers).length;
            progressText.textContent = `${answeredCount}/${this.mockData.questions.length}`;
        }
    },

    startMockTimer: function () {
        if (this.mockState.timerInterval) clearInterval(this.mockState.timerInterval);

        const updateTimer = () => {
            if (this.mockState.timeLeft <= 0) {
                clearInterval(this.mockState.timerInterval);
                this.submitMockTest();
                return;
            }
            const m = Math.floor(this.mockState.timeLeft / 60).toString().padStart(2, '0');
            const s = (this.mockState.timeLeft % 60).toString().padStart(2, '0');
            document.querySelectorAll('.mock-timer-display').forEach(el => el.textContent = `${m}:${s}`);
            this.mockState.timeLeft--;
        };

        updateTimer();
        this.mockState.timerInterval = setInterval(updateTimer, 1000);
    },

    submitMockTest: function () {
        if (this.mockState.isSubmitted) return;

        this.confirmAction("Bạn có chắc chắn muốn nộp bài thi ngay bây giờ?", () => {
            this.mockState.isSubmitted = true;
            clearInterval(this.mockState.timerInterval);
            this.updateQuest('mock', 1);

            let correctCount = 0;
            this.mockData.questions.forEach(q => {
                if (this.mockState.answers[q.id] === q.correct) correctCount++;
            });

            this.renderMockQuestions();

            document.getElementById('mocktest-footer-actions').innerHTML = `
                <div class="text-sm md:text-lg font-black text-gray-800 dark:text-white flex items-center">
                    Điểm số: <span class="text-white ml-2 px-3 py-1 bg-green-500 rounded-lg shadow-sm">${correctCount} / ${this.mockData.questions.length}</span>
                </div>
                <div class="flex gap-2 md:gap-3">
                    <button onclick="app.quitMockTest()" class="px-4 md:px-6 py-2 md:py-3 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition text-sm md:text-base dark:bg-gray-700 dark:text-gray-300">Thoát</button>
                    <button onclick="app.startMockTest()" class="px-4 md:px-6 py-2 md:py-3 bg-indigo-100 text-indigo-700 rounded-xl font-bold hover:bg-indigo-200 transition text-sm md:text-base dark:bg-indigo-900/50 dark:text-indigo-300">Làm Lại</button>
                </div>
            `;

            this.playSound(correctCount > 0 ? 'correct' : 'wrong');
            if (correctCount > 0) this.gainStat('int', correctCount * 10); 
            this.toast(`Hoàn thành! Đúng ${correctCount}/${this.mockData.questions.length} câu. Hãy xem giải thích bên dưới nhé.`, correctCount > 0 ? 'success' : 'info');
        });
    },

    /**
     * Mở modal hiển thị lời giải chi tiết cho từng câu hỏi trong Mock Test.
     */
    explainMockWithAI: function (qId) {
        const q = this.mockData.questions.find(i => i.id === qId);
        if (!q) return;
        const userAnswer = this.mockState.answers[qId];
        const userText = userAnswer !== undefined ? q.options[userAnswer] : "Chưa chọn đáp án";
        const correctText = q.options[q.correct];
        const explanation = q.explanation || "Dựa vào ngữ cảnh đoạn văn, đây là suy luận hợp lý nhất.";

        document.getElementById('tutor-user-ans').textContent = userText;
        document.getElementById('tutor-correct-ans').textContent = correctText;
        document.getElementById('tutor-explanation').innerHTML = explanation;

        const modal = document.getElementById('modal-ai-tutor');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        modal.children[0].classList.add('animate-pop-in');
    },

    // ==========================================
    // 7. HỘI QUÁN (TAVERN - AI ROLEPLAY)
    // ==========================================
    
    tavernState: { scenario: '', targetVi: '', targetEn: '', isLoading: false },

    openTavern: function () {
        if (!this.apiKey && (!this.user.apiKey || this.user.apiKey.length < 10)) {
            return this.toast("Tính năng này cần cấu hình API Key ở tab Hồ Sơ để AI hoạt động!", "error");
        }

        const m = document.getElementById('modal-tavern');
        m.classList.remove('hidden');
        m.classList.add('flex');
        m.children[0].classList.add('animate-pop-in');

        this.generateTavernScenario();
    },

    /**
     * Tạo ngẫu nhiên một tình huống giao tiếp đời thực
     * và yêu cầu người dùng dịch nó sang tiếng Anh bằng giọng nói.
     */
    generateTavernScenario: function () {
        const box = document.getElementById('tavern-chat-box');
        const scenarios = [
            { s: "Than vãn với sếp khi quá tải.", t: "Sếp ơi, hôm nay em hơi đuối, cho em xin nghỉ sớm 1 tiếng nha.", e: "Hey boss, I'm feeling pretty burnt out. Can I head off an hour early today?" },
            { s: "Mặc cả khi đi chợ.", t: "Bớt cho em chút đi, khách quen mà, lấy em 50 nghìn thôi.", e: "Come on, I'm a regular here. Can you give me a discount? Let's do 50k." },
            { s: "Gặp sự cố mạng (dành cho dân IT).", t: "Mạng gì mà lag dữ vậy trời, chắc em phải reset cái router quá.", e: "Man, the internet is so laggy. I think I need to reboot the router." },
            { s: "Đi Taxi/Grab bị kẹt xe.", t: "Anh tài ơi, cho em xuống ở ngã tư phía trước nha, tấp lề giùm em.", e: "Driver, please drop me off at the next intersection. Just pull over to the curb." },
            { s: "Rủ đồng nghiệp đi 'nhậu' xả stress.", t: "Vô đi anh em! Không say không về nha!", e: "Cheers guys! Let's drink until we're wasted!" },
            { s: "Nói khéo khi muốn từ chối đi chơi.", t: "Thôi nay mình lười quá, để dịp khác mình bao bạn nha.", e: "I'm feeling so lazy today. Let's do it another time, my treat!" }
        ];
        const random = scenarios[Math.floor(Math.random() * scenarios.length)];
        this.tavernState.scenario = random.s;
        this.tavernState.targetVi = random.t;
        this.tavernState.targetEn = random.e;

        box.innerHTML = `
            <div class="flex gap-3 mt-4 animate-fade-in-up">
                <div class="w-8 h-8 rounded-full bg-amber-200 flex items-center justify-center text-lg shrink-0 shadow-sm border border-white">👱‍♀️</div>
                <div class="bg-white dark:bg-gray-800 p-4 rounded-2xl rounded-tl-none shadow-md border border-amber-100 dark:border-gray-700 w-[85%]">
                    <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Tình huống mới:</p>
                    <p class="text-sm text-gray-800 dark:text-gray-200 font-black mb-3 leading-relaxed">${this.tavernState.scenario}</p>
                    <div class="p-3 bg-amber-50 dark:bg-amber-900/30 border-2 border-amber-200 dark:border-amber-800 rounded-xl mb-3">
                        <p class="text-[10px] font-black text-amber-700 dark:text-amber-400 mb-1 uppercase tracking-tight">🗣️ Hãy thử nói bằng Tiếng Anh:</p>
                        <p class="text-base font-black text-gray-900 dark:text-white leading-tight">"${this.tavernState.targetVi}"</p>
                    </div>
                    <div id="tavern-hint-area">
                        <button onclick="app.showTavernHint()" class="w-full py-2.5 border-2 border-dashed border-amber-300 text-amber-600 rounded-xl text-xs font-black hover:bg-amber-50 transition-all flex items-center justify-center gap-2">
                            <span>💡 Xem gợi ý & Nghe đọc mẫu</span>
                        </button>
                    </div>
                </div>
            </div>
        `;
        box.scrollTop = box.scrollHeight;
    },

    showTavernHint: function () {
        const area = document.getElementById('tavern-hint-area');
        const safeEn = this.tavernState.targetEn.replace(/'/g, "\\'");
        area.innerHTML = `
            <div class="animate-pop-in p-3 bg-white dark:bg-gray-900 border border-emerald-200 dark:border-emerald-900 rounded-xl shadow-inner">
                <div class="flex justify-between items-start mb-2">
                    <span class="text-[9px] font-black text-emerald-600 uppercase">Câu mẫu dành cho bạn:</span>
                    <button onclick="app.playAudio(event, '${safeEn}')" class="w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition">🔊</button>
                </div>
                <p class="text-sm font-bold text-gray-700 dark:text-gray-200 italic leading-relaxed">"${this.tavernState.targetEn}"</p>
                <p class="text-[10px] text-gray-400 mt-2 italic">Hãy nghe AI đọc mẫu rồi bấm Mic nói theo nhé!</p>
            </div>
        `;
    },

    /**
     * Khởi động quá trình ghi âm.
     * Chuyển đổi giọng nói người dùng thành văn bản (Speech-to-Text).
     */
    recordTavernSpeech: function () {
        if (this.tavernState.isLoading) return;
        const btn = document.getElementById('btn-tavern-mic');
        const statusText = document.getElementById('tavern-status-text');

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) return this.toast("Trình duyệt không hỗ trợ Mic!", "error");

        const recognition = new SpeechRecognition();
        recognition.lang = 'en-US'; 
        recognition.interimResults = false;

        btn.innerHTML = `<span class="text-2xl animate-spin">⏳</span> ĐANG LẮNG NGHE...`;
        btn.classList.replace('from-amber-500', 'from-red-500');
        btn.classList.replace('to-orange-600', 'to-rose-600');
        statusText.textContent = "Hãy nói to ý tưởng của bạn...";

        recognition.start();

        recognition.onresult = (e) => {
            const transcript = e.results[0][0].transcript;
            this.appendUserMessage(transcript);
            this.evaluateTavernSpeech(transcript);
        };

        recognition.onerror = (e) => {
            this.toast("Không nghe rõ, hãy thử lại!", "error");
            this.resetTavernMic(btn, statusText);
        };

        recognition.onend = () => {
            if (!this.tavernState.isLoading) this.resetTavernMic(btn, statusText);
        };
    },

    resetTavernMic: function (btn, statusText) {
        btn.innerHTML = `<span class="text-2xl drop-shadow-md">🎙️</span> BẤM ĐỂ NÓI`;
        btn.classList.replace('from-red-500', 'from-amber-500');
        btn.classList.replace('to-rose-600', 'to-orange-600');
        statusText.textContent = "Hãy bấm Micro và nói...";
    },

    appendUserMessage: function (text) {
        const box = document.getElementById('tavern-chat-box');
        box.innerHTML += `
            <div class="flex gap-3 mt-4 flex-row-reverse animate-fade-in-up">
                <div class="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white text-sm shrink-0 shadow-inner">${this.user.avatar || '👨‍🎓'}</div>
                <div class="bg-indigo-600 text-white p-3.5 rounded-2xl rounded-tr-none shadow-md max-w-[85%]">
                    <p class="text-sm font-medium leading-relaxed">"${text}"</p>
                </div>
            </div>
        `;
        box.scrollTop = box.scrollHeight;
    },

    /**
     * Đưa câu tiếng Anh của người dùng cho OpenAI phân tích, 
     * chấm điểm ngữ cảnh và đề xuất cách nói chuẩn bản xứ hơn.
     */
    evaluateTavernSpeech: async function (userEnglish) {
        const activeKey = this.user.apiKey || this.apiKey;
        this.tavernState.isLoading = true;
        const btn = document.getElementById('btn-tavern-mic');
        const statusText = document.getElementById('tavern-status-text');

        btn.innerHTML = `<span class="text-2xl animate-spin">🤖</span> AI ĐANG CHẤM...`;
        statusText.textContent = "Chờ NPC xử lý...";

        const prompt = `Act as a supportive, fun English communication coach.
        Scenario: ${this.tavernState.scenario}
        Target meaning (Vietnamese): "${this.tavernState.targetVi}"
        What the user actually said (Speech-to-text): "${userEnglish}"

        Strict Evaluation Rules:
        1. BE EXTREMELY ENCOURAGING.
        2. If the user's speech is similar to the sample English phrase or the target meaning, give a high score (>85).
        3. If it's understandable but has small errors, give a medium score (70-84).
        4. Focus on 'Can a foreigner understand this?' rather than grammar perfection.

        Return ONLY a JSON object:
        {
            "score": <number 0-100>,
            "feedback": "<Lời nhận xét tiếng Việt ngắn gọn, cực kỳ khích lệ. Ví dụ: 'Bạn nói rất tốt, Tây nghe hiểu ngay!'>",
            "native_version": "<Cách nói tự nhiên nhất của người bản xứ>"
        }`;

        try {
            const res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${activeKey}` },
                body: JSON.stringify({ model: "gpt-3.5-turbo", messages: [{ role: "user", content: prompt }], temperature: 0.5 })
            });

            const data = await res.json();
            const content = data.choices[0].message.content.replace(/```json|```/g, '').trim();
            const result = JSON.parse(content);

            this.appendAIFeedback(result);

            if (result.score >= 70) {
                this.gainStat('str', 10); 
                this.playSound('correct');
            } else {
                this.playSound('wrong');
            }

        } catch (err) {
            this.toast("Lỗi AI! Vui lòng thử lại.", "error");
        } finally {
            this.tavernState.isLoading = false;
            this.resetTavernMic(btn, statusText);
        }
    },

    appendAIFeedback: function (result) {
        const box = document.getElementById('tavern-chat-box');
        const isGood = result.score >= 70;

        box.innerHTML += `
            <div class="flex gap-3 mt-4 animate-fade-in-up">
                <div class="w-8 h-8 rounded-full bg-amber-200 flex items-center justify-center text-lg shrink-0">👱‍♀️</div>
                <div class="bg-white dark:bg-gray-800 p-4 rounded-2xl rounded-tl-none shadow-lg border border-amber-100 dark:border-gray-700 w-[90%]">
                    <div class="flex justify-between items-center mb-2 pb-2 border-b border-gray-100 dark:border-gray-700">
                        <span class="font-black text-sm ${isGood ? 'text-emerald-500' : 'text-orange-500'}">Độ hiểu ý: ${result.score}%</span>
                        <span class="text-xl">${isGood ? '🎉' : '🤔'}</span>
                    </div>
                    <p class="text-sm text-gray-700 dark:text-gray-300 mb-3 leading-relaxed">${result.feedback}</p>
                    <div class="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-xl border border-amber-200 dark:border-amber-800/50 relative">
                        <p class="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-1 flex justify-between">
                            <span>Cách nói tự nhiên:</span>
                            <button onclick="app.playAudio(event, '${result.native_version.replace(/'/g, "\\'")}')" class="text-xl hover:scale-125 transition">🔊</button>
                        </p>
                        <p class="font-black text-gray-800 dark:text-white text-base">"${result.native_version}"</p>
                    </div>
                </div>
            </div>
        `;
        box.scrollTop = box.scrollHeight;
    },


    // ==========================================
    // 8. MA PHÁP TRẬN NGỮ PHÁP (GRAMMAR ENGINE)
    // ==========================================
    
    grammarTopics: [
        { id: 'tenses', icon: '⏳', name: '12 Thì Tiếng Anh', desc: 'Thì Hiện tại, Quá khứ, Tương lai và các dấu hiệu nhận biết.' },
        { id: 'conditional', icon: '🔀', name: 'Câu Điều Kiện', desc: 'If loại 0, 1, 2, 3 và câu điều kiện hỗn hợp (Mixed).' },
        { id: 'passive', icon: '🔄', name: 'Câu Bị Động', desc: 'Passive Voice trong mọi thì và cấu trúc đặc biệt.' },
        { id: 'relative', icon: '🔗', name: 'Mệnh Đề Quan Hệ', desc: 'Who, whom, which, that & rút gọn mệnh đề phân từ.' },
        { id: 'prepositions', icon: '📍', name: 'Giới Từ & Cụm', desc: 'In, on, at và Phrasal Verbs hay thi nhất.' },
        { id: 'reported', icon: '🗣️', name: 'Câu Gián Tiếp', desc: 'Reported Speech: Lùi thì và đổi ngôi chuẩn xác.' }
    ],

    renderGrammarTopics: function () {
        const grid = document.getElementById('grammar-topic-grid');
        if (!grid) return;

        grid.innerHTML = this.grammarTopics.map((t, idx) => {
            const delay = Math.min(idx * 50, 300);
            return `
            <div style="animation-delay: ${delay}ms" onclick="app.startGrammarPractice('${t.name}')" class="animate-fade-in-up opacity-0 bg-white rounded-3xl shadow-sm border border-gray-100 p-5 hover:shadow-xl hover:-translate-y-1 hover:border-blue-400 transition-all duration-300 cursor-pointer group dark:bg-gray-800 dark:border-gray-700 dark:hover:border-blue-500">
                <div class="flex items-center gap-4 mb-3">
                    <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 text-blue-600 flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 group-hover:rotate-6 transition-transform dark:from-blue-900/30 dark:to-indigo-900/30 dark:text-blue-400 border border-blue-100 dark:border-blue-800/50">
                        ${t.icon}
                    </div>
                    <div class="flex-1">
                        <h4 class="font-black text-lg text-gray-800 dark:text-white group-hover:text-blue-600 transition-colors">${t.name}</h4>
                    </div>
                </div>
                <p class="text-xs text-gray-500 dark:text-gray-400 font-medium leading-relaxed">${t.desc}</p>
                <div class="mt-4 pt-3 border-t border-gray-50 dark:border-gray-700/50 flex justify-between items-center">
                    <span class="text-[10px] font-bold text-blue-500 uppercase tracking-widest bg-blue-50 dark:bg-blue-900/30 px-2 py-1 rounded-md flex items-center gap-1"><span class="animate-pulse">✨</span> AI Sinh Đề</span>
                    <span class="w-8 h-8 rounded-full bg-gray-50 dark:bg-gray-700 flex items-center justify-center text-gray-400 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                        <svg class="w-4 h-4 ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7"></path></svg>
                    </span>
                </div>
            </div>`;
        }).join('');
    },

    /**
     * Gọi AI tạo một bài kiểm tra Ngữ pháp bao gồm lý thuyết tóm tắt và 5 câu trắc nghiệm.
     */
    startGrammarPractice: async function (topicName) {
        const activeKey = this.user.apiKey || this.apiKey;
        if (!activeKey || activeKey.length < 10) {
            return this.toast("Tính năng này cần cấu hình API Key ở tab Hồ Sơ để AI biên soạn đề!", "error");
        }

        this.toast(`🪄 Đang triệu hồi AI soạn lý thuyết & 5 bài tập về ${topicName}...`, "info");

        const prompt = `Act as an expert English grammar teacher. Generate a Grammar Practice Test about: "${topicName}".
Requirements:
1. "passage": Write a very short, highly practical explanation (in Vietnamese) of the core grammar rules for this topic. Use HTML <p>, <b>, <br> tags.
2. "questions": Generate EXACTLY 5 multiple-choice questions focusing on finding the grammatically correct answer.
3. "explanation": Provide a clear Vietnamese explanation detailing WHY that answer is correct and others are wrong.

STRICT JSON RULES:
- Output MUST be a valid JSON object ONLY. No markdown wrapping.
- NEVER use double quotes (") inside strings. Use single quotes for HTML.
Format exactly like this:
{
  "title": "Grammar: ${topicName}",
  "timeLimit": 300,
  "passage": "<h3 class='text-xl font-black mb-2 text-blue-600'>Lý thuyết trọng tâm</h3><p>...</p>",
  "questions": [
    {
      "id": 1,
      "text": "Question with a _____ blank?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct": 0,
      "explanation": "Lời giải thích chi tiết..."
    }
  ]
}`;

        try {
            const res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${activeKey}` },
                body: JSON.stringify({ model: "gpt-3.5-turbo", messages: [{ role: "user", content: prompt }], temperature: 0.5 })
            });

            if (!res.ok) throw new Error("Lỗi API");
            const data = await res.json();
            let content = data.choices[0].message.content.trim().replace(/```json/g, '').replace(/```/g, '').trim();
            const parsedData = JSON.parse(content);

            parsedData.title = `Luyện Tập Ngữ Pháp: ${topicName}`;

            this.grammarData = parsedData;
            this.enterGrammarWorkspace();
            this.toast(`Hoàn tất! Bắt đầu luyện ${topicName} thôi.`, "success");

        } catch (err) {
            this.toast("Lỗi tạo bài tập AI. Hãy thử lại!", "error");
        }
    },

    enterGrammarWorkspace: function () {
        if (!this.grammarData) return;

        document.getElementById('grammar-home').classList.add('hidden');
        document.getElementById('grammar-workspace').classList.remove('hidden');
        window.scrollTo({ top: 0, behavior: 'smooth' });

        document.getElementById('grammar-title').textContent = this.grammarData.title;
        document.getElementById('grammar-theory-content').innerHTML = this.grammarData.passage;

        const btnSubmit = document.getElementById('btn-submit-grammar');
        btnSubmit.classList.remove('hidden');
        const oldResult = document.getElementById('grammar-result-box');
        if (oldResult) oldResult.remove();

        let qHtml = this.grammarData.questions.map((q, qIndex) => {
            let opts = q.options.map((opt, optIndex) => `
                <label class="flex items-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 border-2 border-gray-100 dark:border-gray-800 rounded-xl cursor-pointer hover:border-blue-300 dark:hover:border-blue-700 transition-colors group">
                    <input type="radio" name="gq_${qIndex}" value="${optIndex}" class="w-5 h-5 text-blue-600 focus:ring-blue-500 border-gray-300">
                    <span class="font-bold text-gray-700 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white transition-colors">${opt}</span>
                </label>
            `).join('');

            return `
            <div class="grammar-q-block" data-qidx="${qIndex}">
                <p class="font-black text-gray-800 dark:text-white mb-3 text-lg leading-snug"><span class="text-blue-500 mr-1">${qIndex + 1}.</span> ${q.text}</p>
                <div class="flex flex-col gap-2">
                    ${opts}
                </div>
                <div class="grammar-explanation hidden mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border-l-4 border-blue-500 text-sm font-medium text-gray-700 dark:text-gray-300"></div>
            </div>`;
        }).join('');

        document.getElementById('grammar-questions').innerHTML = qHtml;
    },

    exitGrammarWorkspace: function () {
        document.getElementById('grammar-workspace').classList.add('hidden');
        document.getElementById('grammar-home').classList.remove('hidden');
        this.grammarData = null;
    },

    /**
     * Chấm điểm bài kiểm tra Ngữ pháp và hiển thị lý giải cho từng câu.
     */
    submitGrammarTest: function () {
        if (!this.grammarData) return;

        const qBlocks = document.querySelectorAll('.grammar-q-block');
        let correctCount = 0;
        let allAnswered = true;

        qBlocks.forEach(block => {
            const qIdx = parseInt(block.getAttribute('data-qidx'));
            if (!block.querySelector(`input[name="gq_${qIdx}"]:checked`)) allAnswered = false;
        });

        if (!allAnswered) return this.toast("Vui lòng trả lời hết 5 câu trước khi nộp!", "error");

        qBlocks.forEach(block => {
            const qIdx = parseInt(block.getAttribute('data-qidx'));
            const qData = this.grammarData.questions[qIdx];
            const checked = block.querySelector(`input[name="gq_${qIdx}"]:checked`);
            const selectedVal = parseInt(checked.value);

            block.querySelectorAll('input').forEach(i => i.disabled = true);
            block.querySelectorAll('label').forEach(lbl => lbl.className = "flex items-center gap-3 p-4 bg-gray-50 dark:bg-gray-900/50 border-2 border-gray-100 dark:border-gray-800 rounded-xl opacity-60");

            const correctLbl = block.querySelectorAll('label')[qData.correct];
            const selectedLbl = block.querySelectorAll('label')[selectedVal];

            if (selectedVal === qData.correct) {
                correctCount++;
                selectedLbl.className = "flex items-center gap-3 p-4 bg-emerald-50 dark:bg-emerald-900/30 border-2 border-emerald-500 rounded-xl shadow-sm";
                selectedLbl.querySelector('span').classList.add('text-emerald-700', 'dark:text-emerald-300');
            } else {
                selectedLbl.className = "flex items-center gap-3 p-4 bg-rose-50 dark:bg-rose-900/30 border-2 border-rose-500 rounded-xl shadow-sm";
                selectedLbl.querySelector('span').classList.add('text-rose-700', 'dark:text-rose-300');
                correctLbl.className = "flex items-center gap-3 p-4 bg-emerald-50 dark:bg-emerald-900/30 border-2 border-emerald-500 rounded-xl shadow-sm";
                correctLbl.querySelector('span').classList.add('text-emerald-700', 'dark:text-emerald-300');
            }

            const expDiv = block.querySelector('.grammar-explanation');
            expDiv.innerHTML = `<span class="font-black text-blue-600 dark:text-blue-400 mr-1">💡 Giải thích:</span> ${qData.explanation}`;
            expDiv.classList.remove('hidden');
            expDiv.classList.add('animate-fade-in-up');
        });

        document.getElementById('btn-submit-grammar').classList.add('hidden');

        const actionArea = document.getElementById('grammar-action-area');
        const scoreColor = correctCount >= 4 ? 'text-emerald-500' : (correctCount >= 3 ? 'text-amber-500' : 'text-rose-500');
        const scoreText = correctCount >= 4 ? 'Tuyệt vời!' : (correctCount >= 3 ? 'Khá tốt!' : 'Cần ôn lại lý thuyết!');

        actionArea.insertAdjacentHTML('beforeend', `
            <div id="grammar-result-box" class="animate-pop-in p-6 bg-gray-900 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 border border-gray-800 shadow-2xl">
                <div class="flex items-center gap-4">
                    <div class="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center text-3xl font-black ${scoreColor} shadow-inner border border-gray-700">
                        ${correctCount}/5
                    </div>
                    <div>
                        <h4 class="text-xl font-black text-white uppercase tracking-widest">${scoreText}</h4>
                        <p class="text-sm text-gray-400 font-medium">Đọc phần giải thích để hiểu rõ đáp án nhé.</p>
                    </div>
                </div>
                <button onclick="app.exitGrammarWorkspace()" class="w-full md:w-auto px-8 py-3.5 bg-white text-gray-900 font-black rounded-xl hover:bg-gray-200 transition-colors shadow-md">Hoàn Tất</button>
            </div>
        `);

        this.playSound(correctCount >= 3 ? 'crit' : 'wrong');
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    }
};

// ==========================================
// 9. KÍCH HOẠT ỨNG DỤNG
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    app.init();
    app.renderQuests(); 
});