/**
 * FLASHCARD PRO - QUIZ MODULE
 * Module này quản lý toàn bộ logic của hệ thống Trắc nghiệm (Quiz) và Ôn tập SRS.
 * Bao gồm các chế độ: Đoán nghĩa, Dịch ngược, Điền từ, Luyện nghe (Shadowing, Dictation...).
 */

Object.assign(app, {
    
    startReviewSession: function () {
        const now = Date.now();
        const dueWords = this.data.filter(i => i.nextReview > 0 && i.nextReview <= now);

        if (dueWords.length === 0) return this.toast("Tuyệt vời! Bạn không có từ nào cần ôn lúc này.", "info");

        this.state.quizMode = 'meaning';
        this.state.currentQuizTopic = 'SRS Review';
        this.quizData = dueWords.sort(() => 0.5 - Math.random()).slice(0, 10);
        this.quizState = { index: 0, score: 0 };

        this.navigate('quiz');
        document.getElementById('quiz-intro').classList.add('hidden');
        document.getElementById('quiz-result').classList.add('hidden');
        document.getElementById('quiz-game').classList.replace('hidden', 'flex');

        this.renderQuestion();
        this.toast(`🚀 Bắt đầu ôn tập ${this.quizData.length} từ đến hạn!`, "success");
    },

    startQuizMode: function (mode) {
        this.state.quizMode = mode;
        this.navigate('quiz');

        const intro = document.getElementById('quiz-intro');
        if (intro) intro.classList.remove('hidden');

        const game = document.getElementById('quiz-game');
        if (game) game.classList.add('hidden');

        const res = document.getElementById('quiz-result');
        if (res) res.classList.add('hidden');
    },

    startQuiz: function (topic) {
        this.state.currentQuizTopic = topic;

        let pool = topic === 'ALL' ? this.data : this.data.filter(i => (i.topic || 'General') === topic);

        if (pool.length < 4) return this.toast(topic === 'ALL' ? "Thư viện cần ít nhất 4 từ để tạo bài test!" : "Chủ đề này cần ít nhất 4 từ vựng!", "error");

        this.quizData = pool.sort(() => 0.5 - Math.random()).slice(0, 10);
        this.quizState = { index: 0, score: 0 };

        // RESET các biến mode đặc biệt khi bắt đầu
        this.state.deepStep = 0;
        this.state.survivalStreak = 0;

        document.getElementById('quiz-intro').classList.add('hidden');
        document.getElementById('quiz-result').classList.add('hidden');
        document.getElementById('quiz-game').classList.replace('hidden', 'flex');

        const speedBtn = document.getElementById('listen-speed-btn');
        const accentBtn = document.getElementById('listen-accent-btn');
        const noiseBtn = document.getElementById('listen-noise-btn');
        if (speedBtn) {
            if (this.state.quizMode === 'listen') {
                speedBtn.classList.remove('hidden');
                if (accentBtn) accentBtn.classList.remove('hidden');
                if (noiseBtn) noiseBtn.classList.remove('hidden');
            } else {
                speedBtn.classList.add('hidden');
                if (accentBtn) accentBtn.classList.add('hidden');
                if (noiseBtn) noiseBtn.classList.add('hidden');
            }
        }

        this.renderQuestion();
    },

    renderQuestion: function () {
        const item = this.quizData[this.quizState.index];
        const mode = this.state.quizMode || 'meaning';

        let questionText, pronunText, typeText, correctAnswer, optionsPool;

        if (mode === 'fill' && item.example) {
            const targetWord = item.coreWord || item.word;
            const regex = new RegExp(`\\b${targetWord}\\b`, "ig");
            let hiddenSentence = item.example.replace(regex, "________");
            if (hiddenSentence === item.example) hiddenSentence = item.example.replace(item.word, "________");

            questionText = hiddenSentence;
            pronunText = `Nghĩa: ${item.coreDef || item.definition}`; 
            typeText = "Điền Từ";
            correctAnswer = item.word;
            optionsPool = this.data.map(i => i.word);
        } else if (mode === 'reverse') {
            questionText = item.coreDef || item.definition; 
            pronunText = "Chọn từ ngoại ngữ chính xác";
            typeText = "Dịch Ngược";
            correctAnswer = item.word;
            optionsPool = this.data.map(i => i.word);
        } else if (mode === 'listen') {
            const hasTranslation = item.example && item.exTranslation;
            let userMode = this.state.listenMode || 'random';

            if (userMode === 'deep') {
                if (this.state.deepStep === 0) userMode = 'blind';
                else if (this.state.deepStep === 1) userMode = 'transcription';
                else userMode = 'shadowing';
            }

            if (userMode === 'random' || userMode === 'survival') {
                const availableModes = ['dictation'];
                if (hasTranslation) availableModes.push('blind', 'overload');
                if (item.example) availableModes.push('transcription', 'shadowing');
                userMode = availableModes[Math.floor(Math.random() * availableModes.length)];
            }

            if (!item.example && userMode !== 'blind') userMode = 'basic_audio';
            if (!hasTranslation && (userMode === 'blind' || userMode === 'overload')) userMode = 'dictation';

            if (userMode === 'blind') {
                questionText = 'audio_blind_mode';
                this.quizState.currentAudioText = item.example;
                pronunText = "🙈 Nghe Mù (Blind Comprehension)";
                typeText = "Hiểu Toàn Câu";
                correctAnswer = item.exTranslation;
                optionsPool = this.data.filter(i => i.exTranslation).map(i => i.exTranslation);
                if (optionsPool.length < 4) optionsPool = [...optionsPool, "Dịch sai ngữ cảnh", "Không rõ nghĩa"];
                setTimeout(() => this.playAudio(null, item.example), 400);
            } else if (userMode === 'transcription') {
                questionText = 'audio_transcription_mode';
                this.quizState.currentAudioText = item.example;
                pronunText = "⌨️ Chép Chính Tả (Hardcore Mode)";
                typeText = "Gõ Lại Cả Câu";
                correctAnswer = item.example;
                optionsPool = [];
                setTimeout(() => this.playAudio(null, item.example), 400);
            } else if (userMode === 'shadowing') {
                questionText = 'audio_shadowing_mode';
                this.quizState.currentAudioText = item.example;
                pronunText = "🗣️ Luyện Lưỡi Bản Xứ (Shadowing AI)";
                typeText = "Luyện Cảm Âm & Phản Xạ";
                correctAnswer = item.example;
                optionsPool = [];
                setTimeout(() => this.playAudio(null, item.example), 400);
            } else if (userMode === 'overload') {
                questionText = 'audio_overload_mode';
                this.quizState.currentAudioText = item.example;
                pronunText = "⚡ Nghe Ép Xung (Speed Overload)";
                typeText = "Phá Vỡ Giới Hạn Nghe";
                correctAnswer = item.exTranslation;
                optionsPool = this.data.filter(i => i.exTranslation).map(i => i.exTranslation);
                if (optionsPool.length < 4) optionsPool = [...optionsPool, "Nghe không kịp", "Tốc độ quá nhanh"];
                setTimeout(() => {
                    const oldSpeed = this.state.listenSpeed;
                    this.state.listenSpeed = 1.5;
                    this.playAudio(null, item.example);
                    setTimeout(() => this.state.listenSpeed = oldSpeed, 500);
                }, 400);
            } else if (userMode === 'dictation') {
                const targetWord = item.coreWord || item.word;
                const regex = new RegExp(`\\b${targetWord}\\b`, "ig");
                let hiddenSentence = item.example.replace(regex, "________");
                questionText = 'audio_sentence_mode';
                this.quizState.currentHiddenSentence = hiddenSentence;
                this.quizState.currentAudioText = item.example;
                pronunText = "🎧 Nghe Đục Lỗ (Dictation)";
                typeText = "Nghe Bắt Ý";
                correctAnswer = item.word;
                optionsPool = this.data.map(i => i.word);
                setTimeout(() => this.playAudio(null, item.example), 400);
            } else {
                questionText = 'audio_mode';
                this.quizState.currentAudioText = item.word;
                pronunText = "Lắng nghe và chọn đáp án";
                typeText = "Nghe Từ Đơn";
                correctAnswer = item.word;
                optionsPool = this.data.map(i => i.word);
                setTimeout(() => this.playAudio(null, item.word), 400);
            }
        } else {
            questionText = item.word;
            pronunText = item.pronun || '/.../';
            typeText = item.type || 'Word';
            correctAnswer = item.coreDef || item.definition; 
            optionsPool = this.data.map(i => i.coreDef || i.definition); 
        }

        let options = [correctAnswer];
        const distractors = [...new Set(optionsPool)].filter(opt => opt && opt !== correctAnswer);
        const maxOptions = Math.min(3, distractors.length);
        for (let i = 0; i < maxOptions; i++) {
            const randomIndex = Math.floor(Math.random() * distractors.length);
            options.push(distractors.splice(randomIndex, 1)[0]);
        }

        document.getElementById('quiz-current').textContent = this.quizState.index + 1;
        document.getElementById('quiz-score').textContent = this.quizState.score;

        const qEl = document.getElementById('quiz-question');
        if (questionText === 'audio_blind_mode') {
            const safeAudioText = this.quizState.currentAudioText.replace(/'/g, "\\'").replace(/"/g, '&quot;');
            qEl.innerHTML = `
                <div class="mb-5 flex flex-col items-center justify-center">
                    <div class="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center text-4xl mb-4 shadow-inner dark:bg-indigo-900/30 dark:text-indigo-400">🙈</div>
                    <p class="text-gray-500 font-bold text-sm dark:text-gray-400 uppercase tracking-widest">Nghe và Chọn nghĩa của câu</p>
                </div>
                <button onclick="app.playAudio(event, '${safeAudioText}')" class="mx-auto flex items-center justify-center gap-2 bg-indigo-600 text-white p-4 px-8 rounded-full hover:bg-indigo-700 transition shadow-lg shadow-indigo-200 dark:shadow-none">
                    <svg class="w-6 h-6 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                    <span class="text-base font-black tracking-wider uppercase">Nghe Lại Câu Này</span>
                </button>`;
        } else if (questionText === 'audio_transcription_mode') {
            const safeAudioText = this.quizState.currentAudioText.replace(/'/g, "\\'").replace(/"/g, '&quot;');
            qEl.innerHTML = `
                <div class="mb-5 flex flex-col items-center justify-center">
                    <div class="w-16 h-16 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center text-3xl mb-4 shadow-inner dark:bg-rose-900/30 dark:text-rose-400">⌨️</div>
                    <p class="text-gray-500 font-bold text-xs dark:text-gray-400 uppercase tracking-widest text-center">Nghe và Gõ lại toàn bộ câu</p>
                </div>
                <button onclick="app.playAudio(event, '${safeAudioText}')" class="mx-auto flex items-center justify-center gap-2 bg-rose-600 text-white p-4 px-8 rounded-full hover:bg-rose-700 transition shadow-lg shadow-rose-200 dark:shadow-none">
                    <svg class="w-6 h-6 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                    <span class="text-base font-black tracking-wider uppercase">Nghe Lại Câu</span>
                </button>`;
        } else if (questionText === 'audio_shadowing_mode') {
            const safeAudioText = this.quizState.currentAudioText.replace(/'/g, "\\'").replace(/"/g, '&quot;');
            qEl.innerHTML = `
                <div class="mb-5 flex flex-col items-center justify-center">
                    <div class="w-16 h-16 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center text-3xl mb-4 shadow-inner dark:bg-rose-900/30 dark:text-rose-400">🗣️</div>
                    <p class="text-gray-500 font-bold text-xs dark:text-gray-400 uppercase tracking-widest text-center mb-3">Nghe và Bắt chước y hệt ngữ điệu</p>
                    <p class="text-xl font-medium text-gray-700 dark:text-gray-300 italic px-4 text-center leading-relaxed">"${item.example}"</p>
                </div>`;
        } else if (questionText === 'audio_overload_mode') {
            const safeAudioText = this.quizState.currentAudioText.replace(/'/g, "\\'").replace(/"/g, '&quot;');
            qEl.innerHTML = `
                <div class="mb-5 flex flex-col items-center justify-center">
                    <div class="w-16 h-16 bg-orange-50 text-orange-600 rounded-full flex items-center justify-center text-3xl mb-4 shadow-inner dark:bg-orange-900/30 dark:text-orange-400 animate-pulse">⚡</div>
                    <p class="text-gray-500 font-bold text-xs dark:text-gray-400 uppercase tracking-widest text-center">Ép Xung 1.5x Tốc Độ</p>
                </div>
                <button onclick="let old = app.state.listenSpeed; app.state.listenSpeed = 1.5; app.playAudio(event, '${safeAudioText}'); setTimeout(()=>app.state.listenSpeed = old, 500);" class="mx-auto flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white p-4 px-8 rounded-full hover:scale-105 transition shadow-lg shadow-orange-200 dark:shadow-none">
                    <span class="text-base font-black tracking-wider uppercase">⚡ Nghe Lại (1.5x)</span>
                </button>`;
        } else if (questionText === 'audio_sentence_mode') {
            const safeAudioText = this.quizState.currentAudioText.replace(/'/g, "\\'").replace(/"/g, '&quot;');
            qEl.innerHTML = `
                <div class="mb-5 text-lg md:text-xl font-medium text-gray-700 dark:text-gray-300 leading-relaxed italic">
                    "${this.quizState.currentHiddenSentence}"
                </div>
                <button onclick="app.playAudio(event, '${safeAudioText}')" class="mx-auto flex items-center justify-center gap-2 bg-pink-50 text-pink-600 p-3 px-5 rounded-full hover:bg-pink-100 transition shadow-sm border border-pink-200 dark:bg-pink-900/30 dark:text-pink-400 dark:border-pink-800">
                    <svg class="w-6 h-6 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                    <span class="text-sm font-extrabold tracking-wide">Nghe Lại Câu</span>
                </button>`;
        } else if (questionText === 'audio_mode') {
            const safeAudioText = this.quizState.currentAudioText.replace(/'/g, "\\'");
            qEl.innerHTML = `<button onclick="app.playAudio(event, '${safeAudioText}')" class="mx-auto flex items-center justify-center gap-3 bg-pink-50 text-pink-600 p-4 px-6 rounded-full hover:bg-pink-100 transition shadow-sm border border-pink-200 dark:bg-pink-900/30 dark:text-pink-400 dark:border-pink-800">
                <svg class="w-8 h-8 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                <span class="text-xl font-extrabold tracking-wide">Nghe Lại Từ</span>
            </button>`;
        } else {
            qEl.textContent = questionText;
        }

        document.getElementById('quiz-pronun').textContent = pronunText;
        document.getElementById('quiz-word-type').textContent = typeText;
        this.quizState.correctAnswer = correctAnswer;

        const grid = document.getElementById('quiz-options');
        if (questionText === 'audio_transcription_mode') {
            grid.innerHTML = `
                <div class="space-y-4">
                    <textarea id="transcription-input" rows="3" spellcheck="false" class="w-full p-4 bg-white border-2 border-gray-200 focus:border-rose-500 rounded-2xl text-gray-800 font-medium transition-all shadow-inner dark:bg-gray-800 dark:border-gray-700 dark:text-white text-base md:text-lg" placeholder="Gõ lại chính xác câu bạn nghe được..."></textarea>
                    <button onclick="app.checkTranscriptionAnswer()" class="w-full py-4 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-2xl font-black text-sm md:text-lg shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all active:scale-95 uppercase tracking-widest">Nộp Đáp Án</button>
                </div>
            `;
            setTimeout(() => document.getElementById('transcription-input')?.focus(), 500);
        } else if (questionText === 'audio_shadowing_mode') {
            grid.innerHTML = `
                <div class="space-y-4 mt-2">
                    <button id="btn-shadowing-record" onclick="app.checkShadowingAI()" class="w-full py-5 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-2xl font-black text-sm md:text-lg shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all active:scale-95 uppercase tracking-widest flex items-center justify-center gap-2">
                        <span class="text-2xl animate-bounce">🎙️</span> BẤM VÀO ĐỂ ĐỌC LẠI
                    </button>
                </div>
            `;
        } else {
            grid.innerHTML = options.sort(() => 0.5 - Math.random()).map(opt => `
                <button onclick="app.checkAnswer(this, '${opt.replace(/'/g, "\\'")}')" class="w-full p-4 bg-white border-2 border-gray-100 rounded-xl text-gray-700 font-bold hover:border-primary hover:bg-indigo-50 transition text-left shadow-sm dark:bg-gray-800 dark:border-gray-700 dark:text-gray-200 dark:hover:bg-gray-700 leading-relaxed">${opt}</button>
            `).join('');
        }
    },

    processSRS: function (wordId, isCorrect) {
        const item = this.data.find(i => i.id === wordId);
        if (!item) return;

        if (isCorrect) {
            item.level = (item.level || 0) + 1;
            const daysToWait = Math.min(item.level, 30);
            item.nextReview = Date.now() + (daysToWait * 86400000);
        } else {
            item.level = 0;
            item.nextReview = Date.now();
        }
        this.saveData();
    },

    checkShadowingAI: function () {
        if (this.isListening) return;
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) return this.toast("Trình duyệt/Thiết bị của bạn không hỗ trợ Thu âm!", "error");

        const btn = document.getElementById('btn-shadowing-record');
        if (!btn) return;
        const oldHtml = btn.innerHTML;
        const expectedText = this.quizState.correctAnswer.toLowerCase().replace(/[.,!?'"()]/g, '').trim();

        this.isListening = true;
        btn.innerHTML = `<span class="animate-pulse flex items-center gap-2">🔴 Đang nghe... (Hãy nói thật chuẩn)</span>`;
        btn.classList.replace('from-rose-500', 'from-red-600');
        btn.classList.replace('to-pink-600', 'to-red-700');

        const recognition = new SpeechRecognition();
        recognition.lang = this.user.voiceLang || 'en-US';
        recognition.interimResults = false;

        try {
            recognition.start();
            this.toast("🎙️ Đang ghi âm... Hãy đọc khớp với ngữ điệu bạn vừa nghe.", "info");
        } catch (e) {
            this.isListening = false; btn.innerHTML = oldHtml; return;
        }

        recognition.onresult = (e) => {
            const transcript = e.results[0][0].transcript.toLowerCase().replace(/[.,!?'"()]/g, '').trim();
            const expectedWords = expectedText.split(' ');
            const spokenWords = transcript.split(' ');
            let matchCount = 0;
            expectedWords.forEach(w => { if (spokenWords.includes(w)) matchCount++; });
            const matchRate = matchCount / expectedWords.length;

            if (matchRate >= 0.7 || transcript.includes(expectedText)) {
                this.toast(`✅ Khớp giọng bản xứ! Độ chính xác: ${Math.round(matchRate * 100)}%`, "success");
                this.gainStat('str', 5); 
                this.gainStat('dex', 5); 
                this.quizState.score += 20;
                document.getElementById('quiz-score').textContent = this.quizState.score;
                this.processSRS(this.quizData[this.quizState.index].id, true);

                if (this.state.listenMode === 'survival') {
                    this.state.survivalStreak++;
                    if (this.state.survivalStreak >= 2) this.state.listenSpeed = Math.min(1.2, this.state.listenSpeed + 0.1);
                    this.updateListenToolsUI();
                }
                this.showQuizFeedback(true);
            } else {
                this.toast(`❌ Bạn đọc: "${transcript}". Chưa đủ khớp, hãy thử lại!`, "error");
                this.processSRS(this.quizData[this.quizState.index].id, false);
                if (this.state.listenMode === 'survival') {
                    this.state.survivalStreak = 0;
                    this.state.listenSpeed = 1.0;
                    this.updateListenToolsUI();
                }
                this.showQuizFeedback(false);
            }
        };

        recognition.onerror = () => {
            this.isListening = false;
            btn.innerHTML = oldHtml;
            this.toast("Chưa nhận diện được giọng, vui lòng bấm lại!", "error");
        };
        recognition.onend = () => {
            this.isListening = false;
            if (btn.innerHTML.includes('Đang nghe')) {
                btn.innerHTML = oldHtml;
                btn.classList.replace('from-red-600', 'from-rose-500');
                btn.classList.replace('to-red-700', 'to-pink-600');
            }
        };
    },

    checkTranscriptionAnswer: function () {
        const inputEl = document.getElementById('transcription-input');
        if (!inputEl) return;

        let userText = inputEl.value.trim().toLowerCase().replace(/[.,!?'"()]/g, '').replace(/\\s+/g, ' ');
        let correctText = this.quizState.correctAnswer.toLowerCase().replace(/[.,!?'"()]/g, '').replace(/\\s+/g, ' ');

        if (!userText) return this.toast("Hãy nhập câu trả lời của bạn!", "error");

        const isCorrect = userText === correctText;

        if (isCorrect) {
            this.quizState.score += 20;
            document.getElementById('quiz-score').textContent = this.quizState.score;
            inputEl.classList.replace('border-gray-200', 'border-green-500');
            inputEl.classList.add('bg-green-50', 'text-green-800');
            this.processSRS(this.quizData[this.quizState.index].id, true);

            if (this.state.listenMode === 'survival') {
                this.state.survivalStreak++;
                if (this.state.survivalStreak >= 2) {
                    this.state.listenSpeed = Math.min(1.2, this.state.listenSpeed + 0.1);
                    if (this.state.survivalStreak >= 4) this.state.listenNoise = true;
                    this.updateListenToolsUI();
                }
            }
        } else {
            inputEl.classList.replace('border-gray-200', 'border-red-500');
            inputEl.classList.add('bg-red-50', 'text-red-800');
            this.processSRS(this.quizData[this.quizState.index].id, false);

            if (this.state.listenMode === 'survival') {
                this.state.survivalStreak = 0;
                this.state.listenSpeed = 1.0;
                this.state.listenNoise = false;
                this.updateListenToolsUI();
            }
        }

        this.showQuizFeedback(isCorrect);
    },

    checkAnswer: function (btn, selectedAnswer) {
        const currentWord = this.quizData[this.quizState.index];
        const correctAnswer = this.quizState.correctAnswer;

        const btns = document.querySelectorAll('#quiz-options button');
        btns.forEach(b => {
            b.disabled = true;
            if (b.textContent === correctAnswer) {
                b.classList.remove('border-gray-100', 'dark:border-gray-700');
                b.classList.add('bg-green-50', 'border-green-500', 'text-green-700', 'dark:bg-green-900/30', 'dark:text-green-400');
            }
        });

        const isCorrect = selectedAnswer === correctAnswer;

        if (isCorrect) {
            this.quizState.combo++;
            const bonus = this.quizState.combo > 2 ? (this.quizState.combo * 2) : 0;
            this.quizState.score += (10 + bonus);
            if (this.state.quizMode === 'listen') this.gainStat('agi', 3); 
            const scoreEl = document.getElementById('quiz-score');
            scoreEl.textContent = this.quizState.score;
            scoreEl.classList.add('scale-125', 'text-green-500');
            setTimeout(() => scoreEl.classList.remove('scale-125', 'text-green-500'), 300);

            if (this.quizState.combo > 1) {
                const comboEl = document.getElementById('quiz-combo-text');
                comboEl.textContent = `${this.quizState.combo} COMBO🔥`;
                comboEl.classList.remove('opacity-0', 'translate-y-2');
                comboEl.classList.add('opacity-100', 'translate-y-0', 'scale-110');
                setTimeout(() => comboEl.classList.remove('scale-110'), 200);
            }

            btn.innerHTML += ' ✅';
            this.processSRS(currentWord.id, true);

            if (this.state.listenMode === 'survival') {
                this.state.survivalStreak++;
                if (this.state.survivalStreak >= 2) {
                    this.state.listenSpeed = Math.min(1.2, this.state.listenSpeed + 0.1);
                    if (this.state.survivalStreak >= 4) this.state.listenNoise = true;
                    this.updateListenToolsUI();
                }
            }
        } else {
            this.quizState.combo = 0;
            const comboEl = document.getElementById('quiz-combo-text');
            if (comboEl) comboEl.classList.add('opacity-0', 'translate-y-2');

            btn.classList.add('bg-red-100', 'border-red-500', 'text-red-700');
            btn.innerHTML += ' ❌';
            this.processSRS(currentWord.id, false);

            if (this.state.listenMode === 'survival') {
                this.state.survivalStreak = 0;
                this.state.listenSpeed = 1.0;
                this.state.listenNoise = false;
                this.updateListenToolsUI();
            }
        }

        this.showQuizFeedback(isCorrect);
    },

    showQuizFeedback: function (isCorrect) {
        if (this.autoNextTimeout) clearTimeout(this.autoNextTimeout);

        this.playSound(isCorrect ? 'correct' : 'wrong');

        const bar = document.getElementById('quiz-feedback-bar');
        const inner = document.getElementById('quiz-feedback-inner');
        if (!bar || !inner) return;

        const currentWord = this.quizData[this.quizState.index];
        const safeWord = currentWord.word.replace(/'/g, "\\'");

        bar.classList.remove('hidden');
        setTimeout(() => bar.classList.remove('translate-y-full'), 10);

        const getConnectedSpeech = (text) => {
            const words = text.split(' ');
            return words.map((w, i) => {
                const next = words[i + 1];
                if (next && /[^aeiou]$/i.test(w) && /^[aeiou]/i.test(next)) {
                    return `<span class="text-yellow-300 underline decoration-2 underline-offset-4 font-black">${w}</span>`;
                }
                if (/^(in|on|at|to|the|a|an|of|and)$/i.test(w)) return `<span class="opacity-50 font-light">${w}</span>`;
                return w;
            }).join(' ');
        };

        const detailsHtml = `
            <div class="mt-2 md:mt-3 p-4 bg-white/20 rounded-2xl text-left border border-white/30 backdrop-blur-md w-full shadow-inner max-h-[40vh] overflow-y-auto">
                <div class="mb-3 p-2 bg-black/20 rounded-lg border border-white/10">
                    <p class="text-[10px] font-bold text-yellow-200 uppercase mb-1 flex items-center gap-1">🔍 Phân tích nối âm & Nuốt âm:</p>
                    <p class="text-sm leading-relaxed">${getConnectedSpeech(currentWord.example || currentWord.word)}</p>
                </div>
                <div class="flex items-center gap-3 mb-2">
                    <button onclick="app.playAudio(event, '${safeWord}')" class="p-2 bg-white text-gray-800 rounded-full hover:scale-110 transition shadow-sm shrink-0"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg></button>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="font-black text-lg md:text-xl tracking-wide truncate drop-shadow-sm">${currentWord.word}</span>
                            <span class="text-xs font-mono font-bold bg-black/20 px-2 py-0.5 rounded whitespace-nowrap">${currentWord.pronun || '/.../'}</span>
                        </div>
                    </div>
                    <span class="text-[10px] uppercase tracking-widest font-black opacity-80 border border-white/40 px-2 py-1 rounded ml-auto shrink-0">${currentWord.type || 'Word'}</span>
                </div>
                <p class="text-sm md:text-base font-bold mb-3 text-white drop-shadow-sm leading-snug">${currentWord.definition}</p>
                ${currentWord.example ? `
                <div class="pl-3 border-l-4 border-white/40 bg-black/5 p-2 rounded-r-lg">
                    <p class="text-xs md:text-sm italic font-medium opacity-95">"${currentWord.example}"</p>
                    ${currentWord.exTranslation ? `<p class="text-[10px] md:text-xs opacity-80 mt-1 font-medium">${currentWord.exTranslation}</p>` : ''}
                </div>` : ''}
            </div>
        `;

        if (isCorrect) {
            inner.className = 'p-5 rounded-3xl flex flex-col shadow-2xl gap-2 bg-emerald-500 text-white dark:bg-emerald-600 border-t-4 border-emerald-300 w-full';
            inner.innerHTML = `
                <div class="flex flex-col md:flex-row items-center justify-between gap-4 w-full">
                    <div class="flex items-center gap-4 w-full md:w-auto flex-1">
                        <div class="w-12 h-12 shrink-0 rounded-full flex items-center justify-center text-2xl font-black bg-white text-emerald-500 shadow-md">✓</div>
                        <div class="text-left flex-1 min-w-0">
                            <h4 class="text-xl font-black tracking-wide drop-shadow-sm truncate">${this.lang === 'vi' ? 'Tuyệt vời!' : 'Excellent!'}</h4>
                            <p class="text-xs font-bold opacity-90">Bạn đã trả lời chính xác.</p>
                        </div>
                    </div>
                    <button onclick="app.nextQuizQuestion()" id="quiz-feedback-btn" class="w-full md:w-auto px-8 py-3.5 rounded-2xl font-black shadow-lg hover:shadow-xl transition-all active:scale-95 text-center uppercase tracking-widest text-sm bg-white text-emerald-600 hover:bg-emerald-50 shrink-0 flex items-center justify-center">
                        Tiếp Tục ➔
                    </button>
                </div>
                ${detailsHtml}
            `;
        } else {
            inner.className = 'p-5 rounded-3xl flex flex-col shadow-2xl gap-2 bg-rose-500 text-white dark:bg-rose-600 border-t-4 border-rose-300 w-full';
            inner.innerHTML = `
                <div class="flex flex-col md:flex-row items-center justify-between gap-4 w-full">
                    <div class="flex items-center gap-4 w-full md:w-auto flex-1">
                        <div class="w-12 h-12 shrink-0 rounded-full flex items-center justify-center text-2xl font-black bg-white text-rose-500 shadow-md">✕</div>
                        <div class="text-left flex-1 min-w-0">
                            <h4 class="text-xl font-black tracking-wide drop-shadow-sm truncate">${this.lang === 'vi' ? 'Chưa chính xác!' : 'Not quite!'}</h4>
                            <p class="text-xs font-bold opacity-90 truncate">Đ.án: ${this.quizState.correctAnswer}</p>
                        </div>
                    </div>
                    <div class="flex gap-2 w-full md:w-auto mt-2 md:mt-0">
                        ${this.state.quizMode === 'listen' && currentWord.example ? `<button id="btn-shadowing" onclick="if(app.autoNextTimeout) clearTimeout(app.autoNextTimeout); app.checkSentencePronunciation(event)" class="flex-1 md:flex-none px-4 py-3.5 rounded-xl font-black shadow-md hover:shadow-lg transition-all active:scale-95 text-center text-xs bg-rose-700 text-white border border-rose-500 flex items-center justify-center gap-1.5 shrink-0"><span class="text-base leading-none">🎙️</span> Luyện Đọc Lại</button>` : ''}
                        <button onclick="app.nextQuizQuestion()" id="quiz-feedback-btn" class="flex-1 md:flex-none px-6 py-3.5 rounded-xl font-black shadow-md hover:shadow-lg transition-all active:scale-95 text-center uppercase tracking-widest text-[11px] md:text-sm bg-white text-rose-600 hover:bg-rose-50 shrink-0 flex flex-col items-center justify-center leading-tight">
                            <span>Đã Hiểu ➔</span>
                        </button>
                    </div>
                </div>
                ${detailsHtml}
            `;
        }
    },

    nextQuizQuestion: function () {
        if (this.autoNextTimeout) {
            clearTimeout(this.autoNextTimeout);
            this.autoNextTimeout = null;
        }

        const bar = document.getElementById('quiz-feedback-bar');
        if (bar) {
            bar.classList.add('translate-y-full');
            setTimeout(() => bar.classList.add('hidden'), 300);
        }

        if (this.state.listenMode === 'deep') {
            this.state.deepStep++;
            if (this.state.deepStep < 3) {
                setTimeout(() => this.renderQuestion(), 300);
                return;
            } else {
                this.state.deepStep = 0; 
            }
        }

        if (!this.quizState || !this.quizData) {
            this.showQuizResult();
            return;
        }

        const btn = document.getElementById('quiz-feedback-btn');
        if (btn && btn.disabled) return;
        if (btn) btn.disabled = true;

        this.quizState.index++;

        if (this.quizState.index < this.quizData.length) {
            setTimeout(() => {
                this.renderQuestion();
                if (btn) btn.disabled = false;
            }, 300);
        } else {
            this.showQuizResult();
            if (btn) btn.disabled = false;
        }
    },

    updateListenToolsUI: function () {
        const sBtn = document.getElementById('listen-speed-btn');
        const nBtn = document.getElementById('listen-noise-btn');
        if (sBtn) sBtn.innerHTML = `🔥 ${this.state.listenSpeed.toFixed(1)}x`;
        if (nBtn) nBtn.innerHTML = this.state.listenNoise ? '🌧️ Ồn ào' : '☕ Yên tĩnh';
    },

    showQuizResult: function () {
        this.updateQuest('quiz', 1); 
        const expGained = Math.floor(this.quizState.score / 5);
        if (expGained > 0) {
            this.user.exp = (this.user.exp || 0) + expGained;
            this.saveUserData();
        }
        document.getElementById('quiz-game').classList.replace('flex', 'hidden');
        document.getElementById('quiz-result').classList.remove('hidden');
        document.getElementById('quiz-final-score').textContent = this.quizState.score;
    }

});