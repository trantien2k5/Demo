/**
 * FLASHCARD PRO - UI & LANGUAGE MODULE
 * Module này quản lý toàn bộ về Điều hướng (Tabs, Navbar),
 * Giao diện (Theme Sáng/Tối), Đa ngôn ngữ (Tiếng Việt/Anh) 
 * và các Sự kiện chung (Vuốt thẻ, Bàn phím).
 */

Object.assign(app, {

    // ==========================================
    // 1. ĐIỀU HƯỚNG & GIAO DIỆN (NAVIGATION)
    // ==========================================
    navigate: function (viewName) {
        Object.values(this.dom.views).forEach(el => {
            if (el) {
                el.classList.add('hidden');
                el.classList.remove('animate-fade-in-up');
            }
        });

        const questBtn = document.getElementById('draggable-quest-btn');
        if (questBtn) {
            const isFocusMode = ['arena', 'mocktest', 'quiz'].includes(viewName);
            questBtn.classList.toggle('hidden', isFocusMode);
        }

        const targetView = this.dom.views[viewName];
        if (targetView) {
            targetView.classList.remove('hidden');
            void targetView.offsetWidth;
            targetView.classList.add('animate-fade-in-up');
        }

        const fbBar = document.getElementById('quiz-feedback-bar');
        if (fbBar) fbBar.classList.add('hidden', 'translate-y-full');

        this.handleTabChange(viewName);
        this.syncNavbar(viewName);
        window.scrollTo(0, 0);
    },

    handleTabChange: function (view) {
        if (view === 'dashboard') {
            this.renderStats();
            this.renderDailyQuests();
            this.updateMascotImage(); 
            setTimeout(() => this.pokeMascot(true), 500);
        }
        if (view === 'listening') {
            this.renderListeningTopics();
        }
        if (view === 'grammar') {
            this.renderGrammarTopics();
        }
        if (view === 'study') {
            this.renderTopics();
            this.backToTopics();
        }
        if (view === 'library') this.renderLibrary();
        if (view === 'quiz') {
            document.getElementById('quiz-intro').classList.remove('hidden');
            ['quiz-game', 'quiz-result'].forEach(id => document.getElementById(id).classList.add('hidden'));
            this.renderTopics();
        }
    },

    syncNavbar: function (activeTab) {
        this.dom.navItems.forEach(btn => {
            const target = btn.getAttribute('data-target');
            const isDesktop = btn.classList.contains('w-full');
            const iconBox = btn.querySelector('span.bg-gray-100, span.bg-indigo-100');

            if (target === activeTab) {
                btn.classList.add('text-primary');
                btn.classList.remove('text-gray-400', 'text-gray-600');
                if (isDesktop) {
                    btn.classList.add('bg-indigo-50', 'dark:bg-indigo-900/20');
                    if (iconBox) {
                        iconBox.classList.remove('bg-gray-100');
                        iconBox.classList.add('bg-indigo-100', 'text-primary', 'dark:bg-indigo-900', 'dark:text-white');
                    }
                }
            } else {
                btn.classList.remove('text-primary', 'bg-indigo-50', 'dark:bg-indigo-900/20');
                btn.classList.add(isDesktop ? 'text-gray-600' : 'text-gray-400');
                if (isDesktop && iconBox) {
                    iconBox.classList.remove('bg-indigo-100', 'text-primary', 'dark:bg-indigo-900', 'dark:text-white');
                    iconBox.classList.add('bg-gray-100');
                }
            }
        });
    },

    refreshViews: function () {
        this.saveData();
        this.renderStats();
        if (!this.dom.views.library.classList.contains('hidden')) this.renderLibrary();
        if (!document.getElementById('study-topics').classList.contains('hidden')) this.renderTopics();
        if (!this.dom.views.profile.classList.contains('hidden')) this.renderStats();
    },

    // ==========================================
    // 2. SỰ KIỆN CHUNG (EVENTS & SWIPE)
    // ==========================================
    bindEvents: function () {
        document.addEventListener('keydown', (e) => {
            if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;

            const fbBar = document.getElementById('quiz-feedback-bar');
            if (fbBar && !fbBar.classList.contains('hidden') && e.code === 'Enter') {
                e.preventDefault();
                const btn = document.getElementById('quiz-feedback-btn');
                if (btn && !btn.disabled) btn.click();
                return;
            }

            if (this.dom.views.study.classList.contains('hidden')) return;
            if (e.code === 'ArrowRight') this.nextCard();
            if (e.code === 'ArrowLeft') this.prevCard();
            if (e.code === 'Space') { e.preventDefault(); this.flipCard(); }
        });

        let touchStartX = 0;
        let touchEndX = 0;

        document.addEventListener('touchstart', e => {
            if (this.dom.views.study.classList.contains('hidden')) return;
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });

        document.addEventListener('touchend', e => {
            if (this.dom.views.study.classList.contains('hidden')) return;
            touchEndX = e.changedTouches[0].screenX;
            this.handleSwipe(touchStartX, touchEndX);
        }, { passive: true });

        // === THÊM MỚI: LOGIC KÉO THẢ NÚT NHIỆM VỤ ===
        const btn = document.getElementById('draggable-quest-btn');
        if (!btn) return;

        let isDragging = false;
        let startX, startY, initialX, initialY;
        let isDragged = false; // Biến cờ để phân biệt giữa Kéo và Click

        const startDrag = (e) => {
            isDragging = true;
            isDragged = false;
            // Ngừng transition để kéo mượt hơn
            btn.style.transition = 'none'; 
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            
            startX = clientX;
            startY = clientY;
            const rect = btn.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;
        };

        const onDrag = (e) => {
            if (!isDragging) return;
            e.preventDefault(); // Chặn cuộn màn hình khi đang kéo
            isDragged = true;

            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;

            let newX = initialX + (clientX - startX);
            let newY = initialY + (clientY - startY);

            // Giới hạn không cho kéo lọt ra ngoài màn hình
            const maxX = window.innerWidth - btn.offsetWidth;
            const maxY = window.innerHeight - btn.offsetHeight;
            newX = Math.max(0, Math.min(newX, maxX));
            newY = Math.max(0, Math.min(newY, maxY));

            // Set vị trí mới (Xóa thuộc tính right/top mặc định của Tailwind)
            btn.style.left = `${newX}px`;
            btn.style.top = `${newY}px`;
            btn.style.right = 'auto'; 
            btn.style.bottom = 'auto';
        };

        const stopDrag = (e) => {
            if (!isDragging) return;
            isDragging = false;

            const rect = btn.getBoundingClientRect();
            const midX = window.innerWidth / 2;
            const isMobile = window.innerWidth < 768;
            const padding = 20; // Khoảng cách đệm tránh dính sát mép

            btn.style.transition = 'all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)';

            // Snap mép gần nhất và giới hạn vùng an toàn tránh đè thanh điều hướng (Bottom Bar)
            btn.style.right = 'auto';
            btn.style.bottom = 'auto';

            let finalY = rect.top;
            const maxY = window.innerHeight - btn.offsetHeight - (isMobile ? 80 : 20);
            if (finalY > maxY) finalY = maxY;
            if (finalY < 20) finalY = 20;
            btn.style.top = finalY + 'px';

            if (!isMobile || (rect.left + rect.width / 2) >= midX) {
                btn.style.left = (window.innerWidth - btn.offsetWidth - padding) + 'px';
            } else {
                btn.style.left = padding + 'px';
            }

            // Chặn click nếu người dùng vừa thực hiện hành động "kéo"
            if (isDragged) {
                const preventClick = (ev) => {
                    ev.stopPropagation();
                    ev.preventDefault();
                    btn.removeEventListener('click', preventClick, true);
                };
                btn.addEventListener('click', preventClick, true);
            }
        };

        // Gắn sự kiện cho Chuột (PC)
        btn.addEventListener('mousedown', startDrag);
        document.addEventListener('mousemove', onDrag, { passive: false });
        document.addEventListener('mouseup', stopDrag);

        // Gắn sự kiện cho Cảm ứng (Mobile)
        btn.addEventListener('touchstart', startDrag, { passive: false });
        document.addEventListener('touchmove', onDrag, { passive: false });
        document.addEventListener('touchend', stopDrag);
    },

    handleSwipe: function (startX, endX) {
        const threshold = 50; 
        if (startX - endX > threshold) {
            this.nextCard(); 
        } else if (endX - startX > threshold) {
            this.prevCard(); 
        }
    },

    startClock: function () {
        const update = () => {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('vi-VN', { hour12: false });
            const dateStr = now.toLocaleDateString('vi-VN', { weekday: 'short', day: '2-digit', month: '2-digit' });
            document.querySelectorAll('.live-clock-full').forEach(el => el.textContent = `${timeStr} • ${dateStr}`);
        };
        update(); setInterval(update, 1000);
    },

    // ==========================================
    // 3. THEME & LANGUAGE SYSTEM
    // ==========================================
    toggleTheme: function () {
        const isDark = document.documentElement.classList.toggle('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        this.updateThemeUI();
    },

    updateThemeUI: function () {
        const isDark = document.documentElement.classList.contains('dark');
        const status = document.getElementById('theme-status');
        if (status) status.textContent = isDark ? this.t('dark_on') : this.t('dark_off');
    },

    lang: 'vi',
    
    t: function (key) {
        return this.translations[this.lang]?.[key] || this.translations['vi'][key] || key;
    },

    translations: {
        vi: {
            nav_home: 'Trang chủ', nav_learn: 'Từ Vựng', nav_library: 'Thư Viện', nav_listen: 'Nghe Hiểu', nav_read: 'Đọc Hiểu', nav_profile: 'Hồ Sơ',
            dash_hello: 'Xin chào', dash_ready: 'Sẵn sàng nâng cao vốn từ vựng chưa?',
            stat_total: 'Tổng số từ', stat_learned: 'Đã học', stat_progress: 'Tiến độ',
            rev_title: 'Trung Tâm Ghi Nhớ 🧠', rev_desc: 'Hệ thống lặp lại ngắt quãng (SRS) giúp bạn nhớ từ mãi mãi.', rev_due: 'Cần ôn tập ngay', rev_btn_srs: '🚀 Ôn tập SRS (Đến hạn)', rev_btn_game: '🎮 Game Trắc Nghiệm',
            pro_words: 'Từ vựng', pro_topics: 'Chủ đề', pro_streak: 'Chuỗi ngày',
            setting_title: 'Cài Đặt Ứng Dụng', lang_label: 'Ngôn ngữ', voice_label: 'Giọng đọc', voice_desc: 'Tùy chỉnh Anh, Mỹ, Úc...', data_label: 'Quản lý Dữ liệu', data_desc: 'Backup, Nạp từ, Reset', dark_label: 'Chế độ tối', dark_desc: 'Chạm để bật/tắt',
            lang_modal_title: 'Chọn Ngôn Ngữ', data_modal_title: 'Quản Lý Dữ Liệu',
            data_backup: 'Backup (Sao lưu)', import_btn: 'Nạp Từ (Import)', data_reset: 'Reset App',
            toast_lang: 'Đã chuyển sang Tiếng Việt',
            dark_on: 'Đang Bật', dark_off: 'Chạm để bật/tắt',
            rank_0: '🥉 Tập Sự', rank_1: '🥈 Tân Binh', rank_2: '🥇 Tinh Anh', rank_3: '🏆 Cao Thủ', rank_4: '💎 Thách Đấu',
            day: 'Ngày', next_lv: 'Lên cấp sau', days: 'ngày',
            quiz_mean: 'Đoán Nghĩa', quiz_rev: 'Dịch Ngược', quiz_fill: 'Ghép Câu', quiz_lis: 'Luyện Nghe',
            srs_new: 'Mới học', srs_learning: 'Đang nhớ', srs_master: 'Thành thạo'
        },
        en: {
            nav_home: 'Home', nav_learn: 'Vocabulary', nav_library: 'Library', nav_listen: 'Listening', nav_read: 'Reading', nav_profile: 'Profile',
            dash_hello: 'Hello', dash_ready: 'Ready to boost your vocabulary?',
            stat_total: 'Total Words', stat_learned: 'Learned', stat_progress: 'Progress',
            rev_title: 'Review Center 🧠', rev_desc: 'Spaced Repetition System (SRS) for permanent memory.', rev_due: 'Due for Review', rev_btn_srs: '🚀 Start SRS Review', rev_btn_game: '🎮 Quick Quiz Game',
            pro_words: 'Words', pro_topics: 'Topics', pro_streak: 'Streak',
            setting_title: 'App Settings', lang_label: 'Language', voice_label: 'Voice Accent', voice_desc: 'Customize US, UK, AU...', data_label: 'Data Manager', data_desc: 'Backup, Import, Reset', dark_label: 'Dark Mode', dark_desc: 'Tap to toggle',
            lang_modal_title: 'Select Language', data_modal_title: 'Data Management',
            data_backup: 'Backup Data', import_btn: 'Import Words', data_reset: 'Reset App',
            toast_lang: 'Switched to English',
            dark_on: 'Enabled', dark_off: 'Tap to toggle',
            rank_0: '🥉 Novice', rank_1: '🥈 Rookie', rank_2: '🥇 Elite', rank_3: '🏆 Master', rank_4: '💎 Challenger',
            day: 'Day', next_lv: 'Next LV in', days: 'days',
            quiz_mean: 'Meaning', quiz_rev: 'Translate', quiz_fill: 'Fill Blank', quiz_lis: 'Listening',
            srs_new: 'New', srs_learning: 'Learning', srs_master: 'Mastered'
        }
    },

    toggleLearningLangModal: function () {
        const m = document.getElementById('modal-learning-lang');
        if(m) {
            m.classList.toggle('hidden'); m.classList.toggle('flex');
            if (!m.classList.contains('hidden')) m.children[0].classList.add('animate-pop-in');
        }
    },

    setLearningLanguage: function (langName, voiceCode) {
        if(!this.user) this.user = {};
        this.user.learningLang = langName;
        this.user.voiceLang = voiceCode; 
        
        if(this.saveUserData) this.saveUserData();
        
        // Tự động set lại menu giọng đọc
        const voiceSelect = document.getElementById('setting-voice-lang');
        if(voiceSelect) voiceSelect.value = voiceCode;
        
        const voiceDisp = document.getElementById('current-voice-display');
        if (voiceDisp && voiceSelect) voiceDisp.textContent = voiceSelect.options[voiceSelect.selectedIndex].text;

        // Gọi hàm đồng bộ UI
        this.updateLearningLangUI();

        this.toggleLearningLangModal();
        if(this.toast) this.toast(`Đã đổi ngôn ngữ học sang ${langName}`, "success");
    },

    // Hàm MỚI: Tự động đổi toàn bộ chữ trên Web khi bạn chọn Ngôn Ngữ
    updateLearningLangUI: function() {
        if(!this.user || !this.user.learningLang) return;
        
        const langMap = {
            'English': 'Tiếng Anh',
            'Chinese': 'Tiếng Trung',
            'Japanese': 'Tiếng Nhật',
            'Korean': 'Tiếng Hàn'
        };
        
        const currentLang = this.user.learningLang;
        const displayVi = langMap[currentLang] || currentLang;

        // 1. Tab Hồ sơ (Setting display)
        const profileDisp = document.getElementById('current-learning-lang-display');
        if (profileDisp) profileDisp.textContent = currentLang;

        // 2. Sidebar Badge (Góc trái trên cùng)
        const sidebarBadge = document.getElementById('global-learning-lang-badge');
        if (sidebarBadge) sidebarBadge.textContent = displayVi;

        // 3. Dashboard Welcome text
        const dashText = document.getElementById('dash-learning-lang-text');
        if (dashText) dashText.textContent = displayVi;

        // 4. AI Modal Title Badge
        const aiModalBadge = document.getElementById('ai-modal-lang-badge');
        if (aiModalBadge) aiModalBadge.textContent = displayVi;
        
        // 5. Update luôn Tiêu đề tab của Trình duyệt!
        document.title = `FlashCard Pro - Học ${displayVi}`;
    },

    toggleLangModal: function () {
        const m = document.getElementById('modal-lang');
        m.classList.toggle('hidden'); m.classList.toggle('flex');
        if (!m.classList.contains('hidden')) m.children[0].classList.add('animate-pop-in');
    },

    setLanguage: function (lang) {
        this.lang = lang;
        localStorage.setItem('app_lang', lang);
        this.applyLanguage();
        this.toggleLangModal();
        this.toast(this.t('toast_lang'), "success");
    },

    applyLanguage: function () {
        const t = this.translations[this.lang];

        document.querySelectorAll('[data-lang]').forEach(el => {
            const key = el.getAttribute('data-lang');
            if (t[key]) el.textContent = t[key];
        });

        const dashNameEl = document.getElementById('dash-name');
        if (dashNameEl && this.user) {
            dashNameEl.textContent = this.user.name;
            const greetingNode = dashNameEl.previousSibling;
            if (greetingNode && greetingNode.nodeType === 3) {
                greetingNode.nodeValue = this.lang === 'vi' ? 'Xin chào, ' : 'Hello, ';
            }
        }

        const actionTitle = document.querySelector('#view-dashboard h2');
        if (actionTitle) actionTitle.textContent = this.lang === 'vi' ? 'Hành động nhanh' : 'Quick Actions';

        const dashStats = document.querySelectorAll('#view-dashboard .grid .text-\\[10px\\]');
        if (dashStats.length >= 3) {
            dashStats[0].textContent = this.lang === 'vi' ? 'Tổng Từ ➔' : 'Total Words ➔';
            dashStats[1].textContent = this.lang === 'vi' ? 'Thuộc Lòng' : 'Mastered';
            dashStats[2].textContent = this.lang === 'vi' ? 'Chuỗi Ngày' : 'Day Streak';
        }

        const dashBoxTitles = document.querySelectorAll('#view-dashboard h3');
        if (dashBoxTitles.length >= 4) {
            dashBoxTitles[0].textContent = this.lang === 'vi' ? 'Ôn Tập Cấp Tốc' : 'SRS Review';
            dashBoxTitles[1].textContent = this.lang === 'vi' ? 'Từ Vựng' : 'Vocabulary';
            dashBoxTitles[2].textContent = this.lang === 'vi' ? 'Nghe Hiểu' : 'Listening';
            dashBoxTitles[3].textContent = this.lang === 'vi' ? 'Đọc Hiểu' : 'Reading';
        }

        const studyTitle = document.querySelector('#study-topics h2');
        if (studyTitle) studyTitle.textContent = this.lang === 'vi' ? 'Chọn Chủ Đề Học' : 'Select Topic to Learn';

        const libSearch = document.getElementById('lib-search');
        if (libSearch) libSearch.placeholder = this.lang === 'vi' ? '🔍 Tìm kiếm từ, nghĩa...' : '🔍 Search words, meanings...';

        const libSort = document.getElementById('lib-sort');
        if (libSort && libSort.options.length > 0) {
            libSort.options[0].text = this.lang === 'vi' ? '🕒 Mới' : '🕒 Newest';
            libSort.options[1].text = this.lang === 'vi' ? '⏳ Cũ' : '⏳ Oldest';
            libSort.options[2].text = this.lang === 'vi' ? '🔤 A-Z' : '🔤 A-Z';
        }

        const proHeaders = document.querySelectorAll('#view-profile h3');
        if (proHeaders.length >= 3) {
            proHeaders[0].textContent = this.lang === 'vi' ? 'Thống Kê Học Tập' : 'Learning Stats';
            proHeaders[1].textContent = this.lang === 'vi' ? 'Hệ Thống & Cài Đặt ⚙️' : 'System Settings ⚙️';
            proHeaders[2].textContent = this.lang === 'vi' ? 'Huy Hiệu Đạt Được 🏆' : 'Earned Badges 🏆';
        }

        const proStats = document.querySelectorAll('#view-profile .grid-cols-2.md\\:grid-cols-4 .uppercase');
        if (proStats.length >= 4) {
            proStats[0].textContent = this.lang === 'vi' ? 'Tổng từ' : 'Total Words';
            proStats[1].textContent = this.lang === 'vi' ? 'Ngày học' : 'Days Learned';
            proStats[2].textContent = this.lang === 'vi' ? 'Tỉ lệ nhớ' : 'Retention';
            proStats[3].textContent = this.lang === 'vi' ? 'Thuộc lòng' : 'Mastered';
        }

        const setTitles = document.querySelectorAll('#view-profile .grid-cols-1.sm\\:grid-cols-2.lg\\:grid-cols-3 .font-bold');
        if (setTitles.length >= 6) {
            setTitles[0].textContent = this.lang === 'vi' ? 'AI Tạo Từ' : 'AI Generator';
            setTitles[1].textContent = this.lang === 'vi' ? 'Giọng Đọc' : 'Voice Accent';
            setTitles[2].textContent = this.lang === 'vi' ? 'Ngôn Ngữ' : 'Language';
            setTitles[3].textContent = this.lang === 'vi' ? 'Giao Diện' : 'Theme Mode';
            setTitles[4].textContent = this.lang === 'vi' ? 'Quản Lý Dữ Liệu' : 'Data Manager';
            setTitles[5].textContent = this.lang === 'vi' ? 'API Key' : 'API Key';
        }

        const setDescs = document.querySelectorAll('#view-profile .grid-cols-1.sm\\:grid-cols-2.lg\\:grid-cols-3 > button > div > div:nth-child(2)');
        if (setDescs.length >= 6) {
            setDescs[0].textContent = this.lang === 'vi' ? 'Sinh từ vựng tự động' : 'Auto generate words';
            setDescs[4].textContent = this.lang === 'vi' ? 'Cloud Sync & Backup' : 'Cloud Sync & Backup';
            setDescs[5].textContent = this.lang === 'vi' ? 'Bảo mật kết nối AI' : 'Secure AI connect';
        }

        const supportTitle = document.getElementById('support-title');
        if (supportTitle) supportTitle.textContent = this.lang === 'vi' ? 'Liên Hệ Hỗ Trợ' : 'Contact Support';

        const aiTitle = document.querySelector('#view-ai h2');
        if (aiTitle) aiTitle.innerHTML = this.lang === 'vi' ? '<span class="text-4xl mr-3">✨</span> Tạo Từ Bằng AI' : '<span class="text-4xl mr-3">✨</span> AI Generator';

        const aiDesc = document.querySelector('#view-ai p.text-gray-500');
        if (aiDesc) aiDesc.textContent = this.lang === 'vi' ? 'Tạo bộ từ vựng thực chiến sát với nhu cầu của bạn trong tích tắc.' : 'Generate practical vocabulary tailored to your needs instantly.';

        const disp = document.getElementById('current-lang-display');
        if (disp) disp.textContent = this.lang === 'vi' ? 'Tiếng Việt' : 'English';

        this.renderProfileHeader();
        this.updateThemeUI();

        if (this.data) {
            this.renderStats();
            const quizBtns = document.querySelectorAll('#view-review button span:nth-child(2)');
            if (quizBtns.length >= 4) {
                quizBtns[0].textContent = this.t('quiz_mean');
                quizBtns[1].textContent = this.t('quiz_rev');
                quizBtns[2].textContent = this.t('quiz_fill');
                quizBtns[3].textContent = this.t('quiz_lis');
            }

            const srsN = document.querySelector('#srs-new')?.nextElementSibling;
            if (srsN) srsN.textContent = this.t('srs_new');
            const srsL = document.querySelector('#srs-learning')?.nextElementSibling;
            if (srsL) srsL.textContent = this.t('srs_learning');
            const srsM = document.querySelector('#srs-master')?.nextElementSibling;
            if (srsM) srsM.textContent = this.t('srs_master');
        }
    }
});