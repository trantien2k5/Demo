/**
 * FLASHCARD PRO - RPG ARENA MODULE
 * Module này chứa toàn bộ logic của hệ thống Đấu Trường Hầm Ngục.
 * Nó sẽ tự động gộp (merge) các hàm này vào đối tượng `app` toàn cục.
 */

Object.assign(app, {
    // --- 13. RPG ARENA ENGINE ---
    bossSprites: ['👺', '👹', '👻', '👽', '🤖', '🦇', '🧛', '🧟', '🐉', '🦖', '👁️', '🐙'],
    bossNames: ['Goblin Lười Biếng', 'Orc Quên Từ', 'Slime Mất Gốc', 'Troll Sai Ngữ Pháp', 'Hiệp Sĩ Mù Chữ', 'Phù Thủy Lặp Từ', 'Ma Cà Rồng Trật Âm', 'Xác Ướp Lười Học', 'Rồng Mù Tiếng Anh', 'T-Rex Ngắc Ngứ', 'Ác Quỷ Quên Nghĩa', 'Bạch Tuộc Rối Não'],

    // NÂNG CẤP RPG: Lõi Hệ Thống Kỹ Năng & Liên Kết Chỉ Số
    startArena: function (nextLevel = false) {
        if (this.data.length < 4) return this.toast("Cần tối thiểu 4 từ trong Thư viện để khiêu chiến Hầm ngục!", "error");
        if (!this.user.dungeonFloor) this.user.dungeonFloor = 1;

        // Reset hệ thống Kỹ Năng mỗi khi vào ải mới
        this.state.arenaState.skillsUsed = { heal: false, hint: false, ulti: false };
        this.state.arenaState.buffUlti = false;

        const st = this.user.stats || { str: 0, int: 0, agi: 0, dex: 0, vit: 0, luk: 0 };
        const userLvl = this.user.exp ? Math.floor(Math.sqrt(this.user.exp / 50)) + 1 : 1;
        const calcLv = (pts) => Math.floor(Math.sqrt((pts || 0) / 10));
        const vitLv = calcLv(st.vit);

        if (!nextLevel) {
            this.state.arenaState.level = this.user.dungeonFloor;
            this.state.arenaState.pMaxHp = 100 + (userLvl * 20) + (vitLv * 15);
            this.state.arenaState.pHp = this.state.arenaState.pMaxHp;
        } else {
            this.state.arenaState.level++;
            const healRate = 0.5 + (vitLv * 0.01);
            this.state.arenaState.pHp = Math.min(this.state.arenaState.pMaxHp, this.state.arenaState.pHp + Math.floor(this.state.arenaState.pMaxHp * healRate));
        }

        const lv = this.state.arenaState.level;
        const isBossFloor = lv % 10 === 0;

        this.state.arenaState.bMaxHp = isBossFloor ? (100 + (lv * 60) + Math.pow(lv, 1.8)) : (40 + (lv * 25) + Math.pow(lv, 1.5));
        this.state.arenaState.bMaxHp = Math.floor(this.state.arenaState.bMaxHp);
        this.state.arenaState.bHp = this.state.arenaState.bMaxHp;

        const bIdx = (lv - 1) % this.bossSprites.length;
        const bossIcon = isBossFloor ? '👑' : this.bossSprites[bIdx];
        const bossName = isBossFloor ? `[BOSS] CHÚA TỂ TẦNG ${lv}` : `Lv.${lv} ${this.bossNames[bIdx]}`;

        document.getElementById('arena-boss-sprite').innerHTML = `${bossIcon}<div id="arena-dmg-boss-layer" class="absolute inset-0 pointer-events-none z-20"></div><div id="arena-slash" class="absolute inset-0 text-white text-[120px] opacity-0 pointer-events-none flex items-center justify-center z-10 drop-shadow-[0_0_20px_rgba(255,255,255,1)]">⚔️</div>`;
        document.getElementById('arena-boss-name').textContent = bossName;

        if (isBossFloor) {
            document.getElementById('arena-boss-name').className = 'bg-black/80 border-2 border-yellow-500 px-4 py-1 rounded-md text-xs text-yellow-400 font-black uppercase tracking-widest mb-3 animate-pulse shadow-[0_0_15px_rgba(234,179,8,0.5)]';
            document.getElementById('arena-boss-sprite').classList.add('scale-125');
        } else {
            document.getElementById('arena-boss-name').className = 'bg-red-950/80 border border-red-800 px-3 py-0.5 rounded-md text-[10px] md:text-xs text-red-300 font-bold uppercase tracking-widest mb-3 backdrop-blur-sm';
            document.getElementById('arena-boss-sprite').classList.remove('scale-125');
        }

        document.getElementById('arena-level').textContent = `${lv}/100`;
        document.getElementById('arena-player-sprite').innerHTML = `${this.user.avatar || '👨‍🎓'}<div id="arena-dmg-player-layer" class="absolute inset-0 pointer-events-none z-20"></div>`;
        document.getElementById('arena-player-sprite').classList.remove('drop-shadow-[0_0_30px_rgba(168,85,247,1)]'); // Xóa aura buff nếu có

        this.state.arenaState.pool = [...this.data].sort((a, b) => (a.level || 0) - (b.level || 0)).slice(0, 15 + Math.floor(lv / 2)).sort(() => 0.5 - Math.random());

        this.updateArenaUI();
        this.renderArenaSkills(); // Vẽ thanh Kỹ năng

        document.getElementById('arena-ui').classList.remove('hidden');
        document.getElementById('arena-result').classList.replace('flex', 'hidden');
        document.querySelector('#view-arena .bg-black.border-4').classList.remove('hidden');

        this.navigate('arena');
        this.nextArenaTurn();
    },

    // TÍNH NĂNG MỚI: Render Thanh Kỹ Năng dựa trên Level
    renderArenaSkills: function () {
        const bar = document.getElementById('arena-skill-bar');
        if (!bar) return;

        const userLvl = this.user.exp ? Math.floor(Math.sqrt(this.user.exp / 50)) + 1 : 1;
        const skills = [
            { id: 'heal', name: 'Bơm Máu', icon: '💖', unlock: 5, desc: 'Hồi 50% HP (1 lần/ải)' },
            { id: 'hint', name: 'Thiên Nhãn', icon: '👁️', unlock: 10, desc: 'Gợi ý đáp án (1 lần/ải)' },
            { id: 'ulti', name: 'Trảm Sát', icon: '⚡', unlock: 15, desc: 'Chém x3 Sát thương (1 lần/ải)' }
        ];

        bar.innerHTML = skills.map(s => {
            const isUnlocked = userLvl >= s.unlock;
            const isUsed = this.state.arenaState.skillsUsed[s.id];

            // Chưa đủ level mở khóa
            if (!isUnlocked) {
                return `
                <div class="relative group cursor-not-allowed">
                    <button disabled class="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-gray-800 border-2 border-gray-700 flex items-center justify-center text-2xl opacity-50 grayscale shadow-inner">🔒</button>
                    <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block w-max bg-gray-900 text-gray-300 text-[10px] md:text-xs px-3 py-1.5 rounded-lg border border-gray-700 z-50 font-bold shadow-lg">Mở khóa ở Lv.${s.unlock}</div>
                </div>`;
            }

            // Đã sử dụng trong ải này
            if (isUsed) {
                return `<button disabled class="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-gray-900 border-2 border-gray-800 flex items-center justify-center text-2xl opacity-30 grayscale cursor-not-allowed shadow-inner">${s.icon}</button>`;
            }

            // Sẵn sàng sử dụng
            let colorClass = 'border-indigo-500 hover:bg-indigo-900 shadow-[0_0_15px_rgba(99,102,241,0.4)]';
            if (s.id === 'heal') colorClass = 'border-green-500 hover:bg-green-900 shadow-[0_0_15px_rgba(34,197,94,0.4)]';
            if (s.id === 'ulti') colorClass = 'border-purple-500 hover:bg-purple-900 shadow-[0_0_15px_rgba(168,85,247,0.4)] text-purple-200';

            return `
            <div class="relative group">
                <button onclick="app.useArenaSkill('${s.id}')" class="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-gray-800 border-2 transition-all flex items-center justify-center text-2xl hover:scale-110 active:scale-95 ${colorClass}">
                    ${s.icon}
                </button>
                <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block w-max bg-gray-900 text-white text-[10px] md:text-xs px-3 py-2 rounded-lg border border-gray-700 z-50 shadow-xl font-medium tracking-wide">
                    <span class="font-black text-white block mb-0.5">${s.name}</span>${s.desc}
                </div>
            </div>`;
        }).join('');
    },

    // TÍNH NĂNG MỚI: Kích hoạt Kỹ năng
    useArenaSkill: function (id) {
        if (this.state.arenaState.skillsUsed[id]) return;
        this.state.arenaState.skillsUsed[id] = true;

        if (id === 'heal') {
            const healAmount = Math.floor(this.state.arenaState.pMaxHp * 0.5);
            this.state.arenaState.pHp = Math.min(this.state.arenaState.pMaxHp, this.state.arenaState.pHp + healAmount);
            this.playSound('correct');
            this.showCombatText('+HP 💖', 'text-green-400');
            this.updateArenaUI();
        }
        else if (id === 'hint') {
            const isBossFloor = this.state.arenaState.level % 10 === 0;
            if (isBossFloor) {
                const input = document.getElementById('arena-typing-input');
                const word = this.state.arenaState.currentWord.word;
                if (input) {
                    input.value = word.substring(0, 2);
                    this.toast("Đã hé lộ 2 ký tự đầu!", "info");
                }
            } else {
                const btns = document.querySelectorAll('#arena-options button');
                let removed = 0;
                btns.forEach(b => {
                    const spanText = b.querySelector('span').textContent;
                    if (spanText !== this.state.arenaState.currentWord.definition && removed < 2) {
                        b.style.opacity = '0.2';
                        b.disabled = true;
                        removed++;
                    }
                });
                this.toast("Thiên nhãn! Đã loại bỏ 2 đáp án sai.", "success");
            }
            this.playSound('correct');
        }
        else if (id === 'ulti') {
            this.state.arenaState.buffUlti = true;
            this.showCombatText('SÁT Ý! ⚡', 'text-purple-400');
            this.playSound('crit');
            document.getElementById('arena-player-sprite').classList.add('drop-shadow-[0_0_30px_rgba(168,85,247,1)]');
        }
        this.renderArenaSkills();
    },

    updateArenaUI: function () {
        const pPercent = Math.max(0, (this.state.arenaState.pHp / this.state.arenaState.pMaxHp) * 100);
        const bPercent = Math.max(0, (this.state.arenaState.bHp / this.state.arenaState.bMaxHp) * 100);

        document.getElementById('arena-player-hp').style.width = `${pPercent}%`;
        document.getElementById('arena-player-hp-text').textContent = `${this.state.arenaState.pHp}/${this.state.arenaState.pMaxHp}`;

        document.getElementById('arena-boss-hp').style.width = `${bPercent}%`;
        document.getElementById('arena-boss-hp-text').textContent = `${this.state.arenaState.bHp}/${this.state.arenaState.bMaxHp}`;
    },

    nextArenaTurn: function () {
        if (this.state.arenaState.pool.length === 0) this.state.arenaState.pool = [...this.data].sort((a, b) => (a.level || 0) - (b.level || 0)).slice(0, 20).sort(() => 0.5 - Math.random());
        const word = this.state.arenaState.pool.pop();
        this.state.arenaState.currentWord = word;

        document.getElementById('arena-word').textContent = word.word;
        setTimeout(() => this.playAudio(null, word.word), 150);

        const isBossFloor = this.state.arenaState.level % 10 === 0;

        if (isBossFloor) {
            document.getElementById('arena-word').innerHTML = `<span class="text-yellow-400">Boss chặn đường!</span><br><span class="text-lg md:text-xl font-medium text-gray-300">Dịch từ này sang Tiếng Anh:</span><br>"${word.definition}"`;
            document.getElementById('arena-options').innerHTML = `
                <div class="flex flex-col gap-3 mt-2">
                    <input type="text" id="arena-typing-input" autocomplete="off" class="w-full p-4 bg-gray-950 border-2 border-red-900 rounded-xl font-black text-white text-center text-xl uppercase tracking-widest focus:border-red-500 focus:ring-0 shadow-inner" placeholder="NHẬP TỪ TIẾNG ANH...">
                    <button onclick="app.handleArenaAnswer('TYPE_MODE')" class="w-full py-4 bg-red-700 text-white rounded-xl font-black text-lg hover:bg-red-600 transition shadow-[0_0_20px_rgba(220,38,38,0.4)] flex items-center justify-center gap-2">
                        <span>💥 TUNG TUYỆT CHIÊU 💥</span>
                    </button>
                </div>
            `;
            setTimeout(() => document.getElementById('arena-typing-input')?.focus(), 100);

        } else {
            let options = [word.definition];
            const distractors = [...new Set(this.data.map(i => i.definition))].filter(d => d && d !== word.definition);
            distractors.sort(() => 0.5 - Math.random());
            options = options.concat(distractors.slice(0, 3)).sort(() => 0.5 - Math.random());

            const optHtml = options.map(opt => `
                <button onclick="app.handleArenaAnswer('${opt.replace(/'/g, "\\'")}')" class="w-full p-4 bg-gray-800 border-2 border-gray-700 rounded-xl font-black text-gray-300 hover:border-red-500 hover:bg-red-950 hover:text-white transition-all text-left shadow-[0_4px_0_rgba(0,0,0,0.3)] hover:shadow-[0_2px_0_rgba(220,38,38,0.5)] hover:translate-y-[2px] group flex items-center justify-between">
                    <span>${opt}</span>
                    <span class="opacity-0 group-hover:opacity-100 transition-all text-2xl transform translate-x-4 group-hover:translate-x-0 drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]">🗡️</span>
                </button>
            `).join('');
            document.getElementById('arena-options').innerHTML = optHtml;
        }
    },

    handleArenaAnswer: function (selected) {
        const btns = document.querySelectorAll('#arena-options button');
        btns.forEach(b => b.disabled = true);
        const typingInput = document.getElementById('arena-typing-input');
        if (typingInput) typingInput.disabled = true;

        const wordObj = this.state.arenaState.currentWord;
        let isCorrect = false;

        if (selected === 'TYPE_MODE') {
            const userInput = (typingInput?.value || '').trim().toLowerCase();
            isCorrect = userInput === wordObj.word.toLowerCase();
        } else {
            isCorrect = selected === wordObj.definition;
        }

        const st = this.user.stats || { str: 0, int: 0, agi: 0, dex: 0, vit: 0, luk: 0 };
        const calcLv = (pts) => Math.floor(Math.sqrt((pts || 0) / 10));
        const strLv = calcLv(st.str);
        const lukLv = calcLv(st.luk);
        const agiLv = calcLv(st.agi);
        const intLv = calcLv(st.int);

        if (isCorrect) {
            this.processSRS(wordObj.id, true);
            this.updateQuest('quiz', 1);

            this.state.arenaState.combo++;
            const comboMultiplier = 1 + (this.state.arenaState.combo * 0.1);

            const critChance = Math.min(0.5, 0.1 + (this.state.arenaState.combo * 0.05) + (lukLv * 0.01));
            const isCrit = Math.random() < critChance;

            const userLvl = this.user.exp ? Math.floor(Math.sqrt(this.user.exp / 50)) + 1 : 1;

            const baseDmg = 30 + Math.floor(Math.random() * 20) + (userLvl * 5) + (strLv * 4) + (intLv * 2);
            let finalDmg = Math.floor(baseDmg * comboMultiplier);

            // Xử lý Buff Kỹ năng Ultimate
            if (this.state.arenaState.buffUlti) {
                finalDmg = finalDmg * 3;
                this.state.arenaState.buffUlti = false; // Xóa buff sau khi chém
                document.getElementById('arena-player-sprite').classList.remove('drop-shadow-[0_0_30px_rgba(168,85,247,1)]');
            } else if (isCrit) {
                finalDmg = Math.floor(finalDmg * 2.5);
                this.gainStat('luk', 2);
            }

            this.state.arenaState.bHp = Math.max(0, this.state.arenaState.bHp - finalDmg);

            this.playSound(isCrit ? 'crit' : 'correct');
            this.triggerArenaAnim('boss', finalDmg, isCrit);
            this.showCombatText(`COMBO x${this.state.arenaState.combo}!`, isCrit ? 'text-yellow-400' : 'text-blue-400');

            setTimeout(() => {
                this.updateArenaUI();
                if (this.state.arenaState.bHp <= 0) this.arenaWin();
                else this.nextArenaTurn();
            }, 800);

        } else {
            this.state.arenaState.combo = 0;
            this.showCombatText('COMBO BROKEN!', 'text-gray-500');
            this.processSRS(wordObj.id, false);

            if (selected === 'TYPE_MODE') {
                this.toast(`❌ Tát sấp mặt! Từ đúng là: "${wordObj.word}"`, "error");
            } else {
                this.toast(`❌ Bạn bị tát! "${wordObj.word}" nghĩa là: ${wordObj.definition}`, "error");
            }

            const rawDmg = 15 + Math.floor(this.state.arenaState.level * 6);

            const dodgeChance = Math.min(0.3, agiLv * 0.015);
            const isDodge = Math.random() < dodgeChance;

            if (isDodge) {
                this.showCombatText('DODGED! 💨', 'text-green-400');
                this.playSound('correct');
                setTimeout(() => { this.nextArenaTurn(); }, 800);
            } else {
                this.state.arenaState.pHp = Math.max(0, this.state.arenaState.pHp - rawDmg);
                this.playSound('wrong');
                this.triggerArenaAnim('player', rawDmg, false);

                setTimeout(() => {
                    this.updateArenaUI();
                    if (this.state.arenaState.pHp <= 0) this.arenaLose();
                    else this.nextArenaTurn();
                }, 800);
            }
        }
    },

    // Hàm tiện ích: In chữ Combo nảy bùng trên đầu Player
    showCombatText: function (text, colorClass) {
        const ct = document.getElementById('arena-combat-text');
        if (!ct) return;
        ct.innerHTML = `<span class="block text-xl font-black ${colorClass} uppercase tracking-widest drop-shadow-[0_0_10px_rgba(0,0,0,0.8)] animate-pop-in">${text}</span>`;
        setTimeout(() => { ct.innerHTML = ''; }, 1000);
    },

    // Nâng cấp: Phản hồi thị giác cực mạnh (Crits, Màn hình lóe)
    triggerArenaAnim: function (target, dmg, isCrit = false) {
        const tObj = document.getElementById(target === 'boss' ? 'arena-boss-sprite' : 'arena-player-sprite');
        const layer = document.getElementById(target === 'boss' ? 'arena-dmg-boss-layer' : 'arena-dmg-player-layer');

        if (target === 'boss') {
            const slash = document.getElementById('arena-slash');
            slash.classList.add('animate-slash');
            if (isCrit) {
                slash.style.transform = 'scale(2)'; // Kiếm chém to hơn nếu bạo kích
                slash.style.filter = 'hue-rotate(90deg) drop-shadow(0 0 30px yellow)'; // Đổi màu vệt chém
            } else {
                slash.style.transform = ''; slash.style.filter = '';
            }
            setTimeout(() => slash.classList.remove('animate-slash'), 400);
        }

        const dmgNode = document.createElement('div');
        // Phóng to số dame nếu nổ Crit
        const critText = isCrit ? `<div class="text-yellow-400 text-sm mb-[-10px] drop-shadow-md">CRITICAL!</div>` : '';
        const size = isCrit ? 'text-6xl md:text-7xl text-yellow-300' : 'text-4xl md:text-5xl text-white';
        const color = target === 'boss' ? `${size} drop-shadow-[0_0_15px_rgba(255,0,0,1)]` : 'text-4xl text-red-500 drop-shadow-[0_0_10px_rgba(0,0,0,1)]';

        dmgNode.className = `absolute top-1/2 left-1/2 font-black z-30 animate-dmg-float flex flex-col items-center justify-center ${color}`;
        dmgNode.innerHTML = `${critText} -${dmg}`;

        layer.appendChild(dmgNode);

        // Thêm Hit Flash và Rung Lắc
        tObj.classList.add('animate-shake', 'animate-hit-flash');

        setTimeout(() => {
            tObj.classList.remove('animate-shake', 'animate-hit-flash');
        }, 400);

        setTimeout(() => {
            if (layer.contains(dmgNode)) layer.removeChild(dmgNode);
        }, 1000);
    },

    arenaWin: function () {
        document.getElementById('arena-ui').classList.add('hidden');
        document.querySelector('#view-arena .bg-black.border-4').classList.add('hidden');

        const isBossFloor = this.state.arenaState.level % 10 === 0;
        const res = document.getElementById('arena-result');
        res.classList.replace('hidden', 'flex');

        document.getElementById('arena-result-bg').className = 'absolute inset-0 bg-gradient-to-t from-yellow-900/50 to-transparent opacity-50';
        document.getElementById('arena-result-title').textContent = isBossFloor ? 'BOSS CLEAR!' : 'VICTORY!';
        document.getElementById('arena-result-title').className = `text-3xl font-black ${isBossFloor ? 'text-orange-400 scale-125' : 'text-yellow-400'} tracking-wider mb-2 relative z-10 uppercase drop-shadow-md transition-all`;
        document.getElementById('arena-result-icon').textContent = isBossFloor ? '👑' : '🏆';
        document.getElementById('arena-result-desc').textContent = `Tầng ${this.state.arenaState.level} đã được chinh phục!`;

        // Lưu tiến độ Vĩnh viễn (Mở khóa tầng mới)
        if (this.state.arenaState.level >= (this.user.dungeonFloor || 1) && this.state.arenaState.level < 100) {
            this.user.dungeonFloor = this.state.arenaState.level + 1;
        }

        // Kiểm tra phá đảo Tầng 100
        if (this.state.arenaState.level >= 100) {
            document.getElementById('arena-btn-next').classList.add('hidden');
            document.getElementById('arena-result-desc').textContent = '🎊 CHÚC MỪNG! BẠN ĐÃ PHÁ ĐẢO TOÀN BỘ 100 TẦNG HẦM NGỤC! 🎊';
        } else {
            document.getElementById('arena-btn-next').classList.remove('hidden');
            document.getElementById('arena-btn-next').innerHTML = `Tiến Vào Tầng ${this.state.arenaState.level + 1} ➔`;
        }

        // Thưởng EXP: Qua Tầng Boss thưởng x5 lần bình thường
        const baseExp = 30 + (10 * this.state.arenaState.level);
        const expGained = isBossFloor ? baseExp * 5 : baseExp;
        this.gainStat('vit', 15 + this.state.arenaState.level); // Tăng chỉ số Thể Lực (Từ vựng)
        document.getElementById('arena-loot-exp').textContent = `+${expGained}`;

        this.user.exp = (this.user.exp || 0) + expGained;
        this.saveUserData();
        this.renderStats(); // Cập nhật lại UI Dashboard ngay lập tức

        this.fireConfetti();
        if (isBossFloor) setTimeout(() => this.fireConfetti(), 800); // Tầng Boss thì bắn pháo hoa 2 lần cho ngầu
    },

    arenaLose: function () {
        document.getElementById('arena-ui').classList.add('hidden');
        document.querySelector('#view-arena .bg-black.border-4').classList.add('hidden');

        const res = document.getElementById('arena-result');
        res.classList.replace('hidden', 'flex');

        document.getElementById('arena-result-bg').className = 'absolute inset-0 bg-gradient-to-t from-red-900/50 to-transparent opacity-50';
        document.getElementById('arena-result-title').textContent = 'DEFEATED';
        document.getElementById('arena-result-title').className = 'text-3xl font-black text-red-500 tracking-wider mb-2 relative z-10 uppercase drop-shadow-md';
        document.getElementById('arena-result-icon').textContent = '☠️';
        document.getElementById('arena-result-desc').textContent = `Bạn gục ngã tại Tầng ${this.state.arenaState.level}... Về làng luyện cấp rồi phục thù!`;

        document.getElementById('arena-btn-next').classList.add('hidden');
        document.getElementById('arena-loot-exp').textContent = `+0`;
    }
});